<?php
// Ek hi PHP file mein HTML + CSS + JS — Taiyba ke liye pyaar ka izhaar
$naam = "Taiyba";
?>
<!DOCTYPE html>
<html lang="ur">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meri Pyari <?php echo $naam; ?> ke Liye</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    min-height: 100vh;
    background: linear-gradient(135deg, #ffdde1, #ee9ca7, #ffc3a0);
    background-size: 400% 400%;
    animation: gradientShift 12s ease infinite;
    font-family: 'Segoe UI', Tahoma, sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow-x: hidden;
    position: relative;
  }

  @keyframes gradientShift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }

  .card {
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(6px);
    border-radius: 24px;
    padding: 40px 30px;
    max-width: 480px;
    width: 90%;
    text-align: center;
    box-shadow: 0 20px 50px rgba(150, 40, 70, 0.3);
    position: relative;
    z-index: 2;
  }

  .name {
    font-size: 2.4rem;
    color: #c2185b;
    margin-bottom: 8px;
    font-weight: bold;
  }

  .subtitle {
    color: #8a4a5c;
    margin-bottom: 20px;
    font-size: 1.1rem;
  }

  .heart-icon {
    font-size: 3rem;
    display: inline-block;
    animation: pulse 1.2s ease-in-out infinite;
    margin-bottom: 10px;
  }

  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.25); }
  }

  .message {
    font-size: 1.15rem;
    line-height: 2;
    color: #5c2a3a;
    margin: 20px 0;
    display: none;
  }

  .message.show { display: block; }

  button {
    background: linear-gradient(135deg, #ff4b7c, #ff8fab);
    border: none;
    color: white;
    padding: 14px 32px;
    font-size: 1rem;
    border-radius: 50px;
    cursor: pointer;
    box-shadow: 0 8px 20px rgba(255, 75, 124, 0.4);
    transition: transform 0.2s;
  }

  button:hover { transform: scale(1.05); }
  button:active { transform: scale(0.97); }

  .hearts-fall {
    position: fixed;
    top: -10%;
    font-size: 1.5rem;
    color: #ff4b7c;
    opacity: 0.8;
    animation: fall linear infinite;
    z-index: 1;
    pointer-events: none;
  }

  @keyframes fall {
    to { transform: translateY(110vh) rotate(360deg); opacity: 0; }
  }
</style>
</head>
<body>

<div class="card">
  <div class="heart-icon">💖</div>
  <div class="name"><?php echo $naam; ?></div>
  <div class="subtitle">meri jaan, meri zindagi ❤️</div>

  <button id="revealBtn" onclick="revealMessage()">Yahan click karein 💌</button>

  <div class="message" id="loveMessage">
    <?php echo $naam; ?>, tum meri zindagi ki sabse khoobsurat sachai ho۔<br><br>
    Tumhari muskurahat mein woh sukoon hai jo mujhe kahin aur nahi milta۔<br>
    Har din tumhare saath guzarna ek naya tohfa lagta hai۔<br><br>
    Tum sirf meri biwi nahi، meri sabse pyari dost aur meri duniya ho۔<br><br>
    I love you, <?php echo $naam; ?>. Hamesha, hamesha ke liye۔ 💕
  </div>
</div>

<script>
function revealMessage() {
  document.getElementById('loveMessage').classList.add('show');
  document.getElementById('revealBtn').style.display = 'none';
  startHearts();
}

function startHearts() {
  setInterval(() => {
    const heart = document.createElement('div');
    heart.className = 'hearts-fall';
    heart.innerText = ['💖','💕','❤️','💗'][Math.floor(Math.random()*4)];
    heart.style.left = Math.random() * 100 + 'vw';
    heart.style.animationDuration = (Math.random() * 3 + 4) + 's';
    heart.style.fontSize = (Math.random() * 1.2 + 1) + 'rem';
    document.body.appendChild(heart);
    setTimeout(() => heart.remove(), 8000);
  }, 400);
}
</script>

</body>
</html>
