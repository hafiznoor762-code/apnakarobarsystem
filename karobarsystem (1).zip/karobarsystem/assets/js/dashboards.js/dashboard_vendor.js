(function(){
  const rootBase = '/karobarsystem/pages/ajax/vendor/pages/';
  const target = document.getElementById('vendor-main-content');
  const dateElement = document.getElementById('current-date');

  function loadInner(file) {
    if (!target) return;
    target.innerHTML = '<p style="padding:20px;">Loading...</p>';
    fetch(rootBase + file)
      .then(r => r.text())
      .then(html => { target.innerHTML = html; })
      .catch(() => { target.innerHTML = '<p style="color:red;">Error loading page.</p>'; });
  }

  window.initVendorDashboard = function() {
    document.querySelectorAll('.rd-link').forEach(a => {
      a.onclick = function(e){
        e.preventDefault();
        document.querySelectorAll('.rd-link').forEach(x=>x.classList.remove('active'));
        this.classList.add('active');
        loadInner(this.dataset.file);
      };
    });
    loadInner(document.querySelector('.rd-link.active').dataset.file);
  };

  // Date show
  if (dateElement) {
    const now = new Date();
    dateElement.innerText = now.toLocaleDateString("en-GB");
  }

  // Sidebar toggle
  document.getElementById('toggle-sidebar')?.addEventListener('click', () => {
    document.querySelector('.rd-sidebar').classList.toggle('hidden');
  });

  initVendorDashboard();
})();
document.addEventListener("DOMContentLoaded", function() {
  const sidebar = document.getElementById("sidebar");
  const toggleBtn = document.getElementById("toggle-sidebar");
  const mainContent = document.querySelector(".rd-main");

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("hidden");    // sidebar slide karega
    mainContent.classList.toggle("full");  // content expand hoga
  });
})();