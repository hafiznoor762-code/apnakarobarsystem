const buttons = document.querySelectorAll(".menu-btn");
const contentBox = document.getElementById("contentBox"); 

buttons.forEach(btn => {
    btn.addEventListener("click", () => { 

        buttons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active"); 

        const file = btn.getAttribute("data-file"); 

        fetch(file)
        .then(res => res.text())
        .then(data => {
            contentBox.innerHTML = data; 

            // 👇 Tree init karna zaroori hai
            if (file.includes("tree")) {
                initTree();
            }
        }); 

    });
});
document.addEventListener("change", function(e){

    if(e.target && e.target.id === "uploadProfile"){

        let file = e.target.files[0];

        let formData = new FormData();
        formData.append("profile", file);

        fetch("/karobarsystem/pages/ajax/upload_profile.php", {
            method: "POST",
            body: formData
        })
        .then(res => res.text())
        .then(data => {
            alert(data);
            location.reload();
        });
    }

});