// Dropdown toggle (future mobile support)
document.querySelectorAll(".dropdown").forEach(item => {
  item.addEventListener("click", function (e) {
    e.stopPropagation();
    this.classList.toggle("active");
  });
});
const menu = document.getElementById("mobile-menu");
const nav = document.querySelector(".nav-links");

menu.addEventListener("click", function(){

nav.classList.toggle("active");

});
// Click sound on buttons/links
const clickSound = document.getElementById("click-sound");
document.querySelectorAll("a, button, .button").forEach(element => {
  element.addEventListener("click", () => {
    clickSound.currentTime = 0;
    clickSound.play();
  });
});
function buyProduct(id){
    window.location.href = "product_checkout.php?id=" + id;
}