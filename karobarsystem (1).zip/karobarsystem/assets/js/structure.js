$(document).ready(function () {

    // 🔹 Load dashboard on click
    $(document).on("click", ".dashboard-btn", function () {

        let page = $(this).data("page");

        $("#main-content").load("/karobarsystem/pages/" + page);

        // Optional: hide selection after click
        $(".category-wrapper").hide();
    });

});