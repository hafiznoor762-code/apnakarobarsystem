<?php

function placeUserInNetwork($conn, $user_id, $upliner_id)
{
    // Already exists check

    $check = $conn->prepare("
        SELECT id
        FROM network_tree
        WHERE user_id = ?
    ");

    $check->execute([$user_id]);

    if ($check->fetch()) {
        return false;
    }

    // User category

    $cat = $conn->prepare("
        SELECT category
        FROM users
        WHERE id = ?
    ");

    $cat->execute([$user_id]);

    $category = $cat->fetchColumn();

    if (!$category) {
        $category = 'buyer';
    }

    /*
    ==========================================
    CHECK:
    Kya upliner khud kisi branch ka member hai?
    ==========================================
    */

    $branchCheck = $conn->prepare("
        SELECT branch_no, branch_owner_id
        FROM network_tree
        WHERE user_id = ?
        LIMIT 1
    ");

    $branchCheck->execute([$upliner_id]);

    $parentBranch = $branchCheck->fetch(PDO::FETCH_ASSOC);

    if ($parentBranch) {

        // Existing branch inherit karo

        $branch_no = $parentBranch['branch_no'];
        $branch_owner_id = $parentBranch['branch_owner_id'];

    } else {

        // Root upliner ke niche new branch create hogi

        $nextBranch = $conn->prepare("
            SELECT MAX(branch_no)
            FROM network_tree
            WHERE upliner_id = ?
        ");

        $nextBranch->execute([$upliner_id]);

        $branch_no = $nextBranch->fetchColumn();
        $branch_no = $branch_no ? ($branch_no + 1) : 1;

        $branch_owner_id = $user_id;
    }

    // Insert network row

    $insert = $conn->prepare("
        INSERT INTO network_tree
        (
            user_id,
            upliner_id,
            position,
            branch_no,
            category,
            branch_owner_id,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            'right',
            ?,
            ?,
            ?,
            NOW()
        )
    ");

    $insert->execute([
        $user_id,
        $upliner_id,
        $branch_no,
        $category,
        $branch_owner_id
    ]);

    return true;
}