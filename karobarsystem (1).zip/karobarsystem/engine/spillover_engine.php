<?php

require_once __DIR__ . '/comission_engine.php';

/*
==========================================================
SPILLOVER / INDIRECT COMMISSION LOGIC (BRANCH-FREE, PRODUCT-BASED)
==========================================================
Chain ka formula bilkul wahi hai:

  A refers B, B refers C
      -> C, A ka INDIRECT hai (B ke through aaya)
      -> A ko indirect commission milegi
      -> Cap: sirf B ke pehle 5 referrals tak

Farq sirf itna hai: amount ab fixed 200/50 nahi — jis
product ki wajah se C activate hua, usi product ki
indirect_commission_buyer / indirect_commission_reseller
(A ki apni category ke hisaab se) use hoti hai.
*/
function handleSpillover($conn, $new_user_id)
{
    // Naye user ka seedha (direct) upliner nikaalo
    $stmt = $conn->prepare("
        SELECT upliner_id
        FROM network_tree
        WHERE user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$new_user_id]);
    $parent_id = $stmt->fetchColumn();

    if (!$parent_id) {
        return;
    }

    // Parent ke ab tak kitne total direct referrals hain (isi naye user samet)
    $countStmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE upliner_id = ?
    ");
    $countStmt->execute([$parent_id]);
    $directCount = (int) $countStmt->fetchColumn();

    // Sirf parent ke pehle 5 referrals hi upar wale ko indirect trigger karte hain
    if ($directCount < 1 || $directCount > 5) {
        return;
    }

    // Grandparent = parent ka apna upliner
    $gpStmt = $conn->prepare("
        SELECT upliner_id
        FROM network_tree
        WHERE user_id = ?
        LIMIT 1
    ");
    $gpStmt->execute([$parent_id]);
    $grandparent_id = $gpStmt->fetchColumn();

    if (!$grandparent_id) {
        return;
    }

    // Grandparent ki apni category (buyer/reseller) maloom karo
    $catStmt = $conn->prepare("SELECT category FROM users WHERE id = ?");
    $catStmt->execute([$grandparent_id]);
    $category = strtolower(trim((string) $catStmt->fetchColumn()));

    // Naye user (C) ne jo product khareeda, uski indirect commission values nikaalo
    $prodStmt = $conn->prepare("
        SELECT p.indirect_commission_buyer, p.indirect_commission_reseller
        FROM users u
        INNER JOIN products p ON p.pin = u.product_code
        WHERE u.id = ?
        LIMIT 1
    ");
    $prodStmt->execute([$new_user_id]);
    $product = $prodStmt->fetch(PDO::FETCH_ASSOC);

    // Agar product hi nahi mila (jaise reseller ka free signup, koi product nahi)
    // to indirect commission nahi banti — is case ko chhua nahi gaya
    if (!$product) {
        return;
    }

    $amount = ($category === 'buyer')
        ? (int) $product['indirect_commission_buyer']
        : (int) $product['indirect_commission_reseller'];

    giveIndirectCommission(
        $conn,
        $grandparent_id,
        $new_user_id,
        $amount
    );
}
