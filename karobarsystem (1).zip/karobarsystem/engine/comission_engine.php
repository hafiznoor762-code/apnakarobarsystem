<?php

/*
==========================================================
DIRECT COMMISSION
==========================================================
Ab amount hardcoded nahi — jo bhi product khareeda gaya
uski apni "direct_commission" value yahan pass ki jati hai.

$user_id        = kis ko commission milegi (direct upliner)
$source_user_id = kis naye user ki wajah se mili (buyer/naya member)
$amount         = us product ki direct commission (products table se)
*/
function giveDirectCommission($conn, $user_id, $source_user_id, $amount)
{
    $amount = (int) $amount;

    if ($amount <= 0) {
        return false;
    }

    $insert = $conn->prepare("
        INSERT INTO user_earnings
        (user_id, source_user_id, amount, type, created_at)
        VALUES (?, ?, ?, 'direct_bonus', NOW())
    ");

    $insert->execute([$user_id, $source_user_id, $amount]);

    return true;
}


/*
==========================================================
INDIRECT COMMISSION
==========================================================
Ye us user ko milti hai jiske DIRECT referral ne khud kisi
aur ko refer/activate kiya ho (ek level upar wale ko).

Amount ab bhi recipient ki category (buyer/reseller) ke
hisaab se alag hota hai — lekin ab wo value products table
se aati hai (har product ki apni buyer/reseller indirect
commission), fixed 200/50 ki jagah. Caller (spillover_engine)
sahi amount nikaal kar yahan pass karta hai.

$user_id        = kis ko indirect commission milegi
$source_user_id = kis naye user (grandchild) ki wajah se mili
$amount         = us product ki indirect commission (category ke hisaab se)
*/
function giveIndirectCommission($conn, $user_id, $source_user_id, $amount)
{
    $amount = (int) $amount;

    if ($amount <= 0) {
        return false;
    }

    $insert = $conn->prepare("
        INSERT INTO user_earnings
        (user_id, source_user_id, amount, type, created_at)
        VALUES (?, ?, ?, 'indirect_bonus', NOW())
    ");

    $insert->execute([$user_id, $source_user_id, $amount]);

    return true;
}
