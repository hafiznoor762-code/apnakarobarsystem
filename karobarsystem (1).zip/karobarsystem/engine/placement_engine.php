<?php

/*
==========================================================
PLACEMENT ENGINE (SIMPLE DIRECT REFERRAL CHAIN)
==========================================================
Koi "branch" concept nahi hai. Har naya user seedha apne
upliner ke niche jata hai — bas itna hi. branch_no /
branch_owner_id columns DB mein maujood hain (isliye insert
mein placeholder value daal rahe hain taake table structure
na tootay), lekin ab koi commission/earning logic un par
depend nahi karti.
*/
function placeUserInNetwork($conn, $user_id, $upliner_id)
{
    // Already exists check
    $check = $conn->prepare("
        SELECT id
        FROM network_tree
        WHERE user_id = ?
    ");

    $check->execute([$user_id]);

    if ($check->fetch()) {
        return false;
    }

    // User category
    $cat = $conn->prepare("
        SELECT category
        FROM users
        WHERE id = ?
    ");

    $cat->execute([$user_id]);

    $category = $cat->fetchColumn();

    if (!$category) {
        $category = 'buyer';
    }

    // Insert network row — seedha upliner ke niche, koi branch split nahi
    $insert = $conn->prepare("
        INSERT INTO network_tree
        (
            user_id,
            upliner_id,
            position,
            branch_no,
            category,
            branch_owner_id,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            'right',
            1,
            ?,
            ?,
            NOW()
        )
    ");

    $insert->execute([
        $user_id,
        $upliner_id,
        $category,
        $upliner_id
    ]);

    return true;
}