<?php

/**
 * Renders the network tree for a given parent (upliner) as nested,
 * collapsible <ul>/<li> markup.
 *
 * Signature is unchanged from the original ( $conn, $parent_id ),
 * so every existing call site (e.g. renderTree($conn, $user_id);)
 * keeps working with zero changes elsewhere.
 *
 * $depth is only used internally for recursion — do not pass it manually.
 */
function renderTree($conn, $parent_id, $depth = 0)
{
    $stmt = $conn->prepare("
        SELECT
            nt.user_id,
            nt.branch_no,
            nt.category,
            nt.branch_owner_id,
            u.full_name,
            u.email
        FROM network_tree nt
        LEFT JOIN users u
            ON u.id = nt.user_id
        WHERE nt.upliner_id = ?
        ORDER BY nt.branch_no ASC, nt.id ASC
    ");

    $stmt->execute([$parent_id]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
        return;
    }

    // Auto-expand only the first two levels by default; deeper branches
    // start collapsed so a large tree doesn't overwhelm the screen.
    $ulClass = $depth >= 2 ? 'tree-ul is-collapsed' : 'tree-ul';

    echo "<ul class='{$ulClass}'>";

    foreach ($rows as $row) {

        $name     = $row['full_name'] ?: 'Unknown';
        $email    = $row['email'] ?: '';
        $category = strtolower($row['category'] ?: 'member');
        $initial  = strtoupper(substr($name, 0, 1));
        $searchKey = strtolower($name . ' ' . $email);

        // Render this node's children first (into a buffer) so we know
        // up front whether it has any — that decides if we print a
        // toggle button or a plain spacer.
        ob_start();
        renderTree($conn, $row['user_id'], $depth + 1);
        $childrenHtml = ob_get_clean();
        $hasChildren  = trim($childrenHtml) !== '';

        echo "<li class='tree-node" . ($hasChildren ? '' : ' leaf') . "' data-search='" . htmlspecialchars($searchKey) . "'>";

        echo "<div class='node-row'>";

        if ($hasChildren) {
            echo "<button type='button' class='toggle-btn' aria-label='Toggle branch'><i class='fas fa-chevron-down'></i></button>";
        } else {
            echo "<span class='toggle-spacer'></span>";
        }

        echo "
        <div class='card tree-card cat-{$category}'>
            <div class='avatar-chip'>" . htmlspecialchars($initial) . "</div>
            <div class='card-info'>
                <strong>" . htmlspecialchars($name) . "</strong>
                <small>" . htmlspecialchars($email) . "</small>
            </div>
            <div class='card-tags'>
                <span class='cat-pill'>" . htmlspecialchars(ucfirst($category)) . "</span>
                <span class='branch-tag'>Branch #" . htmlspecialchars($row['branch_no']) . "</span>
            </div>
        </div>
        ";

        echo "</div>"; // .node-row

        echo $childrenHtml;

        echo "</li>";
    }

    echo "</ul>";
}
