<?php

/*
==========================================================
DIRECT COMMISSION
==========================================================
Jab koi naya user (buyer/reseller) activate hota hai,
uska seedha (direct) upliner 400 kamata hai — category
chahe koi bhi ho (Buyer=400, Reseller=400, dono same).

$user_id        = kis ko commission milegi (direct upliner)
$source_user_id = kis naye user ki wajah se mili (buyer/naya member)
*/
function giveDirectCommission($conn, $user_id, $source_user_id)
{
    $stmt = $conn->prepare("
        SELECT category
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $category = $stmt->fetchColumn();

    if (!$category) {
        return false;
    }

    // Direct commission
    // Buyer = 400
    // Reseller = 400

    $amount = 400;

    $insert = $conn->prepare("
        INSERT INTO user_earnings
        (user_id, source_user_id, amount, type, created_at)
        VALUES (?, ?, ?, 'direct_bonus', NOW())
    ");

    $insert->execute([$user_id, $source_user_id, $amount]);

    return true;
}


/*
==========================================================
INDIRECT COMMISSION
==========================================================
Ye us user ko milti hai jiske DIRECT referral ne khud kisi
aur ko refer/activate kiya ho (ek level upar wale ko).

Amount recipient ki apni category pe depend karta hai:
    Buyer    = 200
    Reseller = 50

$user_id        = kis ko indirect commission milegi
$source_user_id = kis naye user (grandchild) ki wajah se mili
*/
function giveIndirectCommission($conn, $user_id, $source_user_id)
{
    $stmt = $conn->prepare("
        SELECT category
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $category = $stmt->fetchColumn();

    if (!$category) {
        return false;
    }

    // Trim + lowercase taake extra space / capital letters
    // ki wajah se match fail na ho
    $category = strtolower(trim($category));

    /*
    Buyer    = 200
    Reseller = 50
    */

    if ($category === 'buyer') {
        $amount = 200;
    } elseif ($category === 'reseller') {
        $amount = 50;
    } else {
        error_log("giveIndirectCommission FAILED: user_id=$user_id, category='$category'");
        return false;
    }

    $insert = $conn->prepare("
        INSERT INTO user_earnings
        (user_id, source_user_id, amount, type, created_at)
        VALUES (?, ?, ?, 'indirect_bonus', NOW())
    ");

    $insert->execute([$user_id, $source_user_id, $amount]);

    return true;
}