<?php

function countBranches($conn, $user_id)
{
    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE upliner_id = ?
    ");

    $stmt->execute([$user_id]);

    return (int)$stmt->fetchColumn();
}

function countDirectTeam($conn, $user_id)
{
    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE upliner_id = ?
    ");

    $stmt->execute([$user_id]);

    return (int)$stmt->fetchColumn();
}

function countIndirectTeam($conn, $user_id)
{
    // Indirect team = wo log jo aapki direct team ke
    // kisi member ke through (upliner_id chain) join hue

    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE upliner_id IN
        (
            SELECT user_id
            FROM network_tree
            WHERE upliner_id = ?
        )
    ");

    $stmt->execute([$user_id]);

    return (int)$stmt->fetchColumn();
}

function countBuyerBranches($conn, $user_id)
{
    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE upliner_id = ?
        AND category='buyer'
    ");

    $stmt->execute([$user_id]);

    return (int)$stmt->fetchColumn();
}

function countResellerBranches($conn, $user_id)
{
    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE upliner_id = ?
        AND category='reseller'
    ");

    $stmt->execute([$user_id]);

    return (int)$stmt->fetchColumn();
}
