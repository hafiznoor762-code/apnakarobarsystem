<?php

require_once __DIR__ . '/comission_engine.php';

function handleSpillover($conn, $new_user_id)
{
    // New user ki tree entry

    $stmt = $conn->prepare("
        SELECT
            upliner_id,
            branch_owner_id
        FROM network_tree
        WHERE user_id = ?
        LIMIT 1
    ");

    $stmt->execute([$new_user_id]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return;
    }

    $branch_owner_id = $row['branch_owner_id'];

    // Branch owner khud count nahi hoga

    $countStmt = $conn->prepare("
        SELECT COUNT(*)
        FROM network_tree
        WHERE branch_owner_id = ?
        AND user_id != ?
    ");

    $countStmt->execute([
        $branch_owner_id,
        $branch_owner_id
    ]);

    $memberCount = (int)$countStmt->fetchColumn();

    // Sirf first 5 indirect members

    if ($memberCount < 1 || $memberCount > 5) {
        return;
    }

    // Branch owner ka upliner nikalo

    $parentStmt = $conn->prepare("
        SELECT upliner_id
        FROM network_tree
        WHERE user_id = ?
        LIMIT 1
    ");

    $parentStmt->execute([$branch_owner_id]);

    $main_upliner = $parentStmt->fetchColumn();

    if (!$main_upliner) {
        return;
    }

    // Indirect commission

    giveIndirectCommission(
        $conn,
        $main_upliner
    );
}