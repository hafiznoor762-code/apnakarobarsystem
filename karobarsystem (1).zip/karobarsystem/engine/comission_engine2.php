<?php

function giveDirectCommission($conn, $user_id)
{
    // User category check

    $stmt = $conn->prepare("
        SELECT category
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $category = $stmt->fetchColumn();

    if (!$category) {
        return false;
    }

    // Direct commission
    // Buyer = 400
    // Reseller = 400

    $amount = 400;

    $insert = $conn->prepare("
        INSERT INTO user_earnings
        (
            user_id,
            amount,
            type,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            'direct_bonus',
            NOW()
        )
    ");

    $insert->execute([
        $user_id,
        $amount
    ]);

    return true;
}


function giveIndirectCommission($conn, $user_id)
{
    // Upliner category

    $stmt = $conn->prepare("
        SELECT category
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $category = $stmt->fetchColumn();

    if (!$category) {
        return false;
    }

    /*
    Buyer    = 200
    Reseller = 50
    */

    if ($category === 'buyer') {

        $amount = 200;

    } elseif ($category === 'reseller') {

        $amount = 50;

    } else {

        return false;
    }

    $insert = $conn->prepare("
        INSERT INTO user_earnings
        (
            user_id,
            amount,
            type,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            'indirect_bonus',
            NOW()
        )
    ");

    $insert->execute([
        $user_id,
        $amount
    ]);

    return true;
}