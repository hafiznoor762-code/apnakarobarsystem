<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/config/db.php';

// Login check
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?page=login");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("SELECT profile_image FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$username = htmlspecialchars(
    $_SESSION['user_name'] ?? $_SESSION['full_name'] ?? 'User',
    ENT_QUOTES,
    'UTF-8'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karobar System – Reseller Dashboard</title>

    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="/karobarsystem/assets/css/dashboards.css/reseller.css?v=<?php echo time(); ?>">
</head>
<body>

    <!-- SIDEBAR OVERLAY (mobile) -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ========== SIDEBAR ========== -->
    <aside class="sidebar" id="sidebar">
        <!-- Brand -->
        <div class="sidebar-brand">
            <img class="brand-logo" src="/karobarsystem/assets/images/logo.png" alt="Apna Karobar System">
            <div class="brand-text">
                Apna Karobar
                <span>Reseller Panel</span>
            </div>
        </div>

        <!-- Navigation (same items, same order, same data-file paths — unchanged) -->
        <nav class="sidebar-nav">
            <!-- Main -->
            <div class="nav-section">
                <div class="nav-section-title">Main</div>
                <ul>
                    <li class="nav-item active" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_account.php">
                        <i class="fas fa-th-large"></i> MY RESELLER ACCOUNT
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_treeview.php">
                        <i class="fas fa-globe"></i> ALL CUSTOMERS TREE
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_orders.php">
                        <i class="fas fa-tag"></i> ORDERS MY CUSTOMERS
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_databases.php">
                        <i class="fas fa-database"></i> Databases
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_hosting.php">
                        <i class="fas fa-server"></i> Hosting
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_emails.php">
                        <i class="fas fa-envelope"></i> Emails
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_ssl.php">
                        <i class="fas fa-lock"></i> SSL Certificates
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_filemanager.php">
                        <i class="fas fa-folder"></i> File Manager
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_backups.php">
                        <i class="fas fa-archive"></i> Backups
                    </li>
                </ul>
            </div>

            <!-- Billing -->
            <div class="nav-section">
                <div class="nav-section-title">Billing</div>
                <ul>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_invoices.php">
                        <i class="fas fa-file-invoice"></i> Invoices
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_payments.php">
                        <i class="fas fa-credit-card"></i> Payments
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_subscriptions.php">
                        <i class="fas fa-repeat"></i> Subscriptions
                    </li>
                </ul>
            </div>

            <!-- Support -->
            <div class="nav-section">
                <div class="nav-section-title">Support</div>
                <ul>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_tickets.php">
                        <i class="fas fa-ticket-alt"></i> Support Tickets
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_knowledge.php">
                        <i class="fas fa-book"></i> Knowledge Base
                    </li>
                </ul>
            </div>

            <!-- Account -->
            <div class="nav-section">
                <div class="nav-section-title">Account</div>
                <ul>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_settings.php">
                        <i class="fas fa-sliders-h"></i> Settings
                    </li>
                    <li class="nav-item" data-file="/karobarsystem/pages/ajax/reseller/pages/reseller_profile.php">
                        <i class="fas fa-user"></i> Profile
                    </li>
                </ul>
            </div>
        </nav>
    </aside>

    <!-- ========== MAIN CONTENT ========== -->
    <main class="main-content">

        <!-- Top Bar (slim) -->
        <div class="top-bar">
            <div class="top-bar-left">
                <button class="hamburger" id="hamburgerBtn" aria-label="Toggle sidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="greeting">
                    Welcome back, <span class="user-name"><?php echo $username; ?></span> 👋
                    <span class="sub-text">Here's what's happening with your reseller business today.</span>
                </div>
            </div>
            <div class="top-bar-right">
                <button class="notification-btn" id="notifBtn" aria-label="Notifications">
                    <i class="fas fa-bell"></i>
                    <span class="badge">3</span>
                </button>
                <form id="profileUploadForm" style="display:none;" enctype="multipart/form-data">
                    <input type="file" name="profile_image" id="profileImageInput" accept="image/*">
                </form>
                <label for="profileImageInput" class="avatar-label" id="avatarLabel" title="Change profile picture">
                    <?php
                    $profileImg = '/karobarsystem/uploads/' . ($user['profile_image'] ?? 'default.png');
                    if (!empty($user['profile_image']) && file_exists($_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/uploads/' . $user['profile_image'])) {
                        echo '<img src="' . $profileImg . '?v=' . time() . '" alt="Profile">';
                    } else {
                        $initial = strtoupper(substr($username, 0, 1));
                        echo '<div class="avatar-placeholder">' . $initial . '</div>';
                    }
                    ?>
                </label>
            </div>
        </div>

        <div class="content-wrap">

            <!-- ===== CONTENT BOX (dynamic) ===== -->
            <div id="contentBox">
                <!-- Loader (shown while fetching) -->
                <div class="content-loader" id="loaderIndicator">
                    <div class="spinner"></div>
                    <span>Loading...</span>
                </div>
                <!-- Actual content will be injected here -->
                <div id="pageContent"></div>
            </div>

            <!-- ===== PRODUCTS (static — stays visible under every dashboard section) ===== -->
            <section class="dash-products">
                <div class="dash-products-head">
                    <div>
                        <div class="eyebrow">Marketplace</div>
                        <h3>Ye Products Abhi Se Resell Karein</h3>
                    </div>
                    <a href="/karobarsystem/index.php?page=products" class="dash-view-all">
                        View All Products <i class="fas fa-arrow-right" style="font-size:11px;"></i>
                    </a>
                </div>

                <div class="dash-products-rail" id="dashProductsRail">
                    <!-- PHP note: replace this static block with your products foreach loop -->
                    <div class="dash-product-card">
                        <img src="/karobarsystem/assets/images/sample1.jpg" alt="Product">
                        <div class="body">
                            <h4>Wireless Earbuds Pro</h4>
                            <span class="price">Rs 3,499</span>
                        </div>
                    </div>
                    <div class="dash-product-card">
                        <img src="/karobarsystem/assets/images/sample2.jpg" alt="Product">
                        <div class="body">
                            <h4>Smart Fitness Band</h4>
                            <span class="price">Rs 2,199</span>
                        </div>
                    </div>
                    <div class="dash-product-card">
                        <img src="/karobarsystem/assets/images/sample3.jpg" alt="Product">
                        <div class="body">
                            <h4>Portable Speaker</h4>
                            <span class="price">Rs 4,999</span>
                        </div>
                    </div>
                    <div class="dash-product-card">
                        <img src="/karobarsystem/assets/images/sample4.jpg" alt="Product">
                        <div class="body">
                            <h4>Leather Wallet</h4>
                            <span class="price">Rs 1,299</span>
                        </div>
                    </div>
                    <div class="dash-product-card">
                        <img src="/karobarsystem/assets/images/sample5.jpg" alt="Product">
                        <div class="body">
                            <h4>Kitchen Organizer Set</h4>
                            <span class="price">Rs 1,899</span>
                        </div>
                    </div>
                </div>
            </section>

        </div>

    </main>

    <script>
        (function() {
            'use strict';

            // ============================================================
            // 1. SIDEBAR TOGGLE (mobile)
            // ============================================================
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            const hamburger = document.getElementById('hamburgerBtn');

            function openSidebar() {
                sidebar.classList.add('open');
                overlay.classList.add('active');
                document.body.style.overflow = 'hidden';
            }

            function closeSidebar() {
                sidebar.classList.remove('open');
                overlay.classList.remove('active');
                document.body.style.overflow = '';
            }

            if (hamburger) {
                hamburger.addEventListener('click', function(e) {
                    e.stopPropagation();
                    sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
                });
            }

            if (overlay) {
                overlay.addEventListener('click', closeSidebar);
            }

            window.addEventListener('resize', function() {
                if (window.innerWidth > 768 && sidebar.classList.contains('open')) {
                    closeSidebar();
                }
            });

            // ============================================================
            // 2. NAVIGATION — using data-file with fetch()
            // ============================================================
            const contentBox = document.getElementById('contentBox');
            const pageContent = document.getElementById('pageContent');
            const loaderIndicator = document.getElementById('loaderIndicator');
            const navItems = document.querySelectorAll('.sidebar-nav .nav-item');

            // Default file (overview)
            const DEFAULT_FILE = '/karobarsystem/pages/ajax/reseller/pages/reseller_overview.php';
            let currentFile = DEFAULT_FILE;

            function loadPage(fileUrl) {
                if (!fileUrl) fileUrl = DEFAULT_FILE;

                // Show loader
                loaderIndicator.style.display = 'flex';
                pageContent.style.display = 'none';
                pageContent.innerHTML = '';

                // Update active nav item
                navItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('data-file') === fileUrl) {
                        item.classList.add('active');
                    }
                });

                // Fetch content using fetch() — pure JS, no jQuery needed
                fetch(fileUrl)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('HTTP ' + response.status + ' ' + response.statusText);
                        }
                        return response.text();
                    })
                    .then(html => {
                        loaderIndicator.style.display = 'none';
                        pageContent.style.display = 'block';
                        pageContent.innerHTML = html;
                        currentFile = fileUrl;

                        // Close sidebar on mobile after navigation
                        if (window.innerWidth <= 768) {
                            closeSidebar();
                        }

                        // 🔁 Re-init tree if the loaded file is treeview
                        if (fileUrl.includes('treeview')) {
                            if (typeof initTree === 'function') {
                                initTree();
                            }
                        }

                        // 🔁 Call custom init hook if defined
                        if (typeof initLoadedContent === 'function') {
                            initLoadedContent();
                        }

                        console.log('✅ Loaded: ' + fileUrl);
                    })
                    .catch(error => {
                        loaderIndicator.style.display = 'none';
                        pageContent.style.display = 'block';
                        pageContent.innerHTML = `
                            <div class="error-box">
                                <i class="fas fa-exclamation-circle"></i>
                                <h3>Failed to load content</h3>
                                <p>${error.message}</p>
                                <button class="retry-btn" onclick="location.reload()">Retry</button>
                            </div>
                        `;
                        console.error('❌ Fetch error:', error);
                    });
            }

            // Click handler for nav items
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    const file = this.getAttribute('data-file');
                    if (file && file !== currentFile) {
                        loadPage(file);
                    } else if (file === currentFile) {
                        // Same page — just close sidebar on mobile
                        if (window.innerWidth <= 768) {
                            closeSidebar();
                        }
                    }
                });
            });

            // ============================================================
            // 3. LOAD DEFAULT PAGE ON START
            // ============================================================
            loaderIndicator.style.display = 'flex';
            pageContent.style.display = 'none';

            // Small delay to ensure DOM is ready
            setTimeout(function() {
                loadPage(DEFAULT_FILE);
            }, 80);

            // ============================================================
            // 4. NOTIFICATION BUTTON
            // ============================================================
            const notifBtn = document.getElementById('notifBtn');
            if (notifBtn) {
                notifBtn.addEventListener('click', function() {
                    alert('🔔 You have 3 new notifications.');
                });
            }

            // ============================================================
            // 5. PROFILE IMAGE UPLOAD (using fetch + FormData)
            // ============================================================
            const profileInput = document.getElementById('profileImageInput');
            if (profileInput) {
                profileInput.addEventListener('change', function(e) {
                    const file = this.files[0];
                    if (!file) return;

                    const formData = new FormData();
                    formData.append('profile', file); // matching your original PHP

                    const label = document.getElementById('avatarLabel');
                    const originalHtml = label.innerHTML;
                    label.innerHTML = '<div class="avatar-placeholder" style="font-size:12px;">⏳</div>';

                    fetch('/karobarsystem/pages/ajax/upload_profile.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.text())
                        .then(data => {
                            try {
                                const parsed = JSON.parse(data);
                                if (parsed.success && parsed.image) {
                                    // Update avatar
                                    const img = document.createElement('img');
                                    img.src = '/karobarsystem/uploads/' + parsed.image + '?v=' +
                                        Date.now();
                                    img.alt = 'Profile';
                                    label.innerHTML = '';
                                    label.appendChild(img);
                                    setTimeout(() => location.reload(), 800);
                                } else {
                                    label.innerHTML = originalHtml;
                                    alert(parsed.message || 'Upload failed');
                                }
                            } catch (e) {
                                // If response is plain text (like "success" or error message)
                                label.innerHTML = originalHtml;
                                if (data.trim().toLowerCase() === 'success') {
                                    location.reload();
                                } else {
                                    alert(data || 'Upload failed');
                                }
                            }
                        })
                        .catch(err => {
                            label.innerHTML = originalHtml;
                            alert('Server error: ' + err.message);
                        });
                });
            }

            // ============================================================
            // 6. EXPOSE loadPage GLOBALLY (for use in loaded content)
            // ============================================================
            window.loadPage = loadPage;

            // ============================================================
            // 7. INIT HOOK for loaded content
            // ============================================================
            window.initLoadedContent = function() {
                console.log('🔄 Content loaded: ' + currentFile);
                // You can add custom initialization here
            };

            console.log('🚀 Karobar System Dashboard initialized (data-file mode).');

        })();
    </script>

    <!-- Small standalone script just for the static products rail (does not touch the logic above) -->
    <script>
        (function() {
            const rail = document.getElementById('dashProductsRail');
            if (!rail) return;
            rail.addEventListener('wheel', function(e) {
                if (e.deltaY === 0) return;
                e.preventDefault();
                rail.scrollLeft += e.deltaY;
            }, { passive: false });
        })();
    </script>

</body>
</html>