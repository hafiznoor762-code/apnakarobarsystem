<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

require_once __DIR__ . '/../../../../config/db.php';
require_once __DIR__ . '/../../../../engine/tree_count.php';

if (!isset($_SESSION['user_id'])) {
    echo "<p>⚠️ Please login first.</p>";
    exit;
}

$user_id = (int) $_SESSION['user_id'];

/* Direct customers — jo is user ke referral se join hue */
$stmt = $conn->prepare("
    SELECT u.id, u.full_name, u.email, u.whatsapp, u.category, u.created_at
    FROM network_tree nt
    INNER JOIN users u ON u.id = nt.user_id
    WHERE nt.upliner_id = ?
    ORDER BY nt.id DESC
");
$stmt->execute([$user_id]);
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="section-content">
  <h2>🛍️ My Customers</h2>
  <p>Aapke referral se jo bhi customer join hua hai, uski detail neeche 👇</p>

  <style>
    .cust-table-wrap{background:#fff;border:1px solid var(--line,#e7e9e4);border-radius:16px;overflow:hidden;box-shadow:0 2px 10px rgba(16,20,15,.06);margin-top:14px;}
    .cust-table{width:100%;border-collapse:collapse;font-size:13.5px;}
    .cust-table th{background:var(--paper-soft,#f7f9f6);text-align:left;padding:12px 14px;font-size:11.5px;text-transform:uppercase;letter-spacing:.05em;color:#8a938c;}
    .cust-table td{padding:11px 14px;border-top:1px solid var(--line,#e7e9e4);vertical-align:middle;}
    .cust-name{font-weight:700;color:#10140f;}
    .cust-email{color:#55605a;font-size:12.5px;}
    .cust-wa{display:inline-flex;align-items:center;gap:6px;color:#146b27;font-weight:600;font-size:12.5px;}
    .cust-wa i{color:#2fa83f;}
    .cust-cat{background:#eaf7ea;color:#146b27;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:700;text-transform:capitalize;}
    .cust-team{font-family:"Space Grotesk","IBM Plex Sans",sans-serif;font-weight:700;font-size:15px;color:#10140f;}
    .cust-team span{display:block;font-size:10px;color:#8a938c;font-weight:600;text-transform:uppercase;letter-spacing:.04em;}
    .cust-empty{padding:30px 16px;text-align:center;color:#8a938c;font-size:13.5px;}

    @media (max-width:720px){
      .cust-table, .cust-table thead, .cust-table tbody, .cust-table th, .cust-table td, .cust-table tr{display:block;}
      .cust-table thead{display:none;}
      .cust-table tr{border-bottom:1px solid var(--line,#e7e9e4);padding:12px 14px;}
      .cust-table td{border:none;padding:4px 0;}
      .cust-table td:before{content:attr(data-label);display:block;font-size:10.5px;font-weight:700;text-transform:uppercase;color:#8a938c;margin-bottom:2px;}
    }
  </style>

  <div class="cust-table-wrap">
    <?php if (empty($customers)): ?>
      <div class="cust-empty">Abhi tak koi customer join nahi hua.</div>
    <?php else: ?>
    <table class="cust-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>WhatsApp</th>
          <th>Category</th>
          <th>Their Team</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($customers as $c):
            // Is customer ki apni total team (direct + indirect)
            $c_direct   = countDirectTeam($conn, $c['id']);
            $c_indirect = countIndirectTeam($conn, $c['id']);
            $c_team     = $c_direct + $c_indirect;
        ?>
        <tr>
          <td data-label="Name"><span class="cust-name"><?= htmlspecialchars($c['full_name']) ?></span></td>
          <td data-label="Email"><span class="cust-email"><?= htmlspecialchars($c['email']) ?></span></td>
          <td data-label="WhatsApp">
            <?php if (!empty($c['whatsapp'])): ?>
              <a class="cust-wa" href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $c['whatsapp']) ?>" target="_blank">
                <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($c['whatsapp']) ?>
              </a>
            <?php else: ?>
              <span class="cust-email">—</span>
            <?php endif; ?>
          </td>
          <td data-label="Category"><span class="cust-cat"><?= htmlspecialchars($c['category'] ?: 'buyer') ?></span></td>
          <td data-label="Their Team">
            <span class="cust-team"><?= $c_team ?><span>Members</span></span>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>