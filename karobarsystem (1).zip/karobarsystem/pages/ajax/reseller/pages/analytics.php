<div class="section-content">
  <h2>📈 Analytics</h2>
  <p>View your performance graphs, sales charts, and insights 📊</p>

  <canvas id="salesChart" width="400" height="200"></canvas>

  <script>
  // Example Chart.js usage
  new Chart(document.getElementById('salesChart'), {
    type: 'bar',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr'],
      datasets: [{
        label: 'Sales',
        data: [12, 19, 3, 5]
      }]
    }
  });
  </script>
</div>