<div class="section-content">
  <h2>💼 My Earning Plan</h2>
  <p>Track your direct and indirect earnings easily 💸</p>

  <ul class="earning-list">
    <li>Direct Sale Commission: Rs.150</li>
    <li>Indirect Sale Commission: Rs.100</li>
    <li>Total Earnings (Current Month): Rs.10,500</li>
  </ul>
</div>