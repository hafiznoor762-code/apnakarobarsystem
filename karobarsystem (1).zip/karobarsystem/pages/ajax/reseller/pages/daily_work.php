<div class="section-content">
  <h2>📝 Daily Work Details</h2>
  <p>Log your daily sales and customer activities below 👇</p>

  <form>
    <label>Task Completed:</label>
    <input type="text" placeholder="e.g., Sold 2 Smart Watches">
    <label>Remarks:</label>
    <textarea placeholder="Any additional comments..."></textarea>
    <button class="btn">Submit Work Log</button>
  </form>
</div>