<?php
session_start();
require_once __DIR__ . '/../../../config/db.php';

// ================= ADMIN ACCESS CHECK =================
// Sirf yahi email admin panel access kar sakti hai
// (existing admin_users.php mein bhi yehi email use hoti hai)
$ADMIN_EMAIL = 'hafiznoor762@gmail.com';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../../index.php?page=login");
    exit;
}

$meStmt = $conn->prepare("SELECT email FROM users WHERE id = ?");
$meStmt->execute([$_SESSION['user_id']]);
$myEmail = $meStmt->fetchColumn();

if ($myEmail !== $ADMIN_EMAIL) {
    die("Access denied! Ye page sirf admin ke liye hai.");
}

$msg = '';
$msgType = '';

// ================= HANDLE ADD / EDIT / DELETE =================

// DELETE
if (isset($_GET['delete'])) {
    $delId = (int) $_GET['delete'];
    $conn->prepare("DELETE FROM products WHERE id = ?")->execute([$delId]);
    header("Location: admin_product.php?msg=deleted");
    exit;
}

// ADD or UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name        = trim($_POST['name'] ?? '');
    $price       = (float) ($_POST['price'] ?? 0);
    $pin         = trim($_POST['pin'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $editId      = (int) ($_POST['edit_id'] ?? 0);

    if ($name === '' || $pin === '' || $price <= 0) {
        $msg = 'Naam, price aur PIN zaroori hain.';
        $msgType = 'danger';
    } else {

        // Duplicate PIN check (excluding the product being edited)
        $dupStmt = $conn->prepare("SELECT id FROM products WHERE pin = ? AND id != ?");
        $dupStmt->execute([$pin, $editId]);
        if ($dupStmt->fetch()) {
            $msg = 'Ye PIN pehle se kisi aur product par lagi hui hai — alag PIN dein.';
            $msgType = 'danger';
        } else {

            // Image upload (optional on edit — keeps old image if none uploaded)
            $imageName = null;
            if (!empty($_FILES['image']['name'])) {
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
                if (in_array($ext, $allowed, true)) {
                    $imageName = 'prod_' . time() . '_' . rand(100, 999) . '.' . $ext;
                    $destDir = $_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/assets/images/';
                    if (!is_dir($destDir)) {
                        mkdir($destDir, 0755, true);
                    }
                    move_uploaded_file($_FILES['image']['tmp_name'], $destDir . $imageName);
                } else {
                    $msg = 'Sirf jpg, jpeg, png, webp, gif images allowed hain.';
                    $msgType = 'danger';
                }
            }

            if ($msgType !== 'danger') {
                if ($editId > 0) {
                    // UPDATE
                    if ($imageName) {
                        $upd = $conn->prepare("UPDATE products SET name=?, price=?, pin=?, description=?, image=? WHERE id=?");
                        $upd->execute([$name, $price, $pin, $description, $imageName, $editId]);
                    } else {
                        $upd = $conn->prepare("UPDATE products SET name=?, price=?, pin=?, description=? WHERE id=?");
                        $upd->execute([$name, $price, $pin, $description, $editId]);
                    }
                    $msg = 'Product update ho gaya.';
                    $msgType = 'success';
                } else {
                    // ADD
                    $ins = $conn->prepare("INSERT INTO products (name, price, pin, description, image) VALUES (?,?,?,?,?)");
                    $ins->execute([$name, $price, $pin, $description, $imageName ?? '']);
                    $msg = 'Naya product add ho gaya.';
                    $msgType = 'success';
                }
            }
        }
    }
}

if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $msg = 'Product delete ho gaya.';
    $msgType = 'success';
}

// Product being edited (if any)
$editProduct = null;
if (isset($_GET['edit'])) {
    $eStmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $eStmt->execute([(int) $_GET['edit']]);
    $editProduct = $eStmt->fetch(PDO::FETCH_ASSOC);
}

$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Admin – Products';
$active = 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin – Products – Apna Karobar System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="products_style.css?v=<?php echo time(); ?>">
</head>
<body style="padding-bottom:30px;">

<header class="bg-white shadow-sm py-3 mb-4">
<div class="container">
<h2 class="fw-bold text-primary m-0">
    <i class="fa-solid fa-screwdriver-wrench"></i>
    Apna<span class="text-dark">Karobar</span> — Admin Panel
</h2>
</div>
</header>

<div class="container">

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="row g-4">

    <!-- ADD / EDIT FORM -->
    <div class="col-lg-4">
        <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="fw-bold mb-3">
                <?= $editProduct ? 'Edit Product' : 'Add New Product' ?>
            </h5>

            <form method="post" enctype="multipart/form-data">
                <?php if ($editProduct): ?>
                    <input type="hidden" name="edit_id" value="<?= (int)$editProduct['id'] ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="name" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Price (Rs.)</label>
                    <input type="number" step="0.01" name="price" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['price'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Product PIN</label>
                    <input type="text" name="pin" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['pin'] ?? '') ?>">
                    <div class="form-text">Ye wahi PIN hai jo buyer registration ke waqt verify hoti hai.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Product Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php if (!empty($editProduct['image'])): ?>
                        <img src="/karobarsystem/assets/images/<?= htmlspecialchars($editProduct['image']) ?>" style="max-width:100px;margin-top:8px;border-radius:8px;">
                        <div class="form-text">Khali chor dein agar image change nahi karni.</div>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    <?= $editProduct ? 'Update Product' : 'Add Product' ?>
                </button>

                <?php if ($editProduct): ?>
                    <a href="admin_product.php" class="btn btn-outline-secondary w-100 mt-2">Cancel Edit</a>
                <?php endif; ?>
            </form>
        </div>
        </div>
    </div>

    <!-- PRODUCT LIST -->
    <div class="col-lg-8">
        <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="fw-bold mb-3">All Products (<?= count($products) ?>)</h5>

            <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>PIN</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>
                        <?php if (!empty($p['image'])): ?>
                        <img src="/karobarsystem/assets/images/<?= htmlspecialchars($p['image']) ?>" style="width:50px;height:50px;object-fit:cover;border-radius:8px;">
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td>Rs. <?= number_format($p['price']) ?></td>
                    <td><code><?= htmlspecialchars($p['pin']) ?></code></td>
                    <td>
                        <a href="admin_product.php?edit=<?= (int)$p['id'] ?>" class="btn btn-sm btn-outline-primary">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <a href="admin_product.php?delete=<?= (int)$p['id'] ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Ye product delete karna hai?');">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                        <a href="details.php?id=<?= (int)$p['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                            <i class="fa-solid fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
    </div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>