<?php
/**
 * Products Listing — Apna Karobar System
 * Design/CSS bilkul same rakha hai, sirf products ko DB se live connect kiya hai.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../../config/db.php';

// Har product uski apni PIN ke saath (jo admin panel se upload karte waqt lagayi jaati hai)
$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    <title>Apna Karobar System – Dashboard</title>

    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        /* ============================================================
           RESET & BASE
           ============================================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
        }

        body {
            background: #f7f9f6;
            color: #10140f;
            padding-bottom: 80px;
            min-height: 100vh;
        }

        a {
            text-decoration: none;
            color: inherit;
        }
        img {
            display: block;
            max-width: 100%;
        }

        /* ============================================================
           HEADER / TOP BAR
           ============================================================ */
        .top-header {
            background: #10140f;
            padding: 14px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 30;
            box-shadow: 0 2px 12px rgba(16,20,15,0.15);
        }

        .top-header .brand {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .top-header .brand i {
            font-size: 28px;
            color: #2fa83f;
        }
        .top-header .brand h1 {
            font-size: 20px;
            font-weight: 700;
            color: #fff;
            letter-spacing: -0.3px;
        }
        .top-header .brand h1 span {
            color: #2fa83f;
        }

        .top-header .header-actions {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #fff;
        }
        .top-header .header-actions i {
            font-size: 20px;
            cursor: pointer;
            transition: 0.2s;
            color: #c7d6c4;
        }
        .top-header .header-actions i:hover {
            color: #2fa83f;
        }

        .avatar-circle {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: linear-gradient(135deg, #2fa83f, #146b27);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 16px;
            color: #fff;
            cursor: pointer;
            border: 2px solid rgba(255,255,255,0.2);
        }

        /* ============================================================
           WELCOME / HERO SECTION
           ============================================================ */
        .welcome-section {
            background: linear-gradient(135deg, #10140f, #146b27);
            padding: 30px 20px 40px;
            text-align: center;
            color: #fff;
            margin-bottom: 20px;
        }
        .welcome-section .greeting {
            font-size: 14px;
            color: #2fa83f;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .welcome-section h2 {
            font-size: 28px;
            font-weight: 700;
            margin: 6px 0 8px;
            line-height: 1.2;
        }
        .welcome-section h2 span {
            color: #2fa83f;
        }
        .welcome-section p {
            font-size: 15px;
            color: #c7d6c4;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* ============================================================
           SECTION TITLE
           ============================================================ */
        .section-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 18px 8px;
        }
        .section-title h3 {
            font-size: 18px;
            font-weight: 700;
            color: #10140f;
        }
        .section-title h3 i {
            color: #2fa83f;
            margin-right: 8px;
        }
        .section-title .view-all {
            font-size: 13px;
            color: #2fa83f;
            font-weight: 600;
        }

        /* ============================================================
           CATEGORIES GRID
           ============================================================ */
        .categories-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            padding: 0 16px 20px;
        }
        .cat-item {
            background: #fff;
            border-radius: 14px;
            padding: 16px 8px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(16,20,15,0.04);
            transition: 0.2s;
            cursor: pointer;
            border: 1px solid #e7e9e4;
        }
        .cat-item:active {
            transform: scale(0.95);
        }
        .cat-item .icon {@
            font-size: 28px;
            margin-bottom: 4px;
        }
        .cat-item .label {
            font-size: 12px;
            font-weight: 500;
            color: #10140f;
        }
        .cat-item.more {
            background: #2fa83f;
            color: #fff;
            border-color: #2fa83f;
        }
        .cat-item.more .label {
            color: #fff;
        }

        /* ============================================================
           TRENDING PRODUCTS
           ============================================================ */
        .trending-scroll {
            display: flex;
            gap: 14px;
            overflow-x: auto;
            padding: 0 16px 20px;
            scrollbar-width: none;
            -webkit-overflow-scrolling: touch;
        }
        .trending-scroll::-webkit-scrollbar {
            display: none;
        }

        .trend-card {
            flex: 0 0 150px;
            background: #fff;
            border-radius: 14px;
            padding: 14px 12px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(16,20,15,0.04);
            border: 1px solid #e7e9e4;
            transition: 0.2s;
            cursor: pointer;
        }
        .trend-card:active {
            transform: scale(0.95);
        }
        .trend-card .discount {
            background: #e74c3c;
            color: #fff;
            font-size: 12px;
            font-weight: 700;
            padding: 2px 12px;
            border-radius: 30px;
            display: inline-block;
        }
        .trend-card .product-img {
            width: 80px;
            height: 80px;
            background: #f7f9f6;
            border-radius: 12px;
            margin: 8px auto;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
        }
        .trend-card .product-name {
            font-size: 13px;
            font-weight: 600;
            margin-top: 4px;
        }
        .trend-card .rating {
            font-size: 12px;
            color: #f39c12;
            margin-top: 2px;
        }
        .trend-card .rating span {
            color: #8a938c;
            margin-left: 4px;
        }
        .trend-card .product-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 12px;
        }
        .trend-card .price-tag {
            font-size: 13px;
            font-weight: 700;
            color: #2fa83f;
            margin-top: 2px;
        }
        .trend-card .pin-tag {
            display: inline-block;
            margin-top: 6px;
            background: #eaf7ea;
            border: 1px dashed #2fa83f;
            color: #146b27;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.4px;
            padding: 3px 10px;
            border-radius: 30px;
        }
        .trend-card .pin-tag i {
            margin-right: 3px;
        }
        .no-products-msg {
            padding: 10px 16px 20px;
            color: #8a938c;
            font-size: 14px;
        }

        /* ============================================================
           STATS & WALLET ROW
           ============================================================ */
        .stats-wallet-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            padding: 0 16px 20px;
        }

        .stats-card {
            background: #fff;
            border-radius: 16px;
            padding: 18px 16px;
            box-shadow: 0 2px 8px rgba(16,20,15,0.04);
            border: 1px solid #e7e9e4;
        }
        .stats-card h4 {
            font-size: 14px;
            color: #8a938c;
            font-weight: 500;
            margin-bottom: 10px;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid #eef1ea;
        }
        .stat-row:last-child {
            border-bottom: none;
        }
        .stat-row .label {
            font-size: 14px;
            color: #55605a;
        }
        .stat-row .value {
            font-size: 14px;
            font-weight: 600;
            color: #10140f;
        }
        .stat-row .value.gold {
            color: #2fa83f;
        }

        .wallet-card {
            background: linear-gradient(135deg, #10140f, #146b27);
            border-radius: 16px;
            padding: 18px 16px;
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            border: none;
        }
        .wallet-card .label {
            font-size: 13px;
            color: #c7d6c4;
        }
        .wallet-card .amount {
            font-size: 28px;
            font-weight: 700;
            margin: 4px 0 6px;
        }
        .wallet-card .amount span {
            font-size: 16px;
            font-weight: 400;
            color: #c7d6c4;
        }
        .wallet-card .action-btn {
            background: #2fa83f;
            color: #10140f;
            border: none;
            padding: 8px 16px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            align-self: flex-start;
            transition: 0.2s;
        }
        .wallet-card .action-btn:hover {
            background: #146b27;
        }

        /* ============================================================
           QUICK LINKS
           ============================================================ */
        .quick-links {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            padding: 0 16px 20px;
        }
        .quick-link {
            background: #fff;
            border-radius: 14px;
            padding: 14px 6px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(16,20,15,0.04);
            border: 1px solid #e7e9e4;
            transition: 0.2s;
            cursor: pointer;
        }
        .quick-link:active {
            transform: scale(0.95);
        }
        .quick-link .icon {
            font-size: 22px;
            color: #2fa83f;
            display: block;
        }
        .quick-link .label {
            font-size: 11px;
            font-weight: 500;
            color: #55605a;
            margin-top: 4px;
            display: block;
        }

        /* ============================================================
           REFERRAL PROGRAM SECTION
           ============================================================ */
        .referral-section {
            background: #fff;
            margin: 0 16px 20px;
            border-radius: 16px;
            padding: 20px 18px;
            box-shadow: 0 2px 8px rgba(16,20,15,0.04);
            border: 1px solid #e7e9e4;
        }
        .referral-section h4 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        .referral-section h4 i {
            color: #2fa83f;
            margin-right: 8px;
        }

        .referral-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }
        .referral-item {
            text-align: center;
            padding: 8px 4px;
            border-radius: 12px;
            background: #eaf7ea;
            cursor: pointer;
            transition: 0.2s;
        }
        .referral-item:active {
            background: #dcf3dc;
        }
        .referral-item .icon {
            font-size: 24px;
            color: #2fa83f;
            display: block;
        }
        .referral-item .label {
            font-size: 12px;
            font-weight: 500;
            color: #55605a;
            margin-top: 2px;
            display: block;
        }

        /* ============================================================
           FEATURES / BENEFITS ROW
           ============================================================ */
        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            padding: 0 16px 20px;
        }
        .benefit-card {
            background: #fff;
            border-radius: 14px;
            padding: 18px 12px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(16,20,15,0.04);
            border: 1px solid #e7e9e4;
            transition: 0.2s;
            cursor: pointer;
        }
        .benefit-card:active {
            transform: scale(0.96);
        }
        .benefit-card .icon {
            font-size: 32px;
            color: #2fa83f;
            display: block;
            margin-bottom: 6px;
        }
        .benefit-card h5 {
            font-size: 14px;
            font-weight: 700;
            color: #10140f;
        }
        .benefit-card p {
            font-size: 12px;
            color: #8a938c;
            margin-top: 2px;
            line-height: 1.4;
        }

        /* ============================================================
           INVITE SECTION
           ============================================================ */
        .invite-section {
            background: linear-gradient(135deg, #2fa83f, #146b27);
            margin: 0 16px 20px;
            border-radius: 16px;
            padding: 24px 20px;
            color: #fff;
            text-align: center;
        }
        .invite-section h3 {
            font-size: 22px;
            font-weight: 700;
        }
        .invite-section p {
            font-size: 14px;
            opacity: 0.9;
            margin: 4px 0 14px;
        }
        .invite-section .invite-btn {
            background: #10140f;
            color: #fff;
            border: none;
            padding: 12px 32px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        .invite-section .invite-btn:hover {
            background: #1c2117;
            transform: scale(1.02);
        }

        /* ============================================================
           BOTTOM NAVIGATION (FIXED)
           ============================================================ */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255,255,255,0.96);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 8px 0 env(safe-area-inset-bottom);
            border-top: 1px solid #e7e9e4;
            box-shadow: 0 -2px 12px rgba(16,20,15,0.06);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 10px;
            color: #8a938c;
            padding: 4px 12px;
            border-radius: 30px;
            transition: 0.2s;
        }
        .bottom-nav .nav-item.active {
            color: #2fa83f;
        }
        .bottom-nav .nav-item .icon {
            font-size: 22px;
            line-height: 1;
        }
        .bottom-nav .nav-item span:last-child {
            margin-top: 2px;
            font-weight: 500;
        }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 480px) {
            .categories-grid {
                grid-template-columns: repeat(4, 1fr);
                gap: 8px;
            }
            .cat-item {
                padding: 12px 4px;
            }
            .cat-item .icon {
                font-size: 22px;
            }
            .cat-item .label {
                font-size: 10px;
            }
            .quick-links {
                grid-template-columns: repeat(3, 1fr);
            }
            .referral-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .benefits-grid {
                grid-template-columns: 1fr 1fr;
            }
            .stats-wallet-row {
                grid-template-columns: 1fr;
            }
            .wallet-card .amount {
                font-size: 24px;
            }
        }

        @media (min-width: 481px) and (max-width: 768px) {
            .categories-grid {
                grid-template-columns: repeat(4, 1fr);
            }
            .quick-links {
                grid-template-columns: repeat(5, 1fr);
            }
            .referral-grid {
                grid-template-columns: repeat(4, 1fr);
            }
            .benefits-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            .stats-wallet-row {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (min-width: 769px) {
            body {
                padding-bottom: 0;
            }
            .bottom-nav {
                display: none;
            }
            .welcome-section {
                padding: 50px 40px 60px;
            }
            .welcome-section h2 {
                font-size: 38px;
            }
            .categories-grid {
                grid-template-columns: repeat(8, 1fr);
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 24px 24px;
            }
            .trending-scroll {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 24px 24px;
            }
            .stats-wallet-row {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 24px 24px;
                grid-template-columns: 1fr 1fr;
            }
            .quick-links {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 24px 24px;
                grid-template-columns: repeat(5, 1fr);
            }
            .referral-section {
                max-width: 1200px;
                margin: 0 auto 24px;
                padding: 24px 28px;
            }
            .benefits-grid {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 24px 32px;
                grid-template-columns: repeat(6, 1fr);
            }
            .invite-section {
                max-width: 1200px;
                margin: 0 auto 32px;
                padding: 32px 40px;
            }
            .section-title {
                max-width: 1200px;
                margin: 0 auto;
                padding: 24px 24px 12px;
            }
            .top-header {
                padding: 16px 40px;
            }
            .top-header .brand h1 {
                font-size: 24px;
            }
        }

        @media (min-width: 1025px) {
            .categories-grid {
                grid-template-columns: repeat(8, 1fr);
            }
            .benefits-grid {
                grid-template-columns: repeat(6, 1fr);
            }
        }

        /* ============================================================
           UTILITY
           ============================================================ */
        .text-gold {
            color: #2fa83f;
        }
        .bg-gold {
            background: #2fa83f;
        }
        .mb-8 {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>

    <!-- ============================================================
    TOP HEADER
    ============================================================ -->
    <header class="top-header">
        <div class="brand">
            <i class="fas fa-store-alt"></i>
            <h1>Aqna<span>Karobar</span></h1>
        </div>
        <div class="header-actions">
            <i class="fas fa-bell"></i>
            <i class="fas fa-envelope"></i>
            <div class="avatar-circle">AK</div>
        </div>
    </header>

    <!-- ============================================================
    WELCOME / HERO
    ============================================================ -->
    <section class="welcome-section">
        <div class="greeting">Welcome to</div>
        <h2>Aqna <span>Karobar System</span></h2>
        <p>
            Shop, Sell &amp; Earn with Confidence<br />
            A complete business solution for Buyers, Resellers, Vendors and Investors.
            Grow your business, earn more and achieve your goals.
        </p>
    </section>

    <!-- ============================================================
    TOP CATEGORIES
    ============================================================ -->
    <div class="section-title">
        <h3><i class="fas fa-th-large"></i> Top Categories</h3>
        <a href="#" class="view-all">See All <i class="fas fa-chevron-right"></i></a>
    </div>
    <div class="categories-grid">
        <div class="cat-item"><div class="icon">📱</div><div class="label">Electronics</div></div>
        <div class="cat-item"><div class="icon">👗</div><div class="label">Fashion</div></div>
        <div class="cat-item"><div class="icon">💄</div><div class="label">Health &amp; Beauty</div></div>
        <div class="cat-item"><div class="icon">🏠</div><div class="label">Home &amp; Kitchen</div></div>
        <div class="cat-item"><div class="icon">📚</div><div class="label">Books &amp; Media</div></div>
        <div class="cat-item"><div class="icon">💻</div><div class="label">Software</div></div>
        <div class="cat-item"><div class="icon">⚽</div><div class="label">Sports</div></div>
        <div class="cat-item more"><div class="icon">➕</div><div class="label">More</div></div>
    </div>

    <!-- ============================================================
    TRENDING PRODUCTS
    ============================================================ -->
    <div class="section-title">
        <h3><i class="fas fa-fire" style="color:#e74c3c;"></i> Trending Products</h3>
        <a href="#" class="view-all">View All <i class="fas fa-chevron-right"></i></a>
    </div>
    <div class="trending-scroll">
        <?php if (empty($products)): ?>
            <p class="no-products-msg">Filhaal koi product available nahi hai.</p>
        <?php else: ?>
            <?php foreach ($products as $p): ?>
            <a href="/karobarsystem/pages/ajax/products/details.php?id=<?= (int)$p['id'] ?>" class="trend-card">
                <div class="product-img">
                    <img src="/karobarsystem/assets/images/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                </div>
                <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>
                <div class="price-tag">Rs. <?= number_format($p['price']) ?></div>
                <?php if (!empty($p['pin'])): ?>
                    <span class="pin-tag"><i class="fas fa-key"></i><?= htmlspecialchars($p['pin']) ?></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- ============================================================
    STATS + WALLET
    ============================================================ -->
    <div class="section-title">
        <h3><i class="fas fa-chart-bar"></i> My Statistics</h3>
    </div>
    <div class="stats-wallet-row">
        <!-- Stats Card -->
        <div class="stats-card">
            <div class="stat-row">
                <span class="label">📦 Total Orders</span>
                <span class="value">18</span>
            </div>
            <div class="stat-row">
                <span class="label">💰 Total Earnings</span>
                <span class="value gold">Rs. 32,750</span>
            </div>
            <div class="stat-row">
                <span class="label">👥 Total Team</span>
                <span class="value">128</span>
            </div>
            <div class="stat-row">
                <span class="label">🏅 Rank</span>
                <span class="value gold">⭐ Silver Reseller</span>
            </div>
        </div>

        <!-- Wallet Card -->
        <div class="wallet-card">
            <span class="label"><i class="fas fa-wallet"></i> My Wallet Balance</span>
            <div class="amount">Rs. 12,450.00 <span>PKR</span></div>
            <button class="action-btn"><i class="fas fa-arrow-right"></i> Withdraw</button>
        </div>
    </div>

    <!-- ============================================================
    QUICK LINKS
    ============================================================ -->
    <div class="section-title">
        <h3><i class="fas fa-bolt"></i> Quick Links</h3>
    </div>
    <div class="quick-links">
        <div class="quick-link"><span class="icon">📋</span><span class="label">My Orders</span></div>
        <div class="quick-link"><span class="icon">👤</span><span class="label">My Profile</span></div>
        <div class="quick-link"><span class="icon">🌳</span><span class="label">Tree View</span></div>
        <div class="quick-link"><span class="icon">🔗</span><span class="label">Referral Link</span></div>
        <div class="quick-link"><span class="icon">📊</span><span class="label">Earnings Report</span></div>
    </div>

    <!-- ============================================================
    REFERRAL PROGRAM
    ============================================================ -->
    <div class="referral-section">
        <h4><i class="fas fa-handshake"></i> Referral Program</h4>
        <div class="referral-grid">
            <div class="referral-item">
                <span class="icon">💰</span>
                <span class="label">Earnings</span>
            </div>
            <div class="referral-item">
                <span class="icon">🛟</span>
                <span class="label">Support</span>
            </div>
            <div class="referral-item">
                <span class="icon">⚙️</span>
                <span class="label">Settings</span>
            </div>
            <div class="referral-item">
                <span class="icon">🚪</span>
                <span class="label">Logout</span>
            </div>
        </div>
    </div>

    <!-- ============================================================
    BENEFITS / FEATURES
    ============================================================ -->
    <div class="benefits-grid">
        <div class="benefit-card">
            <span class="icon">🏢</span>
            <h5>Become a Reseller</h5>
            <p>100% your own business and earn unlimited commission.</p>
        </div>
        <div class="benefit-card">
            <span class="icon">🔒</span>
            <h5>Secure Payment</h5>
            <p>100% secure payment with multiple options.</p>
        </div>
        <div class="benefit-card">
            <span class="icon">🚚</span>
            <h5>Fast Delivery</h5>
            <p>Get your products at your doorstep.</p>
        </div>
        <div class="benefit-card">
            <span class="icon">👥</span>
            <h5>Referral &amp; Earn</h5>
            <p>Refer &amp; earn unlimited commissions.</p>
        </div>
        <div class="benefit-card">
            <span class="icon">🕒</span>
            <h5>24/7 Support</h5>
            <p>We're here to help you anytime.</p>
        </div>
        <div class="benefit-card">
            <span class="icon">🎁</span>
            <h5>Invite &amp; Earn</h5>
            <p>Invite your friends and earn big rewards.</p>
        </div>
    </div>

    <!-- ============================================================
    INVITE SECTION
    ============================================================ -->
    <div class="invite-section">
        <h3>🌟 Invite &amp; Earn</h3>
        <p>Invite your friends and earn big rewards. Share your referral link now!</p>
        <button class="invite-btn">
            <i class="fas fa-share-alt"></i> Invite Now
        </button>
    </div>

    <!-- ============================================================
    BOTTOM NAVIGATION (FIXED)
    ============================================================ -->
    <nav class="bottom-nav">
        <a href="#" class="nav-item active">
            <span class="icon"><i class="fas fa-home"></i></span>
            <span>Home</span>
        </a>
        <a href="#" class="nav-item">
            <span class="icon"><i class="fas fa-th-large"></i></span>
            <span>Categories</span>
        </a>
        <a href="#" class="nav-item">
            <span class="icon"><i class="fas fa-user"></i></span>
            <span>Profile</span>
        </a>
        <a href="#" class="nav-item">
            <span class="icon"><i class="fas fa-shopping-cart"></i></span>
            <span>Cart</span>
        </a>
        <a href="#" class="nav-item">
            <span class="icon"><i class="fas fa-bars"></i></span>
            <span>More</span>
        </a>
    </nav>

    <!-- ============================================================
    JAVASCRIPT (optional interactions)
    ============================================================ -->
    <script>
        // Simple interactive feedback
        document.querySelectorAll('.cat-item, .quick-link, .referral-item, .benefit-card, .trend-card').forEach(el => {
            el.addEventListener('click', function(e) {
                // Just a subtle haptic-like feedback
                this.style.transition = 'transform 0.1s';
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = 'scale(1)';
                }, 120);
                console.log('Clicked:', this.innerText.trim().slice(0, 30));
            });
        });

        // Wallet Withdraw button
        document.querySelector('.wallet-card .action-btn')?.addEventListener('click', function(e) {
            e.stopPropagation();
            alert('💰 Withdraw request initiated. Your balance: Rs. 12,450.00');
        });

        // Invite button
        document.querySelector('.invite-btn')?.addEventListener('click', function() {
            alert('🔗 Your referral link: https://aqnakarobar.com/ref/your-code');
        });

        // Quick link clicks
        document.querySelectorAll('.quick-link').forEach((el, i) => {
            el.addEventListener('click', function() {
                const label = this.querySelector('.label')?.innerText || 'Link';
                alert(`🔗 Navigating to: ${label}`);
            });
        });

        console.log('🚀 Aqna Karobar System Dashboard loaded.');
    </script>

</body>
</html>