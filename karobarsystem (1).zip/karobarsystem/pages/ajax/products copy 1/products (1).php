<?php
session_start();
require_once __DIR__ . '/../../../config/db.php';
require_once __DIR__ . '/../../../engine/tree_count.php';

$pageTitle = 'Shop';
$active = 'home';

// ================= FETCH ALL PRODUCTS =================
$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// ================= LOGIN-AWARE STATS (real data) =================
$statsAvailable = false;
if (isset($_SESSION['user_id'])) {
    $user_id = (int) $_SESSION['user_id'];

    $earnStmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM user_earnings WHERE user_id = ?");
    $earnStmt->execute([$user_id]);
    $totalEarnings = (float) $earnStmt->fetchColumn();

    $directTeam   = countDirectTeam($conn, $user_id);
    $indirectTeam = countIndirectTeam($conn, $user_id);

    $statsAvailable = true;
}

require __DIR__ . '/product_header.php';
?>

<!-- ================= HERO ================= -->
<section class="py-4">
<div class="container">
<div class="row">
<div class="col-lg-8">
<div class="bg-primary rounded-4 p-5 text-white h-100">
<h1 class="fw-bold display-5">Best Quality Products</h1>
<h2 class="text-warning">Best Prices</h2>
<p class="mt-3">Shop from a wide range of premium products at unbeatable prices.</p>
<a href="#productsGrid" class="btn btn-light btn-lg mt-3">Trending Products</a>
</div>
</div>

<div class="col-lg-4 mt-4 mt-lg-0">
<div class="row g-3">
<div class="col-12">
<div class="card border-0 shadow-sm">
<div class="card-body">
<h5><i class="fa-solid fa-shield-halved text-primary"></i> Secure Shopping</h5>
<p class="mb-0">100% Safe Payments</p>
</div>
</div>
</div>
<div class="col-12">
<div class="card border-0 shadow-sm">
<div class="card-body">
<h5><i class="fa-solid fa-truck-fast text-success"></i> Fast Delivery</h5>
<p class="mb-0">Quick Doorstep Delivery</p>
</div>
</div>
</div>
<div class="col-12">
<div class="card border-0 shadow-sm">
<div class="card-body">
<h5><i class="fa-solid fa-headset text-warning"></i> 24/7 Support</h5>
<p class="mb-0">Always Ready To Help</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<?php if ($statsAvailable): ?>
<!-- ================= LOGGED-IN STATS STRIP (real numbers) ================= -->
<section class="container">
<div class="stats-strip">
<div class="row">
<div class="col-4 stat-box">
    <div class="num">Rs. <?= number_format($totalEarnings) ?></div>
    <div class="lbl"><i class="fa-solid fa-wallet"></i> Total Earnings</div>
</div>
<div class="col-4 stat-box">
    <div class="num"><?= $directTeam ?></div>
    <div class="lbl"><i class="fa-solid fa-user-check"></i> Direct Team</div>
</div>
<div class="col-4 stat-box">
    <div class="num"><?= $indirectTeam ?></div>
    <div class="lbl"><i class="fa-solid fa-users"></i> Indirect Team</div>
</div>
</div>
</div>
</section>
<?php endif; ?>

<!-- ================= PRODUCT GRID (Trending Products) ================= -->
<section class="container py-3" id="productsGrid">
<h3 class="fw-bold mb-4"><i class="fa-solid fa-fire text-danger"></i> Trending Products</h3>

<?php if (empty($products)): ?>
    <p class="text-muted">Filhaal koi product available nahi hai.</p>
<?php else: ?>
<div class="row g-4">
    <?php foreach ($products as $p): ?>
    <div class="col-6 col-md-4 col-lg-3">
        <a href="details.php?id=<?= (int)$p['id'] ?>" class="text-decoration-none product-card-link">
            <div class="card product-card">
                <img src="/karobarsystem/assets/images/<?= htmlspecialchars($p['image']) ?>" class="product-thumb" alt="<?= htmlspecialchars($p['name']) ?>">
                <div class="product-body">
                    <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>
                    <div class="product-price">Rs. <?= number_format($p['price']) ?></div>

                    <!-- PIN + Copy box (visible right in the grid, no click-through needed) -->
                    <div class="product-pin-mini">
                        <div class="pin-mini-text">
                            <span>PIN:</span>
                            <strong class="pin-mini-value"><?= htmlspecialchars($p['pin']) ?></strong>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary copy-mini-btn" data-pin="<?= htmlspecialchars($p['pin']) ?>">
                            <i class="fa-regular fa-copy"></i> Copy
                        </button>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

</section>

<script>
document.addEventListener('click', function (e) {
    const btn = e.target.closest('.copy-mini-btn');
    if (!btn) return;

    // PIN copy button ke click par card ka link open na ho
    e.preventDefault();
    e.stopPropagation();

    const pin = btn.getAttribute('data-pin');
    navigator.clipboard.writeText(pin).then(function () {
        const originalHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
        setTimeout(function () { btn.innerHTML = originalHtml; }, 1800);
    });
});
</script>

<?php require __DIR__ . '/product_footer.php'; ?>