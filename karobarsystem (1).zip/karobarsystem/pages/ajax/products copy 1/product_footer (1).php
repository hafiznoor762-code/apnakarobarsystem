<!-- ================= MOBILE BOTTOM NAV (scrollable, more items can be added later) ================= -->
<nav class="mobile-bottom-nav d-lg-none">
    <div class="mobile-bottom-nav-scroll">
        <a href="products.php" class="bn-item <?= $active === 'home' ? 'active' : '' ?>">
            <i class="fa-solid fa-house"></i><span>Home</span>
        </a>
        <a href="categories.php" class="bn-item <?= $active === 'categories' ? 'active' : '' ?>">
            <i class="fa-solid fa-th-large"></i><span>Categories</span>
        </a>
        <a href="cart.php" class="bn-item <?= $active === 'cart' ? 'active' : '' ?>">
            <i class="fa-solid fa-cart-shopping"></i><span>Cart</span>
        </a>
        <a href="account.php" class="bn-item <?= $active === 'account' ? 'active' : '' ?>">
            <i class="fa-solid fa-user"></i><span>Account</span>
        </a>
        <!-- More items yahan aage add hongay (jab bataya jaega) -->
    </div>
</nav>

<!-- Bootstrap JS (dropdowns, collapse) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>