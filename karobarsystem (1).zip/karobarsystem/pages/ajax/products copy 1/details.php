<?php
/**
 * Product Detail Page — Apna Karobar System
 * Path: public_html/karobarsystem/pages/ajax/products/details.php
 *
 * Har product ka apna PIN yahan copy button ke sath dikhta hai.
 * "Buy Now" click karne par buyer registration form khulta hai
 * aur PIN wahan pehle se bhara hota hai.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../../config/db.php';

if (!isset($_GET['id'])) {
    die("Product ID missing");
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found");
}

$pageTitle = $product['name'];
$active    = 'products';

// Related products — kuch aur random products, isko chorh kar
$relStmt = $conn->prepare("SELECT * FROM products WHERE id != ? ORDER BY RAND() LIMIT 4");
$relStmt->execute([$id]);
$related = $relStmt->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/product_header.php';
?>

<section class="container py-4">
<div class="row g-4">

    <!-- IMAGE -->
    <div class="col-lg-5">
        <div class="detail-img-box">
            <img src="/karobarsystem/assets/images/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
        </div>
    </div>

    <!-- DETAILS -->
    <div class="col-lg-7">
        <h1 class="fw-bold"><?= htmlspecialchars($product['name']) ?></h1>

        <div class="mb-3">
            <span class="fs-3 fw-bold text-primary">Rs. <?= number_format($product['price']) ?></span>
        </div>

        <!-- PRODUCT PIN -->
        <?php if (!empty($product['pin'])): ?>
        <div class="pin-box">
            <div>
                <div class="text-muted small">Product PIN</div>
                <div class="pin-value" id="productPin"><?= htmlspecialchars($product['pin']) ?></div>
            </div>
            <button type="button" class="btn btn-outline-primary copy-btn" id="copyPinBtn">
                <i class="fa-regular fa-copy"></i> Copy PIN
            </button>
        </div>
        <div class="text-success small mb-3" id="copiedMsg" style="display:none;">
            <i class="fa-solid fa-check-circle"></i> PIN copy ho gaya!
        </div>
        <?php endif; ?>

        <!-- DESCRIPTION -->
        <div class="mb-4">
            <h5 class="fw-bold">Product Details</h5>
            <p class="text-muted" style="line-height:1.8;">
                <?= nl2br(htmlspecialchars($product['description'] ?? 'Is product ki tafseel jald add ki jayegi.')) ?>
            </p>
        </div>

        <!-- ACTIONS -->
        <div class="d-flex flex-wrap gap-2">
            <a href="../../../pages/register_buyer.php?product_pin=<?= urlencode($product['pin'] ?? '') ?>&product_id=<?= (int)$product['id'] ?>"
               class="btn btn-primary btn-lg flex-fill">
                <i class="fa-solid fa-bolt"></i> Buy Now
            </a>
            <a href="cart.php?add=<?= (int)$product['id'] ?>" class="btn btn-outline-dark btn-lg flex-fill">
                <i class="fa-solid fa-cart-plus"></i> Add To Cart
            </a>
        </div>

        <?php if (!empty($product['pin'])): ?>
        <p class="text-muted small mt-3">
            <i class="fa-solid fa-circle-info"></i>
            PIN copy kar lein — "Buy Now" par click karte hi registration form khulega, wahan PIN paste kar dein.
        </p>
        <?php endif; ?>
    </div>
</div>

<!-- RELATED PRODUCTS -->
<?php if (!empty($related)): ?>
<div class="mt-5">
    <h4 class="fw-bold mb-3"><i class="fa-solid fa-layer-group text-primary"></i> Related Products</h4>
    <div class="row g-4">
        <?php foreach ($related as $r): ?>
        <div class="col-6 col-md-4 col-lg-3">
            <a href="details.php?id=<?= (int)$r['id'] ?>" class="text-decoration-none">
                <div class="card product-card">
                    <img src="/karobarsystem/assets/images/<?= htmlspecialchars($r['image']) ?>" class="product-thumb" alt="<?= htmlspecialchars($r['name']) ?>">
                    <div class="product-body">
                        <div class="product-name"><?= htmlspecialchars($r['name']) ?></div>
                        <div class="price-pin-row">
                            <span class="product-price">Rs. <?= number_format($r['price']) ?></span>
                            <?php if (!empty($r['pin'])): ?>
                                <span class="pin-tag"><i class="fa-solid fa-key"></i><?= htmlspecialchars($r['pin']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

</section>

<?php if (!empty($product['pin'])): ?>
<script>
document.getElementById('copyPinBtn').addEventListener('click', function () {
    const pin = document.getElementById('productPin').innerText.trim();
    navigator.clipboard.writeText(pin).then(function () {
        const msg = document.getElementById('copiedMsg');
        msg.style.display = 'block';
        setTimeout(() => { msg.style.display = 'none'; }, 2500);
    }).catch(function () {
        alert('PIN: ' + pin + ' (copy nahi ho saka, manually copy kar lein)');
    });
});
</script>
<?php endif; ?>

<?php require __DIR__ . '/product_footer.php'; ?>