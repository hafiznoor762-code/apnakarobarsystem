<?php
/**
 * Shared header + navbar for ALL product pages
 * (products.php, details.php, admin_product.php, cart.php, etc.)
 *
 * Include this AFTER session_start() + db.php, and set $active
 * to one of: home, categories, products, cart, account
 *
 * Usage:
 *   $active = 'products';
 *   require __DIR__ . '/product_header.php';
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = isset($_SESSION['user_id']);
$loggedUserName = htmlspecialchars($_SESSION['full_name'] ?? 'User', ENT_QUOTES, 'UTF-8');
$active = $active ?? 'home';

// Cart item count (session based mini-cart, safe default)
$cartCount = isset($_SESSION['cart']) && is_array($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' – ' : '' ?>Apna Karobar System</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<!-- Shared products CSS -->
<link rel="stylesheet" href="products_style.css?v=<?php echo time(); ?>">
</head>
<body>

<!-- ================= HEADER ================= -->
<header class="bg-white shadow-sm py-3">
<div class="container">
<div class="row align-items-center gy-3">

<!-- Logo -->
<div class="col-6 col-lg-3">
    <a href="products.php" class="text-decoration-none">
        <h2 class="fw-bold text-primary m-0">
            <i class="fa-solid fa-bag-shopping"></i>
            Apna<span class="text-dark">Karobar</span>
        </h2>
    </a>
</div>

<!-- Search -->
<div class="col-12 col-lg-6 order-3 order-lg-2">
    <form action="search.php" method="get" class="input-group">
        <input type="text" name="q" class="form-control form-control-lg" placeholder="Search Products..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
        <button class="btn btn-primary" type="submit">
            <i class="fa fa-search"></i>
        </button>
    </form>
</div>

<!-- Icons -->
<div class="col-6 col-lg-3 order-2 order-lg-3 text-end">

    <?php if ($isLoggedIn): ?>
        <div class="dropdown d-inline-block">
            <a href="#" class="text-dark me-3 dropdown-toggle" data-bs-toggle="dropdown">
                <i class="fa-regular fa-circle-user"></i>
                <?= $loggedUserName ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="account.php"><i class="fa-solid fa-gauge me-2"></i>My Dashboard</a></li>
                <li><a class="dropdown-item" href="../../../index.php?page=logout"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
            </ul>
        </div>
    <?php else: ?>
        <a href="../../../index.php?page=login" class="text-dark me-3">
            <i class="fa-regular fa-user"></i>
            Login
        </a>
    <?php endif; ?>

    <a href="cart.php" class="text-dark position-relative">
        <i class="fa-solid fa-cart-shopping"></i>
        <?php if ($cartCount > 0): ?>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
            <?= $cartCount ?>
        </span>
        <?php endif; ?>
    </a>
</div>

</div>
</div>
</header>

<!-- ================= NAVBAR ================= -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container">
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav mx-auto">
    <li class="nav-item"><a href="products.php" class="nav-link <?= $active === 'home' ? 'active' : '' ?>">Home</a></li>
    <li class="nav-item"><a href="categories.php" class="nav-link <?= $active === 'categories' ? 'active' : '' ?>">Categories</a></li>
    <li class="nav-item"><a href="products.php" class="nav-link <?= $active === 'products' ? 'active' : '' ?>">Products</a></li>
    <li class="nav-item"><a href="cart.php" class="nav-link <?= $active === 'cart' ? 'active' : '' ?>">Cart</a></li>
    <li class="nav-item"><a href="account.php" class="nav-link <?= $active === 'account' ? 'active' : '' ?>">Account</a></li>
</ul>
</div>
</div>
</nav>