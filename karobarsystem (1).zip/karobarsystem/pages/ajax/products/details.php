<?php
/**
 * Product Detail Page — Apna Karobar System
 * Amazon-style layout: image + sticky buy-box + full detail + zyada "picks"
 * Design products.php jaisa hi dark-green theme mein.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../../config/db.php';

if (!isset($_GET['id'])) {
    die("Product ID missing");
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found");
}

// Isi product ki apni extra photos (alag angles) — admin panel se upload hoti hain
$giStmt = $conn->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order ASC");
$giStmt->execute([$id]);
$galleryImages = $giStmt->fetchAll(PDO::FETCH_ASSOC);

// Zyada "picks" — 8 ALAG products (Amazon ke "Consider a similar item" jaisa)
$relStmt = $conn->prepare("SELECT * FROM products WHERE id != ? ORDER BY RAND() LIMIT 8");
$relStmt->execute([$id]);
$related = $relStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    <title><?= htmlspecialchars($product['name']) ?> – Apna Karobar System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
        body { background:#f7f9f6; color:#10140f; padding-bottom:80px; min-height:100vh; }
        a { text-decoration:none; color:inherit; }
        img { display:block; max-width:100%; }

        /* HEADER */
        .top-header {
            background:#10140f; padding:14px 18px; display:flex; align-items:center; justify-content:space-between;
            position:sticky; top:0; z-index:30; box-shadow:0 2px 12px rgba(16,20,15,0.15);
        }
        .top-header .brand { display:flex; align-items:center; gap:10px; }
        .top-header .brand i { font-size:22px; color:#2fa83f; }
        .top-header .brand h1 { font-size:18px; font-weight:700; color:#fff; }
        .top-header .brand h1 span { color:#2fa83f; }
        .top-header .back-btn { display:flex; align-items:center; gap:8px; color:#fff; font-size:14px; font-weight:600; }
        .top-header .back-btn i { font-size:16px; color:#2fa83f; }

        /* BREADCRUMB */
        .breadcrumb {
            max-width:1200px; margin:0 auto; padding:14px 16px 0;
            font-size:13px; color:#8a938c;
        }
        .breadcrumb a { color:#146b27; font-weight:600; }
        .breadcrumb i { font-size:10px; margin:0 6px; }

        /* MAIN LAYOUT (Amazon-style: image+desc left, sticky buy-box right) */
        .detail-wrap { max-width:1200px; margin:0 auto; padding:16px 16px 10px; }
        .detail-grid { display:grid; grid-template-columns:1fr; gap:20px; }
        @media (min-width:900px) {
            .detail-grid { grid-template-columns: 1.3fr 1fr 0.9fr; gap:28px; align-items:start; }
        }

        /* IMAGE COLUMN */
        .img-col { }
        .detail-img-box {
            background:#fff; border-radius:16px; border:1px solid #e7e9e4;
            box-shadow:0 2px 8px rgba(16,20,15,0.04); overflow:hidden;
            display:flex; align-items:center; justify-content:center; min-height:280px;
        }
        .detail-img-box img { width:100%; height:100%; max-height:440px; object-fit:cover; }
        .thumb-row { display:flex; gap:8px; margin-top:10px; overflow-x:auto; padding-bottom:4px; }
        .thumb-row img {
            width:60px; height:60px; object-fit:cover; border-radius:8px;
            border:2px solid #e7e9e4; cursor:pointer; opacity:.75; transition:.2s;
        }
        .thumb-row img.active, .thumb-row img:hover { opacity:1; border-color:#2fa83f; }

        /* INFO COLUMN */
        .info-col .product-name { font-size:22px; font-weight:700; line-height:1.35; margin-bottom:6px; }
        .info-col .meta-line { font-size:13px; color:#8a938c; margin-bottom:10px; }
        .info-col .meta-line i { color:#2fa83f; margin-right:4px; }
        .info-col .product-price-row { display:flex; align-items:baseline; gap:10px; margin-bottom:14px; }
        .info-col .product-price { font-size:28px; font-weight:700; color:#2fa83f; }
        .info-col .badge-instock {
            display:inline-block; background:#eaf7ea; color:#146b27; font-size:12px; font-weight:700;
            padding:3px 12px; border-radius:20px; margin-bottom:14px;
        }
        .divider { border-top:1px solid #eef1ea; margin:16px 0; }

        .info-block h5 { font-size:14px; font-weight:700; margin-bottom:8px; }
        .info-block h5 i { color:#2fa83f; margin-right:6px; }
        .info-block p, .info-block li { font-size:14px; color:#55605a; line-height:1.8; }
        .info-block ul { padding-left:18px; margin-bottom:14px; }

        /* BUY BOX (sticky, Amazon-style) */
        .buy-box {
            background:#fff; border-radius:16px; border:1px solid #e7e9e4;
            box-shadow:0 4px 16px rgba(16,20,15,0.06); padding:20px;
        }
        @media (min-width:900px) { .buy-box { position:sticky; top:86px; } }
        .buy-box .bb-price { font-size:26px; font-weight:700; color:#2fa83f; margin-bottom:4px; }
        .buy-box .bb-stock { font-size:13px; color:#146b27; font-weight:700; margin-bottom:14px; }
        .buy-box .bb-stock i { margin-right:4px; }

        .pin-box {
            background:#eaf7ea; border:1.5px dashed #2fa83f; border-radius:14px; padding:14px 16px;
            display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:14px;
        }
        .pin-box .pin-label { font-size:11px; color:#146b27; font-weight:700; text-transform:uppercase; letter-spacing:.5px; }
        .pin-box .pin-value { font-size:18px; font-weight:700; letter-spacing:2px; color:#10140f; font-family:monospace; }
        .pin-box .copy-btn {
            background:#2fa83f; color:#fff; border:none; padding:9px 14px; border-radius:30px;
            font-weight:600; font-size:12px; cursor:pointer; white-space:nowrap; transition:.2s;
        }
        .pin-box .copy-btn:hover { background:#146b27; }
        .copied-msg { font-size:12px; color:#146b27; font-weight:600; margin:-8px 0 12px; display:none; }

        .btn-buy, .btn-cart {
            width:100%; text-align:center; padding:13px 16px; border-radius:30px; font-weight:700; font-size:14px;
            cursor:pointer; border:none; display:flex; align-items:center; justify-content:center; gap:8px;
            transition:.2s; margin-bottom:10px;
        }
        .btn-buy { background:linear-gradient(135deg,#2fa83f,#146b27); color:#fff; }
        .btn-buy:hover { transform:scale(1.015); }
        .btn-cart { background:#fff; color:#10140f; border:1.5px solid #10140f; }
        .btn-cart:hover { background:#f7f9f6; }
        .buy-note { font-size:11.5px; color:#8a938c; line-height:1.5; }
        .buy-note i { color:#2fa83f; margin-right:4px; }

        .trust-row { display:flex; flex-direction:column; gap:8px; margin-top:16px; padding-top:16px; border-top:1px solid #eef1ea; }
        .trust-row .trust-item { display:flex; align-items:center; gap:8px; font-size:12.5px; color:#55605a; }
        .trust-row .trust-item i { color:#2fa83f; width:16px; text-align:center; }

        /* SECTION TITLE */
        .section-title { display:flex; justify-content:space-between; align-items:center; padding:26px 0 12px; max-width:1200px; margin:0 auto; }
        .section-title h3 { font-size:17px; font-weight:700; padding:0 16px; }
        .section-title h3 i { color:#2fa83f; margin-right:8px; }

        /* PICKS GRID (zyada related products) */
        .picks-grid {
            display:grid; grid-template-columns:repeat(2,1fr); gap:14px;
            padding:0 16px 10px; max-width:1200px; margin:0 auto;
        }
        @media (min-width:600px) { .picks-grid { grid-template-columns:repeat(3,1fr); } }
        @media (min-width:900px) { .picks-grid { grid-template-columns:repeat(4,1fr); } }

        .trend-card {
            background:#fff; border-radius:14px; padding:14px 12px; text-align:center;
            box-shadow:0 2px 8px rgba(16,20,15,0.04); border:1px solid #e7e9e4; transition:.2s; cursor:pointer;
        }
        .trend-card:active { transform:scale(0.96); }
        .trend-card .product-img { width:100%; height:110px; background:#f7f9f6; border-radius:12px; margin-bottom:8px; overflow:hidden; }
        .trend-card .product-img img { width:100%; height:100%; object-fit:cover; }
        .trend-card .product-name {
            font-size:13px; font-weight:600; color:#10140f;
            display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; min-height:34px;
        }
        .trend-card .price-tag { font-size:13px; font-weight:700; color:#2fa83f; margin-top:4px; }
        .trend-card .pin-tag {
            display:inline-block; margin-top:6px; background:#eaf7ea; border:1px dashed #2fa83f; color:#146b27;
            font-size:11px; font-weight:700; padding:3px 10px; border-radius:30px;
        }

        /* BOTTOM NAV */
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0; background:rgba(255,255,255,0.96); backdrop-filter:blur(8px);
            display:flex; justify-content:space-around; align-items:center; padding:8px 0 env(safe-area-inset-bottom);
            border-top:1px solid #e7e9e4; box-shadow:0 -2px 12px rgba(16,20,15,0.06); z-index:100;
        }
        .bottom-nav .nav-item { display:flex; flex-direction:column; align-items:center; font-size:10px; color:#8a938c; padding:4px 12px; border-radius:30px; }
        .bottom-nav .nav-item.active { color:#2fa83f; }
        .bottom-nav .nav-item .icon { font-size:22px; line-height:1; }
        .bottom-nav .nav-item span:last-child { margin-top:2px; font-weight:500; }
        @media (min-width:769px) { body { padding-bottom:0; } .bottom-nav { display:none; } }
    </style>
</head>
<body>

    <header class="top-header">
        <a href="products.php" class="brand"><i class="fas fa-store-alt"></i><h1>Aqna<span>Karobar</span></h1></a>
        <a href="products.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Shop</a>
    </header>

    <div class="breadcrumb">
        <a href="products.php">Home</a> <i class="fas fa-chevron-right"></i>
        <a href="all_products.php">All Products</a> <i class="fas fa-chevron-right"></i>
        <span><?= htmlspecialchars($product['name']) ?></span>
    </div>

    <div class="detail-wrap">
        <div class="detail-grid">

            <!-- IMAGE COLUMN -->
            <div class="img-col">
                <div class="detail-img-box">
                    <img id="mainImg" src="/karobarsystem/assets/images/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                </div>
                <?php if (!empty($galleryImages)): ?>
                <div class="thumb-row">
                    <img src="/karobarsystem/assets/images/<?= htmlspecialchars($product['image']) ?>" class="active" onclick="document.getElementById('mainImg').src=this.src;document.querySelectorAll('.thumb-row img').forEach(t=>t.classList.remove('active'));this.classList.add('active');">
                    <?php foreach ($galleryImages as $gi): ?>
                        <img src="/karobarsystem/assets/images/<?= htmlspecialchars($gi['image']) ?>" onclick="document.getElementById('mainImg').src=this.src;document.querySelectorAll('.thumb-row img').forEach(t=>t.classList.remove('active'));this.classList.add('active');">
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- INFO COLUMN -->
            <div class="info-col">
                <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                <div class="meta-line"><i class="fas fa-store"></i> Sold by Apna Karobar System · <i class="fas fa-shield-halved"></i> Verified Product</div>

                <div class="product-price-row">
                    <span class="product-price">Rs. <?= number_format($product['price']) ?></span>
                </div>
                <span class="badge-instock"><i class="fas fa-check-circle"></i> In Stock</span>

                <div class="divider"></div>

                <div class="info-block">
                    <h5><i class="fas fa-align-left"></i> Product Details</h5>
                    <p><?= nl2br(htmlspecialchars($product['description'] ?? 'Is product ki tafseel jald add ki jayegi.')) ?></p>
                </div>

                <div class="divider"></div>

                <div class="info-block">
                    <h5><i class="fas fa-circle-check"></i> Kyun Ye Product Lein</h5>
                    <ul>
                        <li>100% original aur quality-checked product</li>
                        <li>Sell kar ke commission kamane ka mauqa</li>
                        <li>Customer tak product pohanchana system ki zimmedari</li>
                        <li>Poori team ke sath milkar kaam karne ka mauqa</li>
                    </ul>
                </div>
            </div>

            <!-- BUY BOX -->
            <div class="buy-col">
                <div class="buy-box">
                    <div class="bb-price">Rs. <?= number_format($product['price']) ?></div>
                    <div class="bb-stock"><i class="fas fa-circle-check"></i> In Stock — Ready to sell</div>

                    <?php if (!empty($product['pin'])): ?>
                    <div class="pin-box">
                        <div>
                            <div class="pin-label"><i class="fas fa-key"></i> Product PIN</div>
                            <div class="pin-value" id="productPin"><?= htmlspecialchars($product['pin']) ?></div>
                        </div>
                        <button type="button" class="copy-btn" id="copyPinBtn"><i class="fa-regular fa-copy"></i> Copy</button>
                    </div>
                    <div class="copied-msg" id="copiedMsg"><i class="fa-solid fa-circle-check"></i> PIN copy ho gaya!</div>
                    <?php endif; ?>

                    <a href="../../../pages/register_buyer.php?product_pin=<?= urlencode($product['pin'] ?? '') ?>&product_id=<?= (int)$product['id'] ?>" class="btn-buy">
                        <i class="fas fa-bolt"></i> Buy Now
                    </a>
                    <a href="cart.php?add=<?= (int)$product['id'] ?>" class="btn-cart">
                        <i class="fas fa-cart-plus"></i> Add To Cart
                    </a>

                    <?php if (!empty($product['pin'])): ?>
                    <div class="buy-note">
                        <i class="fa-solid fa-circle-info"></i>
                        PIN copy kar lein — "Buy Now" par click karte hi registration form khulega, wahan PIN pehle se bhara milega.
                    </div>
                    <?php endif; ?>

                    <div class="trust-row">
                        <div class="trust-item"><i class="fas fa-truck-fast"></i> Fast delivery seedha aapke customer tak</div>
                        <div class="trust-item"><i class="fas fa-lock"></i> Secure &amp; verified transaction</div>
                        <div class="trust-item"><i class="fas fa-headset"></i> 24/7 support available</div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- MORE PICKS -->
    <?php if (!empty($related)): ?>
    <div class="section-title"><h3><i class="fas fa-layer-group"></i> Aap Ko Ye Bhi Pasand Aa Sakte Hain</h3></div>
    <div class="picks-grid">
        <?php foreach ($related as $r): ?>
        <a href="details.php?id=<?= (int)$r['id'] ?>" class="trend-card">
            <div class="product-img"><img src="/karobarsystem/assets/images/<?= htmlspecialchars($r['image']) ?>" alt="<?= htmlspecialchars($r['name']) ?>"></div>
            <div class="product-name"><?= htmlspecialchars($r['name']) ?></div>
            <div class="price-tag">Rs. <?= number_format($r['price']) ?></div>
            <?php if (!empty($r['pin'])): ?><span class="pin-tag"><i class="fas fa-key"></i> <?= htmlspecialchars($r['pin']) ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <nav class="bottom-nav">
        <a href="products.php" class="nav-item"><span class="icon"><i class="fas fa-home"></i></span><span>Home</span></a>
        <a href="all_products.php" class="nav-item"><span class="icon"><i class="fas fa-th-large"></i></span><span>All Products</span></a>
        <a href="account.php" class="nav-item"><span class="icon"><i class="fas fa-user"></i></span><span>Profile</span></a>
        <a href="cart.php" class="nav-item"><span class="icon"><i class="fas fa-shopping-cart"></i></span><span>Cart</span></a>
        <a href="products.php" class="nav-item active"><span class="icon"><i class="fas fa-bars"></i></span><span>More</span></a>
    </nav>

    <?php if (!empty($product['pin'])): ?>
    <script>
    document.getElementById('copyPinBtn').addEventListener('click', function () {
        const pin = document.getElementById('productPin').innerText.trim();
        navigator.clipboard.writeText(pin).then(function () {
            const msg = document.getElementById('copiedMsg');
            msg.style.display = 'block';
            setTimeout(() => { msg.style.display = 'none'; }, 2500);
        }).catch(function () {
            alert('PIN: ' + pin + ' (copy nahi ho saka, manually copy kar lein)');
        });
    });
    </script>
    <?php endif; ?>

</body>
</html>