<?php
/**
 * All Products — Daraz-style full catalog grid
 * Apna Karobar System — same dark-green theme
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../../config/db.php';

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? ORDER BY id DESC");
    $stmt->execute(['%' . $search . '%']);
} else {
    $stmt = $conn->query("SELECT * FROM products ORDER BY id DESC");
}
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    <title>All Products – Apna Karobar System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
        body { background:#f7f9f6; color:#10140f; padding-bottom:80px; min-height:100vh; }
        a { text-decoration:none; color:inherit; }
        img { display:block; max-width:100%; }

        /* HEADER + SEARCH (Daraz-style orange->green search bar) */
        .top-header {
            background:#10140f; padding:14px 18px; position:sticky; top:0; z-index:30;
            box-shadow:0 2px 12px rgba(16,20,15,0.15);
        }
        .th-row { display:flex; align-items:center; gap:14px; max-width:1200px; margin:0 auto; }
        .brand { display:flex; align-items:center; gap:10px; flex-shrink:0; }
        .brand i { font-size:22px; color:#2fa83f; }
        .brand h1 { font-size:18px; font-weight:700; color:#fff; }
        .brand h1 span { color:#2fa83f; }
        .search-form { flex:1; display:flex; }
        .search-form input {
            flex:1; border:none; padding:10px 16px; border-radius:30px 0 0 30px; font-size:14px; outline:none;
        }
        .search-form button {
            background:#2fa83f; color:#fff; border:none; padding:0 18px; border-radius:0 30px 30px 0; cursor:pointer;
        }
        .cart-link { color:#fff; font-size:20px; flex-shrink:0; }

        /* PAGE HEAD */
        .page-head { max-width:1200px; margin:0 auto; padding:18px 16px 6px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px; }
        .page-head h2 { font-size:20px; font-weight:700; }
        .page-head h2 i { color:#2fa83f; margin-right:8px; }
        .page-head .count { font-size:13px; color:#8a938c; }
        .breadcrumb { max-width:1200px; margin:0 auto; padding:14px 16px 0; font-size:13px; color:#8a938c; }
        .breadcrumb a { color:#146b27; font-weight:600; }
        .breadcrumb i { font-size:10px; margin:0 6px; }

        /* GRID */
        .catalog-grid {
            display:grid; grid-template-columns:repeat(2,1fr); gap:14px;
            max-width:1200px; margin:0 auto; padding:14px 16px 30px;
        }
        @media (min-width:600px) { .catalog-grid { grid-template-columns:repeat(3,1fr); } }
        @media (min-width:900px) { .catalog-grid { grid-template-columns:repeat(4,1fr); } }
        @media (min-width:1150px) { .catalog-grid { grid-template-columns:repeat(5,1fr); } }

        .prod-card {
            background:#fff; border-radius:14px; overflow:hidden; border:1px solid #e7e9e4;
            box-shadow:0 2px 8px rgba(16,20,15,0.04); transition:.2s; cursor:pointer;
        }
        .prod-card:hover { transform:translateY(-3px); box-shadow:0 8px 18px rgba(16,20,15,0.08); }
        .prod-card .p-img { width:100%; height:150px; background:#f7f9f6; overflow:hidden; }
        .prod-card .p-img img { width:100%; height:100%; object-fit:cover; }
        .prod-card .p-body { padding:12px; }
        .prod-card .p-name {
            font-size:13.5px; font-weight:600; color:#10140f; margin-bottom:6px; line-height:1.35;
            display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; min-height:36px;
        }
        .prod-card .p-price { font-size:16px; font-weight:700; color:#2fa83f; margin-bottom:8px; }
        .prod-card .p-pin-row {
            display:flex; align-items:center; justify-content:space-between; gap:6px;
            border-top:1px dashed #e7e9e4; padding-top:8px;
        }
        .prod-card .p-pin { font-size:11px; color:#146b27; font-weight:700; font-family:monospace; }
        .prod-card .p-copy {
            background:#eaf7ea; border:1px solid #2fa83f; color:#146b27; font-size:10.5px; font-weight:700;
            padding:4px 9px; border-radius:20px; cursor:pointer; white-space:nowrap;
        }
        .prod-card .p-copy:hover { background:#2fa83f; color:#fff; }

        .empty-msg { max-width:1200px; margin:40px auto; text-align:center; color:#8a938c; padding:0 16px; }

        /* BOTTOM NAV */
        .bottom-nav {
            position:fixed; bottom:0; left:0; right:0; background:rgba(255,255,255,0.96); backdrop-filter:blur(8px);
            display:flex; justify-content:space-around; align-items:center; padding:8px 0 env(safe-area-inset-bottom);
            border-top:1px solid #e7e9e4; box-shadow:0 -2px 12px rgba(16,20,15,0.06); z-index:100;
        }
        .bottom-nav .nav-item { display:flex; flex-direction:column; align-items:center; font-size:10px; color:#8a938c; padding:4px 12px; border-radius:30px; }
        .bottom-nav .nav-item.active { color:#2fa83f; }
        .bottom-nav .nav-item .icon { font-size:22px; line-height:1; }
        .bottom-nav .nav-item span:last-child { margin-top:2px; font-weight:500; }
        @media (min-width:769px) { body { padding-bottom:0; } .bottom-nav { display:none; } }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="th-row">
            <a href="products.php" class="brand"><i class="fas fa-store-alt"></i><h1>Aqna<span>Karobar</span></h1></a>
            <form class="search-form" action="all_products.php" method="get">
                <input type="text" name="q" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>
            <a href="cart.php" class="cart-link"><i class="fas fa-shopping-cart"></i></a>
        </div>
    </header>

    <div class="breadcrumb">
        <a href="products.php">Home</a> <i class="fas fa-chevron-right"></i>
        <span>All Products</span>
    </div>

    <div class="page-head">
        <h2><i class="fas fa-shop"></i> <?= $search !== '' ? 'Search Results' : 'All Products' ?></h2>
        <span class="count"><?= count($products) ?> products found</span>
    </div>

    <?php if (empty($products)): ?>
        <div class="empty-msg">
            <i class="fas fa-box-open" style="font-size:40px;color:#c8cdc4;"></i>
            <p style="margin-top:10px;">Koi product nahi mila<?= $search !== '' ? ' "' . htmlspecialchars($search) . '" ke liye' : '' ?>.</p>
        </div>
    <?php else: ?>
    <div class="catalog-grid">
        <?php foreach ($products as $p): ?>
        <div class="prod-card" onclick="if(!event.target.closest('.p-copy'))window.location='details.php?id=<?= (int)$p['id'] ?>'">
            <div class="p-img"><img src="/karobarsystem/assets/images/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>"></div>
            <div class="p-body">
                <div class="p-name"><?= htmlspecialchars($p['name']) ?></div>
                <div class="p-price">Rs. <?= number_format($p['price']) ?></div>
                <?php if (!empty($p['pin'])): ?>
                <div class="p-pin-row">
                    <span class="p-pin"><i class="fas fa-key"></i> <?= htmlspecialchars($p['pin']) ?></span>
                    <button type="button" class="p-copy" data-pin="<?= htmlspecialchars($p['pin']) ?>">Copy</button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <nav class="bottom-nav">
        <a href="products.php" class="nav-item"><span class="icon"><i class="fas fa-home"></i></span><span>Home</span></a>
        <a href="all_products.php" class="nav-item active"><span class="icon"><i class="fas fa-th-large"></i></span><span>All Products</span></a>
        <a href="account.php" class="nav-item"><span class="icon"><i class="fas fa-user"></i></span><span>Profile</span></a>
        <a href="cart.php" class="nav-item"><span class="icon"><i class="fas fa-shopping-cart"></i></span><span>Cart</span></a>
        <a href="products.php" class="nav-item"><span class="icon"><i class="fas fa-bars"></i></span><span>More</span></a>
    </nav>

    <script>
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.p-copy');
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
        const pin = btn.getAttribute('data-pin');
        navigator.clipboard.writeText(pin).then(function () {
            const original = btn.textContent;
            btn.textContent = 'Copied!';
            setTimeout(() => { btn.textContent = original; }, 1500);
        });
    });
    </script>

</body>
</html>