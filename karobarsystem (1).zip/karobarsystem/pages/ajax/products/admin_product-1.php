<?php
session_start();
require_once __DIR__ . '/../../../config/db.php';

// ================= SIMPLE ACCESS PASSWORD =================
// Ye password admin_buyers.php aur admin_users.php ke sath shared hai —
// ek dafa dalne se teenon panels unlock ho jate hain.
$ACCESS_PASSWORD = 'apna1234';

if (isset($_GET['logout'])) {
    unset($_SESSION['admin_panel_access']);
    header("Location: admin_product.php");
    exit;
}

if (isset($_POST['access_password'])) {
    if ($_POST['access_password'] === $ACCESS_PASSWORD) {
        $_SESSION['admin_panel_access'] = true;
    } else {
        $accessError = 'Galat password.';
    }
}

if (!isset($_SESSION['admin_panel_access'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Products Admin – Access</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body style="background:#f7f9f6;">
        <div class="d-flex align-items-center justify-content-center" style="min-height:100vh;">
            <div class="card shadow-sm p-4" style="max-width:360px;width:100%;">
                <h5 class="fw-bold mb-3 text-center"><i class="fa-solid fa-lock"></i> Products Admin</h5>
                <?php if (!empty($accessError)): ?>
                    <div class="alert alert-danger py-2"><?= htmlspecialchars($accessError) ?></div>
                <?php endif; ?>
                <form method="post">
                    <input type="password" name="access_password" class="form-control mb-3" placeholder="Password" required autofocus>
                    <button type="submit" class="btn btn-primary w-100">Enter</button>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

$msg = '';
$msgType = '';
$imagesDir = $_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/assets/images/';

// ================= DELETE PRODUCT =================
if (isset($_GET['delete'])) {
    $delId = (int) $_GET['delete'];
    $conn->prepare("DELETE FROM products WHERE id = ?")->execute([$delId]);
    $conn->prepare("DELETE FROM product_images WHERE product_id = ?")->execute([$delId]);
    header("Location: admin_product.php?msg=deleted");
    exit;
}

// ================= DELETE A SINGLE GALLERY IMAGE =================
if (isset($_GET['delete_image'])) {
    $imgId = (int) $_GET['delete_image'];
    $backToEdit = (int) ($_GET['back_to'] ?? 0);
    $conn->prepare("DELETE FROM product_images WHERE id = ?")->execute([$imgId]);
    header("Location: admin_product.php?edit=" . $backToEdit);
    exit;
}

// ================= ADD / UPDATE PRODUCT =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name        = trim($_POST['name'] ?? '');
    $price       = (float) ($_POST['price'] ?? 0);
    $pin         = trim($_POST['pin'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $editId      = (int) ($_POST['edit_id'] ?? 0);

    $directCommission           = (int) ($_POST['direct_commission'] ?? 400);
    $indirectCommissionBuyer    = (int) ($_POST['indirect_commission_buyer'] ?? 200);
    $indirectCommissionReseller = (int) ($_POST['indirect_commission_reseller'] ?? 50);

    if ($name === '' || $pin === '' || $price <= 0) {
        $msg = 'Naam, price aur PIN zaroori hain.';
        $msgType = 'danger';
    } else {

        $dupStmt = $conn->prepare("SELECT id FROM products WHERE pin = ? AND id != ?");
        $dupStmt->execute([$pin, $editId]);
        if ($dupStmt->fetch()) {
            $msg = 'Ye PIN pehle se kisi aur product par lagi hui hai — alag PIN dein.';
            $msgType = 'danger';
        } else {

            $allowedExt = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
            if (!is_dir($imagesDir)) {
                mkdir($imagesDir, 0755, true);
            }

            // Main image (optional on edit — keeps old image if none uploaded)
            $imageName = null;
            $badFile = false;
            if (!empty($_FILES['image']['name'])) {
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, $allowedExt, true)) {
                    $imageName = 'prod_' . time() . '_' . rand(100, 999) . '.' . $ext;
                    move_uploaded_file($_FILES['image']['tmp_name'], $imagesDir . $imageName);
                } else {
                    $badFile = true;
                }
            }

            if ($badFile) {
                $msg = 'Sirf jpg, jpeg, png, webp, gif images allowed hain.';
                $msgType = 'danger';
            } else {
                if ($editId > 0) {
                    // UPDATE
                    if ($imageName) {
                        $upd = $conn->prepare("UPDATE products SET name=?, price=?, pin=?, description=?, image=?, direct_commission=?, indirect_commission_buyer=?, indirect_commission_reseller=? WHERE id=?");
                        $upd->execute([$name, $price, $pin, $description, $imageName, $directCommission, $indirectCommissionBuyer, $indirectCommissionReseller, $editId]);
                    } else {
                        $upd = $conn->prepare("UPDATE products SET name=?, price=?, pin=?, description=?, direct_commission=?, indirect_commission_buyer=?, indirect_commission_reseller=? WHERE id=?");
                        $upd->execute([$name, $price, $pin, $description, $directCommission, $indirectCommissionBuyer, $indirectCommissionReseller, $editId]);
                    }
                    $productId = $editId;
                    $msg = 'Product update ho gaya.';
                    $msgType = 'success';
                } else {
                    // ADD
                    $ins = $conn->prepare("INSERT INTO products (name, price, pin, description, image, direct_commission, indirect_commission_buyer, indirect_commission_reseller) VALUES (?,?,?,?,?,?,?,?)");
                    $ins->execute([$name, $price, $pin, $description, $imageName ?? '', $directCommission, $indirectCommissionBuyer, $indirectCommissionReseller]);
                    $productId = (int) $conn->lastInsertId();
                    $msg = 'Naya product add ho gaya.';
                    $msgType = 'success';
                }

                // ================= EXTRA GALLERY IMAGES (same product ki alag photos) =================
                if (!empty($_FILES['gallery_images']['name'][0])) {
                    $count = count($_FILES['gallery_images']['name']);
                    $sortStmt = $conn->prepare("SELECT COALESCE(MAX(sort_order),0) FROM product_images WHERE product_id = ?");
                    $sortStmt->execute([$productId]);
                    $nextSort = (int) $sortStmt->fetchColumn() + 1;

                    for ($i = 0; $i < $count; $i++) {
                        if ($_FILES['gallery_images']['error'][$i] !== UPLOAD_ERR_OK) {
                            continue;
                        }
                        $origName = $_FILES['gallery_images']['name'][$i];
                        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                        if (!in_array($ext, $allowedExt, true)) {
                            continue;
                        }
                        $galleryName = 'prod_' . time() . '_' . rand(1000, 9999) . '_' . $i . '.' . $ext;
                        move_uploaded_file($_FILES['gallery_images']['tmp_name'][$i], $imagesDir . $galleryName);

                        $insImg = $conn->prepare("INSERT INTO product_images (product_id, image, sort_order) VALUES (?, ?, ?)");
                        $insImg->execute([$productId, $galleryName, $nextSort]);
                        $nextSort++;
                    }
                }

                // Reload the edit form with this product so newly added gallery images show up
                if (isset($_GET['edit']) || $editId > 0 || isset($productId)) {
                    header("Location: admin_product.php?edit=" . $productId . "&msg=" . urlencode($msg));
                    exit;
                }
            }
        }
    }
}

if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $msg = 'Product delete ho gaya.';
    $msgType = 'success';
} elseif (isset($_GET['msg']) && $_GET['msg'] !== '') {
    $msg = $_GET['msg'];
    $msgType = 'success';
}

// Product being edited (if any) + its gallery images
$editProduct = null;
$galleryImages = [];
if (isset($_GET['edit'])) {
    $eStmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $eStmt->execute([(int) $_GET['edit']]);
    $editProduct = $eStmt->fetch(PDO::FETCH_ASSOC);

    if ($editProduct) {
        $giStmt = $conn->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order ASC");
        $giStmt->execute([(int) $_GET['edit']]);
        $galleryImages = $giStmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Gallery image count per product (for the list table)
$galleryCounts = [];
$gcStmt = $conn->query("SELECT product_id, COUNT(*) AS cnt FROM product_images GROUP BY product_id");
foreach ($gcStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $galleryCounts[$row['product_id']] = (int) $row['cnt'];
}

$pageTitle = 'Admin – Products';
$active = 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin – Products – Apna Karobar System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="products_style.css?v=<?php echo time(); ?>">
</head>
<body style="padding-bottom:30px;">

<header class="bg-white shadow-sm py-3 mb-4">
<div class="container">
<h2 class="fw-bold text-primary m-0">
    <i class="fa-solid fa-screwdriver-wrench"></i>
    Apna<span class="text-dark">Karobar</span> — Admin Panel
</h2>
</div>
</header>

<div class="container">

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="row g-4">

    <!-- ADD / EDIT FORM -->
    <div class="col-lg-4">
        <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="fw-bold mb-3">
                <?= $editProduct ? 'Edit Product' : 'Add New Product' ?>
            </h5>

            <form method="post" enctype="multipart/form-data">
                <?php if ($editProduct): ?>
                    <input type="hidden" name="edit_id" value="<?= (int)$editProduct['id'] ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="name" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Price (Rs.)</label>
                    <input type="number" step="0.01" name="price" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['price'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Product PIN</label>
                    <input type="text" name="pin" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['pin'] ?? '') ?>">
                    <div class="form-text">Ye wahi PIN hai jo buyer registration ke waqt verify hoti hai.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
                </div>

                <div class="mb-3 p-3" style="background:#f7f9f6;border-radius:10px;">
                    <label class="form-label fw-bold mb-2"><i class="fa-solid fa-sitemap text-success"></i> Is Product Ki Commission</label>
                    <div class="form-text mb-2">Har product ki apni commission set karein — fixed 400/200/50 ab zaroori nahi.</div>

                    <label class="form-label small">Direct Commission (Rs.)</label>
                    <input type="number" name="direct_commission" class="form-control mb-2" required
                           value="<?= htmlspecialchars($editProduct['direct_commission'] ?? 400) ?>">

                    <label class="form-label small">Indirect Commission — Buyer upliner ke liye (Rs.)</label>
                    <input type="number" name="indirect_commission_buyer" class="form-control mb-2" required
                           value="<?= htmlspecialchars($editProduct['indirect_commission_buyer'] ?? 200) ?>">

                    <label class="form-label small">Indirect Commission — Reseller upliner ke liye (Rs.)</label>
                    <input type="number" name="indirect_commission_reseller" class="form-control" required
                           value="<?= htmlspecialchars($editProduct['indirect_commission_reseller'] ?? 50) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Main Image (cover photo)</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php if (!empty($editProduct['image'])): ?>
                        <img src="/karobarsystem/assets/images/<?= htmlspecialchars($editProduct['image']) ?>" style="max-width:100px;margin-top:8px;border-radius:8px;">
                        <div class="form-text">Khali chor dein agar cover photo change nahi karni.</div>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">
                        Extra Photos <span class="text-muted">(isi product ke alag angles/photos — ek se zyada select kar sakte hain)</span>
                    </label>
                    <input type="file" name="gallery_images[]" class="form-control" accept="image/*" multiple>
                </div>

                <?php if (!empty($galleryImages)): ?>
                <div class="mb-3">
                    <label class="form-label">Is Product Ki Mojooda Extra Photos</label>
                    <div class="d-flex flex-wrap gap-2">
                        <?php foreach ($galleryImages as $gi): ?>
                        <div style="position:relative;">
                            <img src="/karobarsystem/assets/images/<?= htmlspecialchars($gi['image']) ?>" style="width:70px;height:70px;object-fit:cover;border-radius:8px;border:1px solid #ddd;">
                            <a href="admin_product.php?delete_image=<?= (int)$gi['id'] ?>&back_to=<?= (int)$editProduct['id'] ?>"
                               onclick="return confirm('Ye photo hata dein?');"
                               style="position:absolute;top:-6px;right:-6px;background:#dc3545;color:#fff;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:11px;">
                                <i class="fa-solid fa-xmark"></i>
                            </a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <button type="submit" class="btn btn-primary w-100">
                    <?= $editProduct ? 'Update Product' : 'Add Product' ?>
                </button>

                <?php if ($editProduct): ?>
                    <a href="admin_product.php" class="btn btn-outline-secondary w-100 mt-2">Cancel Edit</a>
                <?php endif; ?>
            </form>
        </div>
        </div>
    </div>

    <!-- PRODUCT LIST -->
    <div class="col-lg-8">
        <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="fw-bold mb-3">All Products (<?= count($products) ?>)</h5>

            <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>PIN</th>
                    <th>Commission</th>
                    <th>Photos</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>
                        <?php if (!empty($p['image'])): ?>
                        <img src="/karobarsystem/assets/images/<?= htmlspecialchars($p['image']) ?>" style="width:50px;height:50px;object-fit:cover;border-radius:8px;">
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td>Rs. <?= number_format($p['price']) ?></td>
                    <td><code><?= htmlspecialchars($p['pin']) ?></code></td>
                    <td class="small">
                        D: Rs.<?= (int)($p['direct_commission'] ?? 0) ?><br>
                        I(B): Rs.<?= (int)($p['indirect_commission_buyer'] ?? 0) ?> · I(R): Rs.<?= (int)($p['indirect_commission_reseller'] ?? 0) ?>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark border">
                            <?= isset($galleryCounts[$p['id']]) ? $galleryCounts[$p['id']] : 0 ?> extra
                        </span>
                    </td>
                    <td>
                        <a href="admin_product.php?edit=<?= (int)$p['id'] ?>" class="btn btn-sm btn-outline-primary">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <a href="admin_product.php?delete=<?= (int)$p['id'] ?>"
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Ye product delete karna hai?');">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                        <a href="details.php?id=<?= (int)$p['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                            <i class="fa-solid fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
    </div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>