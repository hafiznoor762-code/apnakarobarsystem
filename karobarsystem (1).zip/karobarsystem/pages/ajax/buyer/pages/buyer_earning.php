<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/config/db.php';

// Login Check
if (!isset($_SESSION['user_id'])) {
    echo "<p>⚠️ Please login first.</p>";
    exit;
}

$user_id = $_SESSION['user_id'];
?>

<!-- 👇 HTML yahan se start hogi -->
<div class="account-container">

    <h2>💼 Buyer Earning Dashboard</h2>

    <!-- Current Income -->
    <div class="account-box">
        <h3>💰 Current Income</h3>
        <p><strong>Amount:</strong> Rs. 15,000</p>
    </div>

    <!-- Total Income -->
    <div class="account-box">
        <h3>📊 Total Income</h3>
        <p><strong>Amount:</strong> Rs. 75,000</p>
    </div>

    <!-- Total Customers -->
    <div class="account-box">
        <h3>👥 Total Customers</h3>
        <p><strong>Count:</strong> 120 Customers</p>
    </div>

    <!-- Reward Income -->
    <div class="account-box">
        <h3>🎁 Reward Income</h3>
        <p><strong>Amount:</strong> Rs. 10,000</p>
    </div>

    <!-- Total Team -->
    <div class="account-box">
        <h3>🌐 Total Team / Network</h3>
        <p><strong>Members:</strong> 250 People</p>
    </div>

</div>

<!-- ✅ CSS -->
<link rel="stylesheet" href="/karobarsystem/assets/css/buyer_earning.css?v=<?php echo time(); ?>">