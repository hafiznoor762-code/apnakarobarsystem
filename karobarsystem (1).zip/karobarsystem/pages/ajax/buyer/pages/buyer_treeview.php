<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/../../../../config/db.php';

/*
|--------------------------------------------------------------------------
| ENGINE FILES
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../../../engine/tree_count.php';
require_once __DIR__ . '/../../../../engine/tree_render.php';

/*
|--------------------------------------------------------------------------
| LOGIN CHECK
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    echo "<p>⚠️ Please login first.</p>";
    exit;
}

$user_id = $_SESSION['user_id'];
$user_category = $_SESSION['category'] ?? '';

/*
|--------------------------------------------------------------------------
| USER INFO
|--------------------------------------------------------------------------
*/

$user_stmt = $conn->prepare("
    SELECT full_name, email, category
    FROM users
    WHERE id = ?
");

$user_stmt->execute([$user_id]);

$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<p>⚠️ User not found.</p>";
    exit;
}

$user_name = $user['full_name'];
$user_email = $user['email'];
$user_initial = strtoupper(substr($user_name ?: '?', 0, 1));

/*
|--------------------------------------------------------------------------
| TEAM COUNTS
|--------------------------------------------------------------------------
*/

$total_branches    = countBranches($conn, $user_id);
$buyer_branches    = countBuyerBranches($conn, $user_id);
$reseller_branches = countResellerBranches($conn, $user_id);
$direct_team       = countDirectTeam($conn, $user_id);
$indirect_team     = countIndirectTeam($conn, $user_id);

/*
|--------------------------------------------------------------------------
| INCOME
|--------------------------------------------------------------------------
*/

$stmt1 = $conn->prepare("
    SELECT SUM(amount)
    FROM user_earnings
    WHERE user_id = ?
    AND type = 'direct_bonus'
");
$stmt1->execute([$user_id]);
$direct_income = $stmt1->fetchColumn();
$direct_income = $direct_income ?: 0;

$stmt2 = $conn->prepare("
    SELECT SUM(amount)
    FROM user_earnings
    WHERE user_id = ?
    AND type = 'indirect_bonus'
");
$stmt2->execute([$user_id]);
$indirect_income = $stmt2->fetchColumn();
$indirect_income = $indirect_income ?: 0;

?>

<link rel="stylesheet" href="/karobarsystem/assets/css/treeview.css?v=<?php echo time(); ?>">

<div class="tree-page" id="treePage">

    <div class="tree-head">
        <div class="eyebrow">Network</div>
        <h2>My Network Tree</h2>
    </div>

    <!-- ROOT USER -->
    <div class="main-user">
        <div class="root-card">
            <span class="you-badge">You</span>
            <strong><?php echo htmlspecialchars($user_name); ?></strong>
            <small><?php echo htmlspecialchars($user_email); ?></small>
            <br>
            <span class="cat-pill" style="display:inline-block; margin-top:10px;">
                <?php echo htmlspecialchars(ucfirst($user_category)); ?>
            </span>
        </div>
    </div>

    <!-- TEAM STATS -->
    <div class="team-count">
        <div class="stat-chip">
            <div class="icon"><i class="fas fa-sitemap"></i></div>
            <b><?php echo $total_branches; ?></b>
            <span>Total Branches</span>
        </div>
        <div class="stat-chip">
            <div class="icon"><i class="fas fa-user-check"></i></div>
            <b><?php echo $direct_team; ?></b>
            <span>Direct Team</span>
        </div>
        <div class="stat-chip">
            <div class="icon"><i class="fas fa-people-group"></i></div>
            <b><?php echo $indirect_team; ?></b>
            <span>Indirect Team</span>
        </div>
        <div class="stat-chip">
            <div class="icon"><i class="fas fa-cart-shopping"></i></div>
            <b><?php echo $buyer_branches; ?></b>
            <span>Buyers</span>
        </div>
        <div class="stat-chip">
            <div class="icon"><i class="fas fa-handshake"></i></div>
            <b><?php echo $reseller_branches; ?></b>
            <span>Resellers</span>
        </div>
    </div>

    <!-- INCOME -->
    <div class="stat-bar">
        <div class="stat-box left">
            <h3>Indirect Income</h3>
            <p>Rs <?php echo number_format($indirect_income, 2); ?></p>
        </div>
        <div class="stat-box right">
            <h3>Direct Income</h3>
            <p>Rs <?php echo number_format($direct_income, 2); ?></p>
        </div>
    </div>

    <!-- TOOLBAR -->
    <div class="tree-toolbar">
        <div class="tree-search">
            <i class="fas fa-search"></i>
            <input type="text" id="treeSearchInput" placeholder="Naam ya email se search karein...">
        </div>
        <button type="button" class="tree-toolbar-btn" id="expandAllBtn">Expand All</button>
        <button type="button" class="tree-toolbar-btn" id="collapseAllBtn">Collapse All</button>
    </div>

    <!-- TREE -->
    <div class="tree-wrapper">
        <?php renderTree($conn, $user_id); ?>
        <?php if ($total_branches === 0): ?>
            <div class="tree-empty">
                Abhi tak aapki team mein koi member nahi hai. Apna referral link share karein aur network banana shuru karein.
            </div>
        <?php endif; ?>
    </div>

</div>

<script>
(function () {
    const page = document.getElementById('treePage');
    if (!page) return;

    /* ---------- Toggle single branch ---------- */
    page.addEventListener('click', function (e) {
        const btn = e.target.closest('.toggle-btn');
        if (!btn) return;
        const node = btn.closest('.tree-node');
        if (node) node.classList.toggle('is-collapsed');
    });

    /* ---------- Expand all / Collapse all ---------- */
    const expandAllBtn = document.getElementById('expandAllBtn');
    const collapseAllBtn = document.getElementById('collapseAllBtn');

    if (expandAllBtn) {
        expandAllBtn.addEventListener('click', function () {
            page.querySelectorAll('.tree-node.is-collapsed').forEach(n => n.classList.remove('is-collapsed'));
        });
    }
    if (collapseAllBtn) {
        collapseAllBtn.addEventListener('click', function () {
            page.querySelectorAll('.tree-node').forEach(n => {
                if (n.querySelector(':scope > .tree-ul')) n.classList.add('is-collapsed');
            });
        });
    }

    /* ---------- Search ---------- */
    const searchInput = document.getElementById('treeSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const q = this.value.trim().toLowerCase();
            const allNodes = page.querySelectorAll('.tree-node');

            if (!q) {
                page.classList.remove('is-searching');
                allNodes.forEach(n => n.classList.remove('search-match', 'search-ancestor'));
                return;
            }

            page.classList.add('is-searching');
            allNodes.forEach(n => n.classList.remove('search-match', 'search-ancestor'));

            allNodes.forEach(function (node) {
                const key = node.getAttribute('data-search') || '';
                if (key.indexOf(q) !== -1) {
                    node.classList.add('search-match');
                    // mark all ancestor tree-nodes so the path to this match stays visible
                    let parent = node.parentElement;
                    while (parent && parent !== page) {
                        if (parent.classList && parent.classList.contains('tree-node')) {
                            parent.classList.add('search-ancestor');
                        }
                        parent = parent.parentElement;
                    }
                }
            });
        });
    }
})();
</script>