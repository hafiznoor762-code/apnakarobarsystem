<?php
// Agar koi error aaye to seedha screen par dikhe (taake pata chal sake)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once __DIR__ . '/../../../../config/db.php';
require_once __DIR__ . '/../../../../engine/tree_count.php';

// Login check
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../../index.php?page=login");
    exit();
}

$user_id = (int) $_SESSION['user_id'];

// ================= REAL USER DATA (sirf user ka apna data) =================
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("Account not found.");
}

$fullName      = $user['full_name'] ?? 'User';
$email         = $user['email'] ?? '';
$mobile        = $user['mobile'] ?? '';
$whatsapp      = $user['whatsapp'] ?? '';
$city          = $user['city'] ?? '';
$address       = $user['address'] ?? '';
$qualification = $user['qualification'] ?? '';
$category      = $user['category'] ?? '';
$status        = $user['status'] ?? '';
$easypaisaName = $user['easypaisa_name'] ?? '';
$easypaisaNum  = $user['easypaisa_number'] ?? '';
$joinedDate    = $user['created_at'] ?? null;

// ================= REAL EARNINGS & TEAM =================
$earnStmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM user_earnings WHERE user_id = ?");
$earnStmt->execute([$user_id]);
$totalEarnings = (float) $earnStmt->fetchColumn();

$directEarnStmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM user_earnings WHERE user_id = ? AND type = 'direct_bonus'");
$directEarnStmt->execute([$user_id]);
$directEarnings = (float) $directEarnStmt->fetchColumn();

$indirectEarnStmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM user_earnings WHERE user_id = ? AND type = 'indirect_bonus'");
$indirectEarnStmt->execute([$user_id]);
$indirectEarnings = (float) $indirectEarnStmt->fetchColumn();

$directTeam   = countDirectTeam($conn, $user_id);
$indirectTeam = countIndirectTeam($conn, $user_id);

// Recent earning activity (last 8)
$recentStmt = $conn->prepare("
    SELECT ue.amount, ue.type, ue.created_at, u.full_name AS source_name
    FROM user_earnings ue
    LEFT JOIN users u ON u.id = ue.source_user_id
    WHERE ue.user_id = ?
    ORDER BY ue.id DESC
    LIMIT 8
");
$recentStmt->execute([$user_id]);
$recentEarnings = $recentStmt->fetchAll(PDO::FETCH_ASSOC);

// Referral link — category ke hisaab se sahi registration page
$refPage = ($category === 'reseller') ? 'register_reseller' : (($category === 'vendor') ? 'register_vendor' : (($category === 'investor') ? 'register_investor' : 'register_buyer'));
$referralLink = "https://" . $_SERVER['HTTP_HOST'] . "/karobarsystem/index.php?page={$refPage}&ref=" . urlencode($email);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>My Account – Apna Karobar System</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --paper:#e7efe4; --paper-soft:#f7f9f6; --ink:#10140f; --ink-soft:#55605a; --ink-faint:#8a938c;
  --leaf:#2fa83f; --leaf-deep:#146b27; --leaf-bright:#6fd85a; --leaf-mist:#eaf7ea; --leaf-mist-2:#dcf3dc;
  --line:#e7e9e4; --line-strong:#d3d7cf;
  --shadow-sm:0 2px 10px rgba(16,20,15,.06); --shadow-md:0 12px 32px rgba(16,20,15,.10); --shadow-green:0 14px 30px rgba(47,168,63,.28);
  --radius:18px;
  --font-display:"Space Grotesk","IBM Plex Sans",sans-serif; --font-body:"Inter","IBM Plex Sans",sans-serif;
}
*,*::before,*::after{box-sizing:border-box;}
html,body{width:100%;}
body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--font-body);font-size:15px;line-height:1.6;}
a{color:inherit;text-decoration:none;}
h1,h2,h3,h4{font-family:var(--font-display);margin:0 0 6px;letter-spacing:-.01em;font-weight:700;}
table{width:100%;border-collapse:collapse;}
td{padding:9px 0;border-bottom:1px solid var(--line);font-size:13.5px;}
td:first-child{color:var(--ink-faint);width:38%;}
td:last-child{font-weight:600;color:var(--ink);}

/* ---------- Header ---------- */
.top-bar{position:sticky;top:0;z-index:40;background:rgba(255,255,255,.94);backdrop-filter:saturate(180%) blur(10px);border-bottom:1px solid var(--line);padding:14px 16px;width:100%;}
.top-bar-row{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;max-width:1300px;margin:0 auto;flex-wrap:wrap;}
.brand{display:flex;align-items:center;gap:8px;font-family:var(--font-display);font-weight:700;font-size:18px;white-space:nowrap;}
.brand i{color:var(--leaf);}
.search-box{flex:1;min-width:180px;display:flex;align-items:center;background:var(--paper-soft);border:1px solid var(--line-strong);border-radius:999px;padding:8px 14px;gap:8px;}
.search-box input{border:none;background:transparent;outline:none;flex:1;font-size:14px;color:var(--ink);min-width:0;}
.search-box i{color:var(--ink-faint);}
.header-right{display:flex;align-items:center;gap:16px;}
.user-menu{position:relative;}
.user-pill{display:flex;align-items:center;gap:8px;font-weight:700;font-size:13.5px;color:var(--ink);cursor:pointer;padding:7px 14px;border-radius:999px;background:var(--leaf-mist);}
.user-dropdown{position:absolute;right:0;top:calc(100% + 8px);background:#fff;border:1px solid var(--line);border-radius:12px;box-shadow:var(--shadow-md);min-width:170px;padding:6px;display:none;z-index:50;}
.user-menu:hover .user-dropdown{display:block;}
.user-dropdown a{display:flex;align-items:center;gap:8px;padding:9px 12px;border-radius:8px;font-size:13.5px;font-weight:600;color:var(--ink-soft);}
.user-dropdown a:hover{background:var(--leaf-mist);color:var(--leaf-deep);}
.cart-icon{font-size:18px;color:var(--ink-soft);}

/* ---------- Nav ---------- */
.nav-bar{background:var(--ink);width:100%;}
.nav-row{max-width:1300px;margin:0 auto;display:flex;justify-content:center;gap:6px;padding:4px 16px;overflow-x:auto;scrollbar-width:none;}
.nav-row::-webkit-scrollbar{display:none;}
.nav-row a{flex:0 0 auto;padding:12px 18px;font-size:13.5px;font-weight:600;color:#c9d0c8;border-radius:999px;transition:.15s;}
.nav-row a:hover{color:#fff;}
.nav-row a.active{background:var(--leaf);color:#fff;}

.wrap{width:100%;max-width:1300px;margin:0 auto;padding:24px 16px 60px;}

/* ---------- Welcome strip ---------- */
.welcome-strip{background:var(--ink);border-radius:22px;padding:26px 26px 22px;color:#fff;position:relative;overflow:hidden;margin-bottom:20px;}
.welcome-strip::after{content:"";position:absolute;right:-70px;top:-90px;width:280px;height:280px;background:radial-gradient(circle,rgba(47,168,63,.5),transparent 70%);}
.welcome-strip .eyebrow{position:relative;z-index:1;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--leaf-bright);font-weight:700;}
.welcome-strip h3{position:relative;z-index:1;color:#fff;font-size:22px;margin:2px 0 10px;}
.badge{position:relative;z-index:1;display:inline-block;padding:5px 14px;border-radius:999px;font-size:11.5px;font-weight:700;text-transform:capitalize;margin-right:8px;}
.badge.category{background:rgba(255,255,255,.14);color:var(--leaf-bright);}
.badge.status-active{background:var(--leaf);color:#fff;}
.badge.status-inactive{background:rgba(255,255,255,.14);color:#c9d0c8;}

/* ---------- Stats ---------- */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px;}
.stat-card{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px 14px;text-align:center;box-shadow:var(--shadow-sm);}
.stat-card .icon{width:38px;height:38px;border-radius:11px;background:var(--leaf-mist);color:var(--leaf-deep);display:flex;align-items:center;justify-content:center;margin:0 auto 8px;font-size:15px;}
.stat-card b{display:block;font-family:var(--font-display);font-size:19px;}
.stat-card span{display:block;font-size:11px;color:var(--ink-faint);margin-top:2px;text-transform:uppercase;letter-spacing:.04em;}

/* ---------- Cards ---------- */
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px;}
.panel{background:#fff;border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow-sm);overflow:hidden;}
.panel-head{padding:15px 18px;border-bottom:1px solid var(--line);font-family:var(--font-display);font-weight:700;font-size:14.5px;display:flex;align-items:center;gap:8px;}
.panel-head i{color:var(--leaf-deep);}
.panel-body{padding:18px;}

/* ---------- Recent earnings list ---------- */
.earn-item{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--line);}
.earn-item:last-child{border-bottom:none;}
.earn-item .label{font-weight:600;font-size:13.5px;}
.earn-item .label .via{color:var(--ink-faint);font-weight:500;font-size:12px;}
.earn-item .time{font-size:11.5px;color:var(--ink-faint);margin-top:2px;}
.earn-item .amount{color:var(--leaf-deep);font-weight:700;font-size:14px;white-space:nowrap;}
.empty-note{color:var(--ink-faint);font-size:13.5px;}

/* ---------- Progress bars ---------- */
.progress-row{margin-bottom:16px;}
.progress-row:last-child{margin-bottom:0;}
.progress-labels{display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:6px;color:var(--ink-soft);}
.progress-track{background:var(--paper-soft);border-radius:999px;height:8px;overflow:hidden;}
.progress-fill{height:100%;border-radius:999px;}
.progress-fill.direct{background:var(--leaf);}
.progress-fill.indirect{background:var(--ink);}

/* ---------- Referral card ---------- */
.ref-card{background:linear-gradient(135deg,var(--ink),#16201a);border-radius:var(--radius);padding:22px;color:#fff;height:100%;display:flex;flex-direction:column;justify-content:center;}
.ref-card .title{font-weight:700;font-size:15px;margin-bottom:12px;display:flex;align-items:center;gap:8px;}
.ref-card .title i{color:var(--leaf-bright);}
.ref-input-row{display:flex;gap:8px;}
.ref-input-row input{flex:1;min-width:0;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:11px 12px;color:#fff;font-size:12.5px;}
.copy-ref-btn{background:var(--leaf);color:#fff;border:none;padding:0 18px;border-radius:10px;font-weight:700;font-size:13px;cursor:pointer;white-space:nowrap;}
.copy-ref-btn:hover{background:var(--leaf-deep);}
.ref-copied{font-size:12px;color:var(--leaf-bright);margin-top:10px;display:none;}

/* ---------- Responsive ---------- */
@media (max-width:960px){
  .stats-grid{grid-template-columns:repeat(2,1fr);}
  .grid-2{grid-template-columns:1fr;}
}
@media (max-width:560px){
  .welcome-strip h3{font-size:18px;}
  .header-right{gap:10px;}
  .user-pill span{display:none;}
}
</style>
</head>
<body>

<div class="top-bar">
  <div class="top-bar-row">
    <a href="products.php" class="brand"><i class="fas fa-bag-shopping"></i> Apna<span style="color:var(--leaf)">Karobar</span></a>

    <div class="search-box">
      <i class="fas fa-search"></i>
      <form action="search.php" method="GET" style="flex:1;display:flex;min-width:0;">
        <input type="text" name="q" placeholder="Search Products...">
      </form>
    </div>

    <div class="header-right">
      <div class="user-menu">
        <div class="user-pill"><i class="fas fa-circle-user"></i> <span><?= htmlspecialchars($fullName) ?></span></div>
        <div class="user-dropdown">
          <a href="account.php"><i class="fas fa-gauge"></i> My Dashboard</a>
          <a href="../../../index.php?page=logout"><i class="fas fa-right-from-bracket"></i> Logout</a>
        </div>
      </div>
      <a href="cart.php" class="cart-icon"><i class="fas fa-cart-shopping"></i></a>
    </div>
  </div>
</div>

<nav class="nav-bar">
  <div class="nav-row">
    <a href="products.php">Home</a>
    <a href="categories.php">Categories</a>
    <a href="products.php">Products</a>
    <a href="cart.php">Cart</a>
    <a href="account.php" class="active">Account</a>
  </div>
</nav>

<div class="wrap">

  <div class="welcome-strip">
    <div class="eyebrow">Welcome back</div>
    <h3><?= htmlspecialchars($fullName) ?></h3>
    <span class="badge category"><?= htmlspecialchars($category ?: 'user') ?></span>
    <span class="badge <?= $status === 'active' ? 'status-active' : 'status-inactive' ?>"><?= htmlspecialchars($status ?: 'unknown') ?></span>
  </div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="icon"><i class="fas fa-wallet"></i></div>
      <b>Rs <?= number_format($totalEarnings) ?></b><span>Total Earnings</span>
    </div>
    <div class="stat-card">
      <div class="icon"><i class="fas fa-user-check"></i></div>
      <b><?= $directTeam ?></b><span>Direct Team</span>
    </div>
    <div class="stat-card">
      <div class="icon"><i class="fas fa-people-group"></i></div>
      <b><?= $indirectTeam ?></b><span>Indirect Team</span>
    </div>
    <div class="stat-card">
      <div class="icon"><i class="fas fa-sitemap"></i></div>
      <b><?= $directTeam + $indirectTeam ?></b><span>Total Team</span>
    </div>
  </div>

  <div class="grid-2">
    <div class="panel">
      <div class="panel-head"><i class="fas fa-id-card"></i> Profile Information</div>
      <div class="panel-body">
        <table>
          <tr><td>Full Name</td><td><?= htmlspecialchars($fullName) ?></td></tr>
          <tr><td>Email</td><td><?= htmlspecialchars($email) ?></td></tr>
          <tr><td>Mobile</td><td><?= htmlspecialchars($mobile ?: '—') ?></td></tr>
          <tr><td>WhatsApp</td><td><?= htmlspecialchars($whatsapp ?: '—') ?></td></tr>
          <tr><td>City</td><td><?= htmlspecialchars($city ?: '—') ?></td></tr>
          <tr><td>Address</td><td><?= htmlspecialchars($address ?: '—') ?></td></tr>
          <?php if ($qualification): ?><tr><td>Qualification</td><td><?= htmlspecialchars($qualification) ?></td></tr><?php endif; ?>
          <?php if ($easypaisaName || $easypaisaNum): ?><tr><td>Easypaisa</td><td><?= htmlspecialchars($easypaisaName) ?> — <?= htmlspecialchars($easypaisaNum) ?></td></tr><?php endif; ?>
          <?php if ($joinedDate): ?><tr><td>Joined On</td><td><?= htmlspecialchars(date('d M Y', strtotime($joinedDate))) ?></td></tr><?php endif; ?>
        </table>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><i class="fas fa-clock-rotate-left"></i> Recent Earnings</div>
      <div class="panel-body">
        <?php if (empty($recentEarnings)): ?>
          <p class="empty-note">Abhi tak koi earning nahi hui.</p>
        <?php else: ?>
          <?php foreach ($recentEarnings as $e): ?>
            <div class="earn-item">
              <div>
                <div class="label">
                  <?= $e['type'] === 'direct_bonus' ? 'Direct Bonus' : 'Indirect Bonus' ?>
                  <?php if (!empty($e['source_name'])): ?><span class="via">— via <?= htmlspecialchars($e['source_name']) ?></span><?php endif; ?>
                </div>
                <div class="time"><?= htmlspecialchars(date('d M Y, h:i A', strtotime($e['created_at']))) ?></div>
              </div>
              <span class="amount">+Rs <?= number_format($e['amount']) ?></span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="grid-2">
    <div class="panel">
      <div class="panel-head"><i class="fas fa-chart-pie"></i> Earnings Breakdown</div>
      <div class="panel-body">
        <div class="progress-row">
          <div class="progress-labels"><span>Direct Bonus</span><span>Rs <?= number_format($directEarnings) ?></span></div>
          <div class="progress-track"><div class="progress-fill direct" style="width: <?= $totalEarnings > 0 ? round(($directEarnings/$totalEarnings)*100) : 0 ?>%;"></div></div>
        </div>
        <div class="progress-row">
          <div class="progress-labels"><span>Indirect Bonus</span><span>Rs <?= number_format($indirectEarnings) ?></span></div>
          <div class="progress-track"><div class="progress-fill indirect" style="width: <?= $totalEarnings > 0 ? round(($indirectEarnings/$totalEarnings)*100) : 0 ?>%;"></div></div>
        </div>
      </div>
    </div>

    <div class="ref-card">
      <div class="title"><i class="fas fa-share-nodes"></i> Aapki Referral Link</div>
      <div class="ref-input-row">
        <input type="text" id="refLink" value="<?= htmlspecialchars($referralLink) ?>" readonly>
        <button class="copy-ref-btn" id="copyRefBtn">Copy</button>
      </div>
      <div class="ref-copied" id="refCopiedMsg"><i class="fas fa-circle-check"></i> Link copy ho gayi!</div>
    </div>
  </div>

</div>

<script>
document.getElementById('copyRefBtn').addEventListener('click', function () {
    const input = document.getElementById('refLink');
    input.select();
    navigator.clipboard.writeText(input.value).then(function () {
        const msg = document.getElementById('refCopiedMsg');
        msg.style.display = 'block';
        setTimeout(() => { msg.style.display = 'none'; }, 2500);
    });
});
</script>
</body>
</html>