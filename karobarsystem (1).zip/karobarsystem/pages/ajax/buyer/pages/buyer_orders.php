<h2>🛍️ My Orders</h2>

<table border="1" cellpadding="10" cellspacing="0">
<tr>
  <th>Order ID</th>
  <th>Product</th>
  <th>Qty</th>
  <th>Price</th>
  <th>Status</th>
  <th>Date</th>
</tr>

<?php foreach($orders as $order): ?>
<tr>
  <td><?= $order['id'] ?></td>
  <td><?= $order['product_name'] ?></td>
  <td><?= $order['quantity'] ?></td>
  <td><?= $order['price'] ?></td>
  <td><?= $order['status'] ?></td>
  <td><?= $order['created_at'] ?></td>
</tr>
<?php endforeach; ?>

</table>