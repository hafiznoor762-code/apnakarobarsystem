<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/config/db.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/karobarsystem/engine/tree_count.php';

// Login check
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?page=login");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("SELECT full_name, email, profile_image FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$username = htmlspecialchars(
    $user['full_name'] ?? $_SESSION['user_name'] ?? $_SESSION['full_name'] ?? 'User',
    ENT_QUOTES,
    'UTF-8'
);

$profile_image = !empty($user['profile_image'])
    ? '/karobarsystem/uploads/' . htmlspecialchars($user['profile_image'])
    : '';

$user_initial = strtoupper(substr($username, 0, 1));

/* ---------------------------------------------------------
   LIVE EARNING + TEAM STATS
--------------------------------------------------------- */
$s1 = $conn->prepare("SELECT SUM(amount) FROM user_earnings WHERE user_id=? AND type='direct_bonus'");
$s1->execute([$user_id]);
$direct_income = $s1->fetchColumn() ?: 0;

$s2 = $conn->prepare("SELECT SUM(amount) FROM user_earnings WHERE user_id=? AND type='indirect_bonus'");
$s2->execute([$user_id]);
$indirect_income = $s2->fetchColumn() ?: 0;

$total_income   = $direct_income + $indirect_income;
$total_branches = countBranches($conn, $user_id);
$direct_team    = countDirectTeam($conn, $user_id);
$indirect_team  = countIndirectTeam($conn, $user_id);
$buyer_branches = function_exists('countBuyerBranches') ? countBuyerBranches($conn, $user_id) : 0;
$reseller_branches = function_exists('countResellerBranches') ? countResellerBranches($conn, $user_id) : 0;

/* WhatsApp support number */
$support_number_display = '0327 5335960';
$support_number_wa      = '923275335960'; // wa.me format, country code + number
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karobar System – Reseller Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root{
          --paper:#e7efe4; --paper-soft:#f7f9f6; --ink:#10140f; --ink-soft:#55605a; --ink-faint:#8a938c;
          --leaf:#2fa83f; --leaf-deep:#146b27; --leaf-bright:#6fd85a; --leaf-mist:#eaf7ea; --leaf-mist-2:#dcf3dc;
          --line:#e7e9e4; --line-strong:#d3d7cf;
          --shadow-sm:0 2px 10px rgba(16,20,15,.06); --shadow-md:0 12px 32px rgba(16,20,15,.10); --shadow-green:0 14px 30px rgba(47,168,63,.28);
          --radius:18px;
          --font-display:"Space Grotesk","IBM Plex Sans",sans-serif; --font-body:"Inter","IBM Plex Sans",sans-serif;
        }
        *,*::before,*::after{box-sizing:border-box;}
        body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--font-body);}
        a{color:inherit;text-decoration:none;}
        h1,h2,h3,h4{font-family:var(--font-display);margin:0 0 6px;letter-spacing:-.01em;font-weight:700;}

        .main-content{max-width:1180px;margin:0 auto;padding:26px 20px 60px;}

        /* ---------- WELCOME HERO ---------- */
        .welcome-hero{
            background:var(--ink);
            border-radius:24px;
            padding:34px 32px;
            color:#fff;
            position:relative;
            overflow:hidden;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:24px;
            flex-wrap:wrap;
        }
        .welcome-hero::after{
            content:"";
            position:absolute;
            right:-80px; top:-100px;
            width:320px;height:320px;
            background:radial-gradient(circle,rgba(47,168,63,.5),transparent 70%);
        }
        .welcome-left{position:relative;z-index:1;display:flex;align-items:center;gap:18px;}
        .welcome-avatar{
            width:60px;height:60px;border-radius:50%;
            background:linear-gradient(135deg,var(--leaf-bright),var(--leaf-deep));
            display:flex;align-items:center;justify-content:center;
            font-weight:700;font-size:22px;color:#fff;
            border:3px solid rgba(255,255,255,.15);
            flex-shrink:0;
            overflow:hidden;
        }
        .welcome-avatar img{width:100%;height:100%;object-fit:cover;}
        .welcome-eyebrow{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--leaf-bright);font-weight:700;margin-bottom:4px;}
        .welcome-hero h1{font-size:24px;color:#fff;margin-bottom:4px;}
        .welcome-hero p{margin:0;color:#c9d0c8;font-size:14px;max-width:480px;line-height:1.6;}
        .welcome-badge{
            position:relative;z-index:1;
            background:rgba(255,255,255,.1);
            border:1px solid rgba(255,255,255,.14);
            padding:10px 18px;border-radius:999px;
            font-size:12.5px;font-weight:700;color:var(--leaf-bright);
            white-space:nowrap;
        }

        /* ---------- GUIDE / RAHNUMAI ---------- */
        .section-title{margin:34px 0 14px;}
        .section-title h3{font-size:17px;}
        .section-title h3 i{color:var(--leaf-deep);margin-right:6px;}

        .guide-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;}
        .guide-card{
            background:#fff;border:1px solid var(--line);border-radius:var(--radius);
            padding:20px 18px;box-shadow:var(--shadow-sm);position:relative;
        }
        .guide-step{
            width:32px;height:32px;border-radius:50%;
            background:var(--leaf-mist);color:var(--leaf-deep);
            font-family:var(--font-display);font-weight:700;font-size:14px;
            display:flex;align-items:center;justify-content:center;margin-bottom:12px;
        }
        .guide-card h4{font-size:14.5px;margin-bottom:6px;}
        .guide-card p{font-size:12.5px;color:var(--ink-soft);margin:0;line-height:1.55;}

        /* ---------- STATS ---------- */
        .stats-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;}
        .stat-card{
            background:#fff;border:1px solid var(--line);border-radius:16px;
            padding:18px 14px;text-align:center;box-shadow:var(--shadow-sm);
        }
        .stat-card .icon{
            width:42px;height:42px;border-radius:12px;background:var(--leaf-mist);
            display:flex;align-items:center;justify-content:center;margin:0 auto 10px;
            color:var(--leaf-deep);font-size:17px;
        }
        .stat-card b{display:block;font-family:var(--font-display);font-size:20px;}
        .stat-card span{display:block;font-size:11.5px;color:var(--ink-faint);margin-top:2px;text-transform:uppercase;letter-spacing:.04em;}

        .income-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px;}
        .income-card{border-radius:18px;padding:20px 22px;color:#fff;}
        .income-card.indirect{background:var(--ink);}
        .income-card.direct{background:linear-gradient(120deg,var(--leaf),var(--leaf-deep));}
        .income-card .label{font-size:11px;letter-spacing:.1em;text-transform:uppercase;opacity:.85;font-weight:700;}
        .income-card .amount{font-family:var(--font-display);font-size:28px;font-weight:700;margin-top:6px;}

        /* ---------- WHATSAPP SUPPORT ---------- */
        .wa-card{
            margin-top:30px;
            background:linear-gradient(120deg,#1fae55,#128c42);
            border-radius:22px;
            padding:26px 28px;
            color:#fff;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:22px;
            flex-wrap:wrap;
            box-shadow:var(--shadow-green);
        }
        .wa-left{display:flex;align-items:center;gap:16px;}
        .wa-icon{
            width:52px;height:52px;border-radius:50%;background:rgba(255,255,255,.16);
            display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;
        }
        .wa-left h4{font-size:17px;color:#fff;margin-bottom:4px;}
        .wa-left p{margin:0;font-size:13px;color:#e6f6ea;line-height:1.6;max-width:460px;}
        .wa-btn{
            background:#fff;color:#128c42;font-weight:700;font-size:14px;
            padding:12px 24px;border-radius:999px;white-space:nowrap;
            display:flex;align-items:center;gap:8px;
            transition:transform .15s ease;
        }
        .wa-btn:hover{transform:translateY(-2px);}

        /* ---------- RESPONSIVE ---------- */
        @media (max-width:980px){
            .guide-grid{grid-template-columns:repeat(2,1fr);}
            .stats-grid{grid-template-columns:repeat(3,1fr);}
        }
        @media (max-width:640px){
            .welcome-hero{padding:24px 20px;}
            .welcome-hero h1{font-size:19px;}
            .welcome-avatar{width:50px;height:50px;font-size:18px;}
            .guide-grid{grid-template-columns:1fr 1fr;}
            .stats-grid{grid-template-columns:repeat(2,1fr);}
            .income-row{grid-template-columns:1fr;}
            .wa-card{flex-direction:column;text-align:center;}
            .wa-left{flex-direction:column;text-align:center;}
        }
    </style>
</head>
<body>

<main class="main-content">

    <!-- ========== WELCOME HERO ========== -->
    <div class="welcome-hero">
        <div class="welcome-left">
            <div class="welcome-avatar">
                <?php if ($profile_image): ?>
                    <img src="<?= $profile_image ?>" alt="<?= $username ?>">
                <?php else: ?>
                    <?= $user_initial ?>
                <?php endif; ?>
            </div>
            <div>
                <div class="welcome-eyebrow">Welcome back</div>
                <h1>Assalam-o-Alaikum, <?= $username ?> 👋</h1>
                <p>Yahan aapki poori reseller business ki summary hai — earnings, team growth aur guidance, sab ek jagah.</p>
            </div>
        </div>
        <div class="welcome-badge"><i class="fas fa-handshake"></i> Reseller Panel</div>
    </div>

    <!-- ========== RAHNUMAI / GUIDE ========== -->
    <div class="section-title"><h3><i class="fas fa-compass"></i>System Kaise Kaam Karta Hai</h3></div>
    <div class="guide-grid">
        <div class="guide-card">
            <div class="guide-step">1</div>
            <h4>Customer Add Karne Ka Tareeqa</h4>
            <p>Naya customer apna account "Activation Code" se activate karta hai — ye code unhe registration ke waqt dena hota hai.</p>
        </div>
        <div class="guide-card">
            <div class="guide-step">2</div>
            <h4>PIN Code Ka Istemaal</h4>
            <p>Product PIN sirf tab use hoti hai jab koi customer product purchase kare — usi PIN se uska account activate hota hai.</p>
        </div>
        <div class="guide-card">
            <div class="guide-step">3</div>
            <h4>Team Grow, Earning Shuru</h4>
            <p>Jaise jaise team grow hoti hai, direct aur indirect commission aapke account mein add hoti hai.</p>
        </div>
        <div class="guide-card">
            <div class="guide-step">4</div>
            <h4>Track &amp; Withdraw</h4>
            <p>"My Network Tree" aur "Earnings" section se apni saari progress kabhi bhi check karein.</p>
        </div>
    </div>

    <!-- ========== INCOME ========== -->
    <div class="section-title"><h3><i class="fas fa-wallet"></i>My Earnings</h3></div>
    <div class="income-row">
        <div class="income-card indirect">
            <div class="label">Indirect Income</div>
            <div class="amount">Rs <?= number_format($indirect_income, 2) ?></div>
        </div>
        <div class="income-card direct">
            <div class="label">Direct Income</div>
            <div class="amount">Rs <?= number_format($direct_income, 2) ?></div>
        </div>
    </div>

    <!-- ========== TEAM STATS ========== -->
    <div class="section-title"><h3><i class="fas fa-chart-pie"></i>Team Overview</h3></div>
    <div class="stats-grid">
        <div class="stat-card">
            <div class="icon"><i class="fas fa-sitemap"></i></div>
            <b><?= $total_branches ?></b><span>Total Branches</span>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-user-check"></i></div>
            <b><?= $direct_team ?></b><span>Direct Team</span>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-people-group"></i></div>
            <b><?= $indirect_team ?></b><span>Indirect Team</span>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-cart-shopping"></i></div>
            <b><?= $buyer_branches ?></b><span>Buyers</span>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-handshake"></i></div>
            <b><?= $reseller_branches ?></b><span>Resellers</span>
        </div>
    </div>

    <!-- ========== WHATSAPP SUPPORT ========== -->
    <div class="wa-card">
        <div class="wa-left">
            <div class="wa-icon"><i class="fab fa-whatsapp"></i></div>
            <div>
                <h4>Samajh nahi aa raha kaam kaise karna hai?</h4>
                <p>
                    Kisi bhi cheez mein rahnumai chahiye ho, ya earning late aa rahi ho, ya koi shikayat ho —
                    seedha WhatsApp pe <strong><?= $support_number_display ?></strong> par message karein.
                </p>
            </div>
        </div>
        <a class="wa-btn" href="https://wa.me/<?= $support_number_wa ?>" target="_blank" rel="noopener">
            <i class="fab fa-whatsapp"></i> WhatsApp Karein
        </a>
    </div>

</main>

</body>
</html>