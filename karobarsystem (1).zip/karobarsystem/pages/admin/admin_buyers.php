<?php
session_start();
require_once __DIR__ . '/../../config/db.php';

/*
|--------------------------------------------------------------------------
| SIMPLE ACCESS PASSWORD (poora login system nahi — bas ek password box)
|--------------------------------------------------------------------------
| Password change karne ke liye neeche wali line mein 'apna1234' badal dein.
*/
$ACCESS_PASSWORD = 'apna1234';

if (isset($_GET['logout'])) {
    unset($_SESSION['buyers_admin_access']);
    header("Location: admin_buyers.php");
    exit;
}

if (isset($_POST['access_password'])) {
    if ($_POST['access_password'] === $ACCESS_PASSWORD) {
        $_SESSION['buyers_admin_access'] = true;
    } else {
        $accessError = 'Galat password.';
    }
}

if (!isset($_SESSION['buyers_admin_access'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Buyers Admin – Access</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body style="background:#f7f9f6;">
        <div class="d-flex align-items-center justify-content-center" style="min-height:100vh;">
            <div class="card shadow-sm p-4" style="max-width:360px;width:100%;">
                <h5 class="fw-bold mb-3 text-center"><i class="fa-solid fa-lock"></i> Buyers Admin</h5>
                <?php if (!empty($accessError)): ?>
                    <div class="alert alert-danger py-2"><?= htmlspecialchars($accessError) ?></div>
                <?php endif; ?>
                <form method="post">
                    <input type="password" name="access_password" class="form-control mb-3" placeholder="Password" required autofocus>
                    <button type="submit" class="btn btn-primary w-100">Enter</button>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

/*
|--------------------------------------------------------------------------
| SEARCH BY PRODUCT CODE (PIN)
|--------------------------------------------------------------------------
*/
$searchPin = trim($_GET['product_code'] ?? '');

$sql = "
    SELECT
        u.id, u.full_name, u.email, u.mobile, u.whatsapp, u.city, u.address,
        u.qualification, u.status, u.created_at,
        bd.product_pin, bd.purchase_name, bd.purchase_contact, bd.purchase_address, bd.product_qty
    FROM users u
    INNER JOIN buyer_details bd ON bd.user_id = u.id
    WHERE u.category = 'buyer'
";

$params = [];
if ($searchPin !== '') {
    $sql .= " AND bd.product_pin LIKE ?";
    $params[] = '%' . $searchPin . '%';
}
$sql .= " ORDER BY u.id DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$buyers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Buyers Admin – Apna Karobar System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body style="background:#f7f9f6; padding-bottom:30px;">

<header class="bg-white shadow-sm py-3 mb-4">
<div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h2 class="fw-bold text-primary m-0"><i class="fa-solid fa-users"></i> Buyers Admin Panel</h2>
    <a href="admin_buyers.php?logout=1" class="btn btn-sm btn-outline-danger">Lock / Exit</a>
</div>
</header>

<div class="container">

    <!-- SEARCH BY PRODUCT CODE -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="get" class="row g-2 align-items-end">
                <div class="col-sm-8 col-md-5">
                    <label class="form-label">Product Code (PIN) se search karein</label>
                    <input type="text" name="product_code" class="form-control" placeholder="Jaise: 7890" value="<?= htmlspecialchars($searchPin) ?>">
                </div>
                <div class="col-sm-4 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-search"></i> Search</button>
                    <?php if ($searchPin !== ''): ?>
                        <a href="admin_buyers.php" class="btn btn-outline-secondary">Clear</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="fw-bold mb-3">
                Buyers (<?= count($buyers) ?>)
                <?php if ($searchPin !== ''): ?>
                    <span class="text-muted fs-6">— product code "<?= htmlspecialchars($searchPin) ?>" ke liye</span>
                <?php endif; ?>
            </h5>

            <?php if (empty($buyers)): ?>
                <p class="text-muted mb-0">Koi buyer nahi mila.</p>
            <?php else: ?>
            <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>WhatsApp</th>
                    <th>City</th>
                    <th>Address</th>
                    <th>Qualification</th>
                    <th>Product Code</th>
                    <th>Purchaser Name</th>
                    <th>Purchaser Contact</th>
                    <th>Purchaser Address</th>
                    <th>Qty</th>
                    <th>Status</th>
                    <th>Registered</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($buyers as $b): ?>
                <tr>
                    <td class="fw-semibold"><?= htmlspecialchars($b['full_name']) ?></td>
                    <td><?= htmlspecialchars($b['email']) ?></td>
                    <td><?= htmlspecialchars($b['mobile']) ?></td>
                    <td><?= htmlspecialchars($b['whatsapp']) ?></td>
                    <td><?= htmlspecialchars($b['city']) ?></td>
                    <td><?= htmlspecialchars($b['address']) ?></td>
                    <td><?= htmlspecialchars($b['qualification']) ?></td>
                    <td><code><?= htmlspecialchars($b['product_pin']) ?></code></td>
                    <td><?= htmlspecialchars($b['purchase_name']) ?></td>
                    <td><?= htmlspecialchars($b['purchase_contact']) ?></td>
                    <td><?= htmlspecialchars($b['purchase_address']) ?></td>
                    <td><?= htmlspecialchars($b['product_qty']) ?></td>
                    <td>
                        <span class="badge <?= $b['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?> text-capitalize">
                            <?= htmlspecialchars($b['status']) ?>
                        </span>
                    </td>
                    <td class="text-muted small"><?= htmlspecialchars(date('d M Y', strtotime($b['created_at']))) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>

</body>
</html>