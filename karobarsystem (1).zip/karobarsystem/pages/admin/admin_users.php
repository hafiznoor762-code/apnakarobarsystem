<?php
session_start();
require_once __DIR__ . '/../../config/db.php';

// ⚠️ Is page ko sirf admin dekh sake, is liye login system ban jaने par
// ye guard zaroor enable kar dein (abhi commented hai taake test kar sakein):
// if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
//     die("Access Denied");
// }

$message = '';

// ---------------- HANDLE: Set / Update unlock code ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_code'])) {
    $user_id  = intval($_POST['user_id']);
    $new_code = trim($_POST['new_code']);

    if ($user_id > 0 && $new_code !== '') {
        // Sirf EK code save hota hai (overwrite) — activation check exact
        // match karta hai, is liye comma-list wala tareeqa yahan nahi chalega.
        $update = $conn->prepare("UPDATE users SET unlock_codes = :code WHERE id = :id");
        $update->execute([':code' => $new_code, ':id' => $user_id]);
        $message = "success:Unlock code User ID $user_id ke liye save ho gaya.";
    } else {
        $message = "error:User ID aur code dono zaroori hain.";
    }
}

// ---------------- FILTERS ----------------
$category = $_GET['cat'] ?? 'all';
$search   = trim($_GET['q'] ?? '');

$allowedCategories = ['all', 'reseller', 'buyer', 'vendor', 'investor'];
if (!in_array($category, $allowedCategories, true)) {
    $category = 'all';
}

$where  = [];
$params = [];

if ($category !== 'all') {
    $where[] = "category = :category";
    $params[':category'] = $category;
}

if ($search !== '') {
    $where[] = "(full_name LIKE :search OR email LIKE :search)";
    $params[':search'] = "%$search%";
}

$sql = "SELECT id, full_name, email, mobile, category, status, unlock_codes, product_code, created_at
        FROM users";
if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ---------------- Quick counts for the tabs ----------------
$counts = $conn->query("SELECT category, COUNT(*) AS c FROM users GROUP BY category")
               ->fetchAll(PDO::FETCH_KEY_PAIR);
$totalCount = array_sum($counts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin — Users</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --paper: #ffffff;
  --paper-soft: #f7f9f6;
  --ink: #10140f;
  --ink-soft: #55605a;
  --ink-faint: #8a938c;
  --leaf: #2fa83f;
  --leaf-deep: #146b27;
  --leaf-bright: #6fd85a;
  --leaf-mist: #eaf7ea;
  --leaf-mist-2: #dcf3dc;
  --line: #e7e9e4;
  --line-strong: #d3d7cf;
  --shadow-sm: 0 2px 10px rgba(16, 20, 15, 0.06);
  --shadow-md: 0 12px 32px rgba(16, 20, 15, 0.10);
  --radius: 16px;
  --radius-sm: 10px;
  --font-display: "Space Grotesk", "IBM Plex Sans", sans-serif;
  --font-body: "Inter", "IBM Plex Sans", sans-serif;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--paper-soft);
  color: var(--ink);
  font-family: var(--font-body);
  font-size: 15px;
  line-height: 1.5;
  padding: 28px 20px 60px;
}
h1 {
  font-family: var(--font-display);
  font-size: 26px;
  margin: 0 0 4px;
}
.sub { color: var(--ink-soft); margin: 0 0 22px; font-size: 14px; }
.container { max-width: 1200px; margin: 0 auto; }

.alert {
  padding: 12px 16px;
  border-radius: var(--radius-sm);
  margin-bottom: 18px;
  font-weight: 600;
  font-size: 14px;
}
.alert.success { background: var(--leaf-mist); color: var(--leaf-deep); border: 1px solid var(--leaf); }
.alert.error   { background: #fdeceb; color: #b3261e; border: 1px solid #f3b3ae; }

.toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 18px;
}
.tabs { display: flex; gap: 8px; flex-wrap: wrap; }
.tab {
  padding: 8px 16px;
  border-radius: 999px;
  background: var(--paper);
  border: 1px solid var(--line);
  color: var(--ink-soft);
  font-size: 13.5px;
  font-weight: 600;
  text-decoration: none;
  white-space: nowrap;
}
.tab.active {
  background: var(--leaf);
  border-color: var(--leaf);
  color: #fff;
}
.tab .count { opacity: 0.75; font-weight: 500; margin-left: 4px; }

.search-box form { display: flex; gap: 8px; }
.search-box input[type="text"] {
  padding: 9px 12px;
  border-radius: var(--radius-sm);
  border: 1px solid var(--line-strong);
  font-family: var(--font-body);
  font-size: 14px;
  min-width: 220px;
}
.search-box button {
  padding: 9px 16px;
  border-radius: var(--radius-sm);
  border: none;
  background: var(--ink);
  color: #fff;
  font-weight: 600;
  cursor: pointer;
  font-size: 14px;
}

.table-wrap {
  background: var(--paper);
  border-radius: var(--radius);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--line);
  overflow-x: auto;
}
table { width: 100%; border-collapse: collapse; min-width: 900px; }
thead th {
  text-align: left;
  font-family: var(--font-display);
  font-size: 12.5px;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ink-soft);
  padding: 14px 16px;
  border-bottom: 1px solid var(--line);
  background: var(--paper-soft);
  white-space: nowrap;
}
tbody td {
  padding: 12px 16px;
  border-bottom: 1px solid var(--line);
  font-size: 14px;
  vertical-align: middle;
}
tbody tr:last-child td { border-bottom: none; }
tbody tr:hover { background: var(--leaf-mist); }

.name { font-weight: 700; }
.email { color: var(--ink-soft); font-size: 13px; }

.badge {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  text-transform: capitalize;
}
.badge.reseller { background: var(--leaf-mist);   color: var(--leaf-deep); }
.badge.buyer    { background: #eaf2fb;            color: #1b5fa8; }
.badge.vendor   { background: #f4eafb;            color: #6a2ba8; }
.badge.investor { background: #fbf3ea;            color: #a8641b; }

.status { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 12px; font-weight: 700; }
.status.active  { background: var(--leaf-mist-2); color: var(--leaf-deep); }
.status.pending { background: #fdf3e3; color: #a8721b; }
.status.other   { background: var(--line); color: var(--ink-soft); }

.code-form { display: flex; gap: 6px; align-items: center; }
.code-form input[type="text"] {
  padding: 7px 10px;
  border-radius: var(--radius-sm);
  border: 1px solid var(--line-strong);
  font-size: 13px;
  width: 130px;
  font-family: var(--font-body);
}
.code-form button {
  padding: 7px 12px;
  border-radius: var(--radius-sm);
  border: none;
  background: var(--leaf);
  color: #fff;
  font-weight: 700;
  font-size: 12.5px;
  cursor: pointer;
  white-space: nowrap;
}
.code-form button:hover { background: var(--leaf-deep); }
.current-code {
  font-size: 11.5px;
  color: var(--ink-faint);
  margin-top: 4px;
}
.current-code b { color: var(--ink-soft); }

.dash { color: var(--ink-faint); }
.empty-row td { text-align: center; padding: 40px; color: var(--ink-faint); }
</style>
</head>
<body>
<div class="container">

  <h1>Users</h1>
  <p class="sub">Reseller, Buyer, Vendor aur Investor — sab naye registered users yahan dikhenge.</p>

  <?php if ($message): ?>
    <?php [$type, $text] = explode(':', $message, 2); ?>
    <div class="alert <?php echo $type; ?>"><?php echo htmlspecialchars($text); ?></div>
  <?php endif; ?>

  <div class="toolbar">
    <div class="tabs">
      <?php foreach (['all' => 'All', 'reseller' => 'Reseller', 'buyer' => 'Buyer', 'vendor' => 'Vendor', 'investor' => 'Investor'] as $key => $label): ?>
        <?php $c = $key === 'all' ? $totalCount : ($counts[$key] ?? 0); ?>
        <a class="tab <?php echo $category === $key ? 'active' : ''; ?>"
           href="?cat=<?php echo $key; ?><?php echo $search !== '' ? '&q=' . urlencode($search) : ''; ?>">
          <?php echo $label; ?><span class="count">(<?php echo $c; ?>)</span>
        </a>
      <?php endforeach; ?>
    </div>

    <div class="search-box">
      <form method="get">
        <input type="hidden" name="cat" value="<?php echo htmlspecialchars($category); ?>">
        <input type="text" name="q" placeholder="Naam ya email search karein" value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">Search</button>
      </form>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Mobile</th>
          <th>Category</th>
          <th>Status</th>
          <th>Registered On</th>
          <th>Unlock Code</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$users): ?>
          <tr class="empty-row"><td colspan="7">Koi user nahi mila.</td></tr>
        <?php endif; ?>

        <?php foreach ($users as $u): ?>
          <tr>
            <td>#<?php echo (int) $u['id']; ?></td>
            <td>
              <div class="name"><?php echo htmlspecialchars($u['full_name']); ?></div>
              <div class="email"><?php echo htmlspecialchars($u['email']); ?></div>
            </td>
            <td><?php echo $u['mobile'] ? htmlspecialchars($u['mobile']) : '<span class="dash">—</span>'; ?></td>
            <td><span class="badge <?php echo htmlspecialchars($u['category']); ?>"><?php echo htmlspecialchars($u['category']); ?></span></td>
            <td>
              <?php
                $statusClass = $u['status'] === 'active' ? 'active' : ($u['status'] === 'pending' ? 'pending' : 'other');
              ?>
              <span class="status <?php echo $statusClass; ?>"><?php echo htmlspecialchars($u['status'] ?: 'pending'); ?></span>
            </td>
            <td><?php echo $u['created_at'] ? date('d M Y, h:i A', strtotime($u['created_at'])) : '<span class="dash">—</span>'; ?></td>
            <td>
              <?php if ($u['category'] === 'buyer'): ?>
                <form class="code-form" method="post">
                  <input type="hidden" name="user_id" value="<?php echo (int) $u['id']; ?>">
                  <input type="text" name="new_code" placeholder="Code" value="<?php echo htmlspecialchars($u['unlock_codes'] ?? ''); ?>" required>
                  <button type="submit" name="set_code" value="1">Save</button>
                </form>
                <?php if (!empty($u['unlock_codes'])): ?>
                  <div class="current-code">Current: <b><?php echo htmlspecialchars($u['unlock_codes']); ?></b></div>
                <?php endif; ?>
              <?php else: ?>
                <span class="dash">—</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</div>
</body>
</html>