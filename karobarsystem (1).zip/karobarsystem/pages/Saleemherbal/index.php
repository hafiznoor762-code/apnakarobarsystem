<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Saleem Herbal | Pure Herbal Remedies</title>
<meta name="description" content="Saleem Herbal - natural herbal products: honey, black seed oil, herbal teas, powders and skin care.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Source+Sans+3:wght@400;600;700&family=Noto+Nastaliq+Urdu:wght@500;700&display=swap" rel="stylesheet">
<style>
:root{
  --forest:#17372A; --leaf:#2F6B45; --moss:#7A8F3C; --haldi:#E6A817; --haldi-soft:#F8E2A3;
  --paper:#F5F7F0; --card:#FFFFFF; --ink:#12211A; --muted:#55645A; --line:#D9E0D0;
  --display:"Bricolage Grotesque","Trebuchet MS",system-ui,sans-serif;
  --body:"Source Sans 3","Segoe UI",system-ui,sans-serif;
  --urdu:"Noto Nastaliq Urdu","Jameel Noori Nastaleeq",serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;scroll-padding-top:84px}
body{font-family:var(--body);background:var(--paper);color:var(--ink);line-height:1.6;font-size:17px}
img,svg{max-width:100%;display:block}
a{color:inherit}
:focus-visible{outline:3px solid var(--haldi);outline-offset:3px;border-radius:6px}
.wrap{width:min(1180px,92%);margin-inline:auto}
button{font:inherit;cursor:pointer}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;border:0;border-radius:999px;padding:.8rem 1.5rem;font-weight:700;text-decoration:none;transition:transform .15s,background .15s}
.btn:active{transform:scale(.97)}
.btn-gold{background:var(--haldi);color:var(--ink)}
.btn-gold:hover{background:#f0b626}
.btn-dark{background:var(--forest);color:#fff}
.btn-dark:hover{background:var(--leaf)}
.btn-line{background:transparent;border:2px solid var(--forest);color:var(--forest)}
.btn-line:hover{background:var(--forest);color:#fff}

/* TOP BAR */
.topbar{background:var(--forest);color:#e9f0e2;font-size:.9rem}
.topbar .wrap{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.5rem 0;flex-wrap:wrap}
.topbar b{color:var(--haldi-soft)}
.topbar a{text-decoration:none}
.topbar a:hover{text-decoration:underline}
.top-right{display:flex;gap:1.2rem}

/* NAV */
header.nav{position:sticky;top:0;z-index:50;background:rgba(245,247,240,.94);backdrop-filter:blur(8px);border-bottom:1px solid var(--line);padding-top:env(safe-area-inset-top,0px)}
.nav .wrap{display:flex;align-items:center;justify-content:space-between;gap:1rem;height:72px}
.logo{display:flex;align-items:center;gap:.6rem;text-decoration:none;font-family:var(--display);font-weight:800;font-size:1.45rem;color:var(--forest);letter-spacing:-.02em}
.logo small{display:block;font-family:var(--urdu);font-size:.8rem;font-weight:500;color:var(--moss);line-height:1.2}
.links{display:flex;gap:1.6rem;list-style:none;font-weight:600}
.links a{text-decoration:none;color:var(--ink);padding:.3rem 0;border-bottom:2px solid transparent}
.links a:hover{border-color:var(--haldi)}
.nav-actions{display:flex;align-items:center;gap:.6rem}
.icon-btn{position:relative;background:var(--card);border:1px solid var(--line);border-radius:999px;height:44px;min-width:44px;padding:0 .9rem;display:inline-flex;align-items:center;gap:.4rem;color:var(--forest);font-weight:700}
.icon-btn .count{background:var(--haldi);color:var(--ink);border-radius:999px;min-width:22px;height:22px;display:grid;place-items:center;font-size:.8rem}
.burger{display:none}

/* HERO */
.hero{padding:clamp(2.5rem,6vw,5rem) 0 clamp(2.5rem,5vw,4rem);overflow:hidden}
.hero .wrap{display:grid;grid-template-columns:1.05fr .95fr;gap:2rem;align-items:center}
.hero h1{font-family:var(--display);font-weight:800;font-size:clamp(2.4rem,5.6vw,4.4rem);line-height:1.02;letter-spacing:-.035em;color:var(--forest)}
.hero .urdu{font-family:var(--urdu);font-size:1.5rem;color:var(--moss);margin:.8rem 0 .4rem;line-height:2}
.hero p.lead{max-width:34rem;color:var(--muted);font-size:1.15rem;margin-bottom:1.6rem}
.hero .cta{display:flex;flex-wrap:wrap;gap:.8rem}
.hero-art{position:relative;aspect-ratio:1/1;max-width:520px;margin-inline:auto;width:100%}
.hero-art .sun{position:absolute;inset:6%;border-radius:50%;background:var(--haldi-soft)}
.hero-art .sun::after{content:"";position:absolute;inset:14%;border-radius:50%;border:2px dashed rgba(23,55,42,.25)}
.hero-art svg{position:absolute;inset:0;width:100%;height:100%}
.stamp{position:absolute;right:2%;bottom:6%;background:var(--forest);color:#fff;border-radius:50%;width:118px;height:118px;display:grid;place-items:center;text-align:center;font-family:var(--display);font-weight:700;font-size:.95rem;line-height:1.15;transform:rotate(-8deg);box-shadow:0 0 0 6px var(--paper)}
.stamp span{display:block;font-size:1.7rem;color:var(--haldi)}

/* TRUST */
.trust{background:var(--card);border-block:1px solid var(--line)}
.trust .wrap{display:grid;grid-template-columns:repeat(4,1fr);gap:1.2rem;padding:1.4rem 0}
.trust-item{display:flex;gap:.8rem;align-items:center}
.trust-item svg{flex:none;width:38px;height:38px;color:var(--leaf)}
.trust-item b{display:block;font-family:var(--display);font-size:1.02rem}
.trust-item span{color:var(--muted);font-size:.92rem;line-height:1.3;display:block}

/* SECTIONS */
section{padding:clamp(3rem,6vw,5rem) 0}
.sec-head{display:flex;justify-content:space-between;align-items:end;gap:1rem;flex-wrap:wrap;margin-bottom:1.8rem}
.sec-head h2{font-family:var(--display);font-weight:800;font-size:clamp(1.8rem,3.6vw,2.6rem);letter-spacing:-.03em;color:var(--forest);line-height:1.1}
.sec-head p{color:var(--muted);max-width:32rem}

/* SHOP TOOLS */
.tools{display:flex;gap:1rem;flex-wrap:wrap;align-items:center;margin-bottom:1.6rem}
.chips{display:flex;gap:.5rem;flex-wrap:wrap}
.chip{border:1.5px solid var(--line);background:var(--card);border-radius:999px;padding:.45rem 1rem;font-weight:600;color:var(--ink)}
.chip[aria-pressed="true"]{background:var(--forest);border-color:var(--forest);color:#fff}
.search{margin-left:auto;flex:1 1 220px;max-width:320px;border:1.5px solid var(--line);border-radius:999px;padding:.6rem 1.1rem;background:var(--card);font:inherit}

/* PRODUCTS */
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:1.4rem}
.card{background:var(--card);border:1px solid var(--line);border-radius:18px;overflow:hidden;display:flex;flex-direction:column}
.card .pic{aspect-ratio:1/1;background:var(--tint,#eef2e6);display:grid;place-items:center;position:relative;overflow:hidden}
.card .pic img{width:100%;height:100%;object-fit:cover}
.card .pic svg{width:62%}
.tag{position:absolute;top:.8rem;left:.8rem;background:var(--forest);color:#fff;border-radius:999px;font-size:.78rem;font-weight:700;padding:.15rem .7rem}
.tag.new{background:var(--haldi);color:var(--ink)}
.card .body{padding:1rem 1.1rem 1.2rem;display:flex;flex-direction:column;gap:.35rem;flex:1}
.card h3{font-family:var(--display);font-size:1.15rem;line-height:1.2;letter-spacing:-.01em}
.card .cat{color:var(--moss);font-weight:700;font-size:.85rem}
.card p{color:var(--muted);font-size:.95rem;line-height:1.45;flex:1}
.card .row{display:flex;justify-content:space-between;align-items:center;margin-top:.6rem;gap:.5rem}
.price{font-family:var(--display);font-weight:800;font-size:1.25rem;color:var(--forest)}
.card .btn{padding:.5rem 1.05rem;font-size:.95rem}
.remove{background:none;border:0;color:#a03a3a;text-decoration:underline;font-size:.85rem;align-self:flex-start;margin-top:.3rem}
.empty{grid-column:1/-1;text-align:center;color:var(--muted);padding:2rem;border:2px dashed var(--line);border-radius:18px}

/* UPLOAD */
.upload{background:var(--forest);color:#fff}
.upload .sec-head h2{color:#fff}
.upload .sec-head p{color:#c6d5bf}
.up-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:2rem;align-items:start}
.form{background:var(--card);color:var(--ink);border-radius:20px;padding:clamp(1.2rem,3vw,2rem);display:grid;gap:1rem}
.form .two{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
label{display:grid;gap:.3rem;font-weight:700;font-size:.95rem}
input[type=text],input[type=number],select,textarea{font:inherit;border:1.5px solid var(--line);border-radius:12px;padding:.65rem .85rem;background:#fff;width:100%}
textarea{resize:vertical;min-height:90px}
.drop{border:2px dashed #b5c3a9;border-radius:14px;padding:1.2rem;text-align:center;color:var(--muted);background:#f8faf4;cursor:pointer;display:grid;gap:.3rem;place-items:center}
.drop:hover,.drop.over{border-color:var(--leaf);background:#eef4e6}
.drop input{display:none}
.preview-box{position:sticky;top:96px}
.preview-box h3{font-family:var(--display);margin-bottom:.8rem;color:var(--haldi-soft);font-size:1.1rem}
.preview-box .card{color:var(--ink)}
.note{font-size:.88rem;color:#c6d5bf;margin-top:1rem}

/* ABOUT */
.about .wrap{display:grid;grid-template-columns:1fr 1fr;gap:3rem;align-items:center}
.about p{color:var(--muted);margin-bottom:1rem}
.about .points{list-style:none;display:grid;gap:.6rem;margin:1.2rem 0 1.6rem}
.about .points li{display:flex;gap:.7rem;align-items:flex-start}
.about .points svg{flex:none;width:22px;height:22px;color:var(--leaf);margin-top:3px}
.about-art{background:var(--haldi-soft);border-radius:28px;padding:2rem;aspect-ratio:1/1;display:grid;place-items:center}

/* REVIEWS */
.reviews{background:var(--card);border-block:1px solid var(--line)}
.rev-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.4rem}
.rev{border-left:4px solid var(--haldi);padding:.2rem 0 .2rem 1.2rem}
.rev p{font-size:1.05rem;margin-bottom:.6rem}
.rev b{color:var(--forest)}
.rev small{color:var(--muted);display:block}

/* CONTACT */
.contact .wrap{display:grid;grid-template-columns:1fr 1fr;gap:2.4rem}
.contact ul{list-style:none;display:grid;gap:.8rem;margin:1.2rem 0}
.contact li b{display:block;color:var(--forest)}
.contact .form{border:1px solid var(--line)}

/* FOOTER */
footer{background:#0F2A1F;color:#cfdcc8}
.foot-main{display:grid;grid-template-columns:1.4fr 1fr 1fr 1.2fr;gap:2rem;padding:3.2rem 0 2.4rem}
footer h4{font-family:var(--display);color:#fff;margin-bottom:.8rem;font-size:1.05rem}
footer ul{list-style:none;display:grid;gap:.5rem}
footer a{text-decoration:none}
footer a:hover{color:var(--haldi-soft);text-decoration:underline}
footer .logo{color:#fff;margin-bottom:.8rem}
footer p{font-size:.95rem;max-width:22rem}
.social{display:flex;gap:.6rem;margin-top:1rem}
.social a{width:42px;height:42px;border-radius:50%;border:1.5px solid #3f5f4d;display:grid;place-items:center;color:#fff}
.social a:hover{background:var(--haldi);border-color:var(--haldi);color:var(--ink)}
.social svg{width:20px;height:20px}
.foot-bar{border-top:1px solid #23443419;background:#0a1f16}
.foot-bar .wrap{display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;padding:1rem 0;font-size:.9rem}
.foot-bar .legal{display:flex;gap:1.2rem;flex-wrap:wrap}
.disclaimer{font-size:.82rem;color:#93a89a;padding-bottom:1.2rem;max-width:60rem}

/* CART DRAWER */
.overlay{position:fixed;inset:0;background:rgba(10,25,18,.5);opacity:0;pointer-events:none;transition:opacity .2s;z-index:80}
.overlay.open{opacity:1;pointer-events:auto}
.drawer{position:fixed;top:0;right:0;height:100%;width:min(420px,100%);background:var(--card);z-index:90;transform:translateX(100%);transition:transform .25s;display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
.drawer.open{transform:none}
.drawer header{display:flex;justify-content:space-between;align-items:center;padding:1rem 1.2rem;border-bottom:1px solid var(--line)}
.drawer h3{font-family:var(--display);font-size:1.3rem}
.drawer .items{flex:1;overflow:auto;padding:1rem 1.2rem;display:grid;gap:1rem;align-content:start}
.line{display:grid;grid-template-columns:64px 1fr auto;gap:.8rem;align-items:center}
.line .thumb{width:64px;height:64px;border-radius:12px;background:#eef2e6;overflow:hidden;display:grid;place-items:center}
.line .thumb img{width:100%;height:100%;object-fit:cover}
.line .thumb svg{width:70%}
.qty{display:inline-flex;align-items:center;gap:.5rem;margin-top:.2rem}
.qty button{width:28px;height:28px;border-radius:50%;border:1.5px solid var(--line);background:#fff}
.drawer footer{background:#fff;color:var(--ink);padding:1rem 1.2rem;border-top:1px solid var(--line);display:grid;gap:.8rem}
.total{display:flex;justify-content:space-between;font-weight:700;font-size:1.15rem}

/* FLOAT + TOAST */
.wa-float{position:fixed;right:1rem;bottom:calc(1rem + env(safe-area-inset-bottom,0px));z-index:60;background:#25D366;color:#fff;width:56px;height:56px;border-radius:50%;display:grid;place-items:center;box-shadow:0 6px 18px rgba(0,0,0,.25)}
.wa-float svg{width:28px;height:28px}
.toast{position:fixed;left:50%;bottom:calc(1.4rem + env(safe-area-inset-bottom,0px));transform:translate(-50%,140%);background:var(--ink);color:#fff;padding:.7rem 1.2rem;border-radius:999px;z-index:100;transition:transform .25s;font-weight:600;max-width:90%}
.toast.show{transform:translate(-50%,0)}

/* RESPONSIVE */
@media (max-width:900px){
  .hero .wrap,.up-grid,.about .wrap,.contact .wrap{grid-template-columns:1fr}
  .hero-art{max-width:380px;order:-1}
  .trust .wrap{grid-template-columns:1fr 1fr}
  .rev-grid{grid-template-columns:1fr}
  .foot-main{grid-template-columns:1fr 1fr}
  .preview-box{position:static}
}
@media (max-width:760px){
  .burger{display:inline-flex}
  .links{display:none;position:absolute;top:100%;left:0;right:0;background:var(--paper);flex-direction:column;gap:0;border-bottom:1px solid var(--line);padding:.5rem 4%}
  .links.open{display:flex}
  .links a{display:block;padding:.8rem 0}
  .top-right{display:none}
  .form .two{grid-template-columns:1fr}
  .foot-main{grid-template-columns:1fr}
}
@media (prefers-reduced-motion:reduce){*{transition:none!important;scroll-behavior:auto!important}}
</style>
</head>
<body>

<!-- TOP BAR (announcement bar) -->
<div class="topbar">
  <div class="wrap">
    <span><b>Free delivery</b> on orders above Rs. 3,000</span>
    <div class="top-right">
      <a href="tel:+923007993068">Call: 03007993068</a>
      <a href="#contact">Contact us</a>
    </div>
  </div>
</div>

<!-- NAVIGATION -->
<header class="nav">
  <div class="wrap">
    <a class="logo" href="#top" aria-label="Saleem Herbal home">
      <svg width="38" height="38" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="20" fill="#17372A"/><path d="M20 31V18M20 22c-5 0-8-3-8-8 5 0 8 3 8 8zm0 4c5 0 8-3 8-8-5 0-8 3-8 8z" fill="none" stroke="#E6A817" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <span>Saleem Herbal<small>قدرت کی شفا</small></span>
    </a>
    <ul class="links" id="links">
      <li><a href="#shop">Shop</a></li>
      <li><a href="#upload">Add product</a></li>
      <li><a href="#about">About</a></li>
      <li><a href="#reviews">Reviews</a></li>
      <li><a href="#contact">Contact</a></li>
    </ul>
    <div class="nav-actions">
      <button class="icon-btn" id="cartBtn" aria-label="Open cart">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 4h2l2.4 11h10.2L20 7H6.2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/></svg>
        Cart <span class="count" id="cartCount">0</span>
      </button>
      <button class="icon-btn burger" id="burger" aria-label="Menu" aria-expanded="false">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
    </div>
  </div>
</header>

<main id="top">
<!-- HERO -->
<div class="hero">
  <div class="wrap">
    <div>
      <h1>Pure herbs, prepared the honest way.</h1>
      <p class="urdu">خالص جڑی بوٹیاں، اعتماد کے ساتھ</p>
      <p class="lead">Honey, black seed oil, herbal teas and powders, made in small batches and sent to your door. Simple ingredients, clearly listed.</p>
      <div class="cta">
        <a class="btn btn-gold" href="#shop">Shop products</a>
        <a class="btn btn-line" href="#about">Our story</a>
      </div>
    </div>
    <div class="hero-art" aria-hidden="true">
      <div class="sun"></div>
      <svg viewBox="0 0 400 400">
        <!-- mortar -->
        <path d="M80 250h240c0 60-40 100-120 100S80 310 80 250z" fill="#17372A"/>
        <rect x="70" y="238" width="260" height="20" rx="10" fill="#2F6B45"/>
        <!-- pestle -->
        <g transform="rotate(28 280 200)"><rect x="268" y="90" width="26" height="160" rx="13" fill="#C98F14"/><circle cx="281" cy="90" r="20" fill="#E6A817"/></g>
        <!-- herb sprigs -->
        <g fill="none" stroke="#2F6B45" stroke-width="5" stroke-linecap="round"><path d="M150 240C140 190 150 140 170 100"/><path d="M200 240C205 180 215 130 235 80"/></g>
        <g fill="#7A8F3C"><path d="M170 100c-30-4-42-26-40-44 24 2 40 18 40 44z"/><path d="M165 140c26-8 44 4 52 22-24 10-46 2-52-22z"/><path d="M154 180c-26-6-38-22-38-40 24 0 38 14 38 40z"/><path d="M235 80c-4-30 10-48 28-54 8 24-4 44-28 54z"/><path d="M212 140c-24-6-36-24-34-40 22 0 36 14 34 40z"/><path d="M206 190c24-8 42 2 50 20-22 10-44 4-50-20z"/></g>
        <circle cx="110" cy="200" r="7" fill="#E6A817"/><circle cx="320" cy="150" r="9" fill="#17372A"/><circle cx="96" cy="120" r="5" fill="#17372A"/>
      </svg>
      <div class="stamp"><div>100%<span>natural</span>no fillers</div></div>
    </div>
  </div>
</div>

<!-- TRUST STRIP -->
<div class="trust">
  <div class="wrap">
    <div class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21V11M12 14c-4 0-6-2.5-6-6 4 0 6 2.5 6 6zm0 3c4 0 6-2.5 6-6-4 0-6 2.5-6 6z"/></svg><div><b>Natural ingredients</b><span>Every label lists what is inside</span></div></div>
    <div class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="7" width="12" height="9" rx="1"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/></svg><div><b>Home delivery</b><span>Cash on delivery available</span></div></div>
    <div class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg><div><b>Small batches</b><span>Packed fresh, not stored for months</span></div></div>
    <div class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h16v11H9l-5 4z"/></svg><div><b>Ask before you buy</b><span>Message us on WhatsApp anytime</span></div></div>
  </div>
</div>

<!-- SHOP -->
<section id="shop">
  <div class="wrap">
    <div class="sec-head">
      <h2>Our products</h2>
      <p>Choose a category or search by name. Add items to the cart and send your order on WhatsApp.</p>
    </div>
    <div class="tools">
      <div class="chips" id="chips" role="group" aria-label="Filter by category"></div>
      <input class="search" id="search" type="search" placeholder="Search products" aria-label="Search products">
    </div>
    <div class="grid" id="grid"></div>
  </div>
</section>

<!-- PRODUCT UPLOAD -->
<section class="upload" id="upload">
  <div class="wrap">
    <div class="sec-head">
      <h2>Add a new product</h2>
      <p>Fill in the details and add a photo. The product appears in the shop straight away, and you can check how it looks on the right.</p>
    </div>
    <div class="up-grid">
      <form class="form" id="prodForm" autocomplete="off">
        <label>Product name
          <input type="text" id="fName" placeholder="e.g. Pure Sidr Honey 500g" required maxlength="60">
        </label>
        <div class="two">
          <label>Category
            <select id="fCat"></select>
          </label>
          <label>Price (Rs.)
            <input type="number" id="fPrice" min="1" step="1" placeholder="1200" required>
          </label>
        </div>
        <label>Description
          <textarea id="fDesc" maxlength="160" placeholder="What is it made of and how is it used?"></textarea>
        </label>
        <label>Product photo
          <span class="drop" id="drop">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 16V5m0 0l-4 4m4-4l4 4M5 19h14"/></svg>
            <span id="dropText">Click to choose a photo, or drop it here</span>
            <input type="file" id="fImg" accept="image/*">
          </span>
        </label>
        <button class="btn btn-gold" type="submit">Add to shop</button>
      </form>
      <div class="preview-box">
        <h3>Live preview</h3>
        <div id="preview"></div>
        <p class="note">Products added here are saved in this browser only. To keep them for every visitor, the site needs a database and a login for you as the owner.</p>
      </div>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="about" id="about">
  <div class="wrap">
    <div>
      <div class="sec-head" style="margin-bottom:1rem"><h2>Herbal care, the way it should be</h2></div>
      <p>Saleem Herbal started with one idea: people should know exactly what they are putting in their bodies. We source herbs, honey and oils from trusted growers, and pack them in small batches.</p>
      <ul class="points">
        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>Ingredients and usage written clearly on every product</li>
        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>No artificial colours or preservatives added by us</li>
        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>Honest advice: we will tell you if a product is not right for you</li>
      </ul>
      <a class="btn btn-dark" href="#contact">Talk to us</a>
    </div>
    <div class="about-art" aria-hidden="true">
      <svg viewBox="0 0 300 300" width="88%">
        <circle cx="150" cy="150" r="120" fill="#fff" opacity=".55"/>
        <path d="M150 250V120" stroke="#17372A" stroke-width="7" stroke-linecap="round"/>
        <g fill="#2F6B45"><path d="M150 130c-46 0-70-30-70-70 46 0 70 30 70 70z"/><path d="M150 190c46 0 70-30 70-70-46 0-70 30-70 70z"/><path d="M150 230c-34 0-52-22-52-52 34 0 52 22 52 52z" fill="#7A8F3C"/></g>
        <circle cx="150" cy="96" r="10" fill="#E6A817"/>
      </svg>
    </div>
  </div>
</section>

<!-- REVIEWS -->
<section class="reviews" id="reviews">
  <div class="wrap">
    <div class="sec-head"><h2>What customers say</h2><p>Sample reviews. Replace these with real ones from your customers.</p></div>
    <div class="rev-grid">
      <div class="rev"><p>The honey tastes exactly like the one from my grandfather's village. Packing was neat and it came in two days.</p><b>Ayesha K.</b><small>Verified buyer</small></div>
      <div class="rev"><p>Good quality black seed oil, and they explained how to use it properly when I messaged them.</p><b>Imran S.</b><small>Verified buyer</small></div>
      <div class="rev"><p>I now order the herbal tea for my whole family. Fresh smell, no artificial taste.</p><b>Sana R.</b><small>Verified buyer</small></div>
    </div>
  </div>
</section>

<!-- CONTACT -->
<section class="contact" id="contact">
  <div class="wrap">
    <div>
      <div class="sec-head" style="margin-bottom:0"><h2>Get in touch</h2></div>
      <ul>
        <li><b>WhatsApp / Phone</b>0300-7993068</li>
        <li><b>Email</b>info@saleemherbal.com</li>
        <li><b>Address</b>Your shop address, City</li>
        <li><b>Open</b>Monday to Saturday, 9am to 8pm</li>
      </ul>
      <a class="btn btn-dark" id="waContact" href="#" target="_blank" rel="noopener">Chat on WhatsApp</a>
    </div>
    <form class="form" id="msgForm">
      <label>Your name<input type="text" id="mName" required></label>
      <label>Message<textarea id="mText" placeholder="Which product are you interested in?" required></textarea></label>
      <button class="btn btn-gold" type="submit">Send on WhatsApp</button>
    </form>
  </div>
</section>
</main>

<!-- FOOTER -->
<footer>
  <div class="wrap foot-main">
    <div>
      <a class="logo" href="#top">Saleem Herbal</a>
      <p>Natural herbal products, packed in small batches and delivered to your home.</p>
      <div class="social">
        <a href="https://facebook.com/" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.5h-1.3c-1.2 0-1.6.8-1.6 1.6V12h2.8l-.4 2.9h-2.3v7A10 10 0 0 0 22 12z"/></svg></a>
        <a href="https://tiktok.com/" target="_blank" rel="noopener" aria-label="TikTok"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.73 5.7 3.15 0 5.7-2.55 5.7-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"/></svg></a>
        <a href="https://instagram.com/" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1" fill="currentColor" stroke="none"/></svg></a>
        <a href="#" class="waLink" target="_blank" rel="noopener" aria-label="WhatsApp"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 21l1.6-4.6A8.5 8.5 0 1 1 8 19.6z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.6-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z" fill="currentColor" stroke="none"/></svg></a>
      </div>
    </div>
    <div>
      <h4>Shop</h4>
      <ul id="footCats"></ul>
    </div>
    <div>
      <h4>Company</h4>
      <ul>
        <li><a href="#about">About us</a></li>
        <li><a href="#reviews">Reviews</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="#upload">Add product</a></li>
      </ul>
    </div>
    <div>
      <h4>Contact</h4>
      <ul>
        <li>0300-7993068</li>
        <li>info@saleemherbal.com</li>
        <li>Mon to Sat, 9am to 8pm</li>
      </ul>
    </div>
  </div>
  <!-- BOTTOM BAR = "FOOTER BAR" / copyright bar -->
  <div class="foot-bar">
    <div class="wrap">
      <span>&copy; <span id="year"></span> Saleem Herbal. All rights reserved. <span id="today"></span></span>
      <div class="legal">
        <a href="#">Privacy policy</a><a href="#">Terms</a><a href="#">Shipping and returns</a>
      </div>
    </div>
    <div class="wrap"><p class="disclaimer">These statements have not been evaluated as a substitute for medical advice. Herbal products are not meant to diagnose, treat or cure any disease. Please consult your doctor before use, especially if you are pregnant, nursing or taking medication.</p></div>
  </div>
</footer>

<!-- CART -->
<div class="overlay" id="overlay"></div>
<aside class="drawer" id="drawer" aria-label="Shopping cart">
  <header><h3>Your cart</h3><button class="icon-btn" id="closeCart" aria-label="Close cart">Close</button></header>
  <div class="items" id="cartItems"></div>
  <footer>
    <div class="total"><span>Total</span><span id="cartTotal">Rs. 0</span></div>
    <button class="btn btn-gold" id="checkout">Order on WhatsApp</button>
  </footer>
</aside>

<a class="wa-float waLink" href="#" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 21l1.6-4.6A8.5 8.5 0 1 1 8 19.6z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.6-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z" fill="currentColor" stroke="none"/></svg>
</a>
<div class="toast" id="toast" role="status"></div>

<script>
/* ---------- SETTINGS: change these ---------- */
const WHATSAPP = "+923007993068";   // your number with country code, no + or spaces
const CATEGORIES = ["Honey","Oils","Herbal Tea","Powders","Skin Care"];
const TINT = {"Honey":"#FBEAB8","Oils":"#F1DFC2","Herbal Tea":"#DDEBD0","Powders":"#E6E9CC","Skin Care":"#F6DDE0"};
const JAR  = {"Honey":"#E6A817","Oils":"#B8741A","Herbal Tea":"#2F6B45","Powders":"#7A8F3C","Skin Care":"#C4667A"};

/* ---------- Sample products ---------- */
const SAMPLE = [
 {id:"s1",name:"Pure Sidr Honey 500g",cat:"Honey",price:2400,desc:"Thick, slow-harvested honey. One spoon with warm water in the morning."},
 {id:"s2",name:"Wild Forest Honey 250g",cat:"Honey",price:1300,desc:"Dark, rich honey with a strong flavour, sold raw and unheated."},
 {id:"s3",name:"Black Seed Oil 100ml",cat:"Oils",price:1100,desc:"Cold-pressed kalonji oil in a dark glass bottle."},
 {id:"s4",name:"Olive Oil Extra Virgin 250ml",cat:"Oils",price:1600,desc:"For cooking and for massage. Keep away from sunlight."},
 {id:"s5",name:"Calm Evening Tea",cat:"Herbal Tea",price:650,desc:"Chamomile, fennel and mint blend. Caffeine free."},
 {id:"s6",name:"Green Tea with Tulsi",cat:"Herbal Tea",price:550,desc:"Loose leaf green tea with dried tulsi leaves."},
 {id:"s7",name:"Moringa Leaf Powder 200g",cat:"Powders",price:900,desc:"Fine dried moringa leaf. Mix into water, smoothies or roti dough."},
 {id:"s8",name:"Amla Powder 250g",cat:"Powders",price:700,desc:"Sun-dried amla, ground fresh. Also used in hair packs."},
 {id:"s9",name:"Aloe Vera Gel 150g",cat:"Skin Care",price:800,desc:"Light gel for skin and hair. Patch test before first use."},
 {id:"s10",name:"Rose Water 200ml",cat:"Skin Care",price:500,desc:"Steam-distilled rose water for face mist and cooking."}
];

/* ---------- Storage (safe if blocked) ---------- */
const store = {
  get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){toast("Photo too large to save. Product added for this visit only.")}}
};
let custom = store.get("sh_custom",[]);
let cart   = store.get("sh_cart",{});
let activeCat = "All", query = "";

const $ = s => document.querySelector(s);
const fmt = n => "Rs. " + Number(n).toLocaleString("en-PK");
const esc = s => String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const all = () => [...custom.map(p=>({...p,isNew:true})), ...SAMPLE];

/* ---------- Product art (SVG jar) ---------- */
function jarSVG(cat){
  const c = JAR[cat] || "#2F6B45";
  return `<svg viewBox="0 0 120 150" aria-hidden="true">
    <rect x="34" y="8" width="52" height="20" rx="6" fill="#17372A"/>
    <rect x="28" y="26" width="64" height="112" rx="16" fill="${c}"/>
    <rect x="28" y="26" width="64" height="112" rx="16" fill="none" stroke="rgba(0,0,0,.12)" stroke-width="2"/>
    <rect x="36" y="58" width="48" height="54" rx="8" fill="#FBFCF7"/>
    <path d="M60 104V78M60 86c-8 0-12-5-12-11 8 0 12 5 12 11zm0 7c8 0 12-5 12-11-8 0-12 5-12 11z" fill="none" stroke="#17372A" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="36" y="34" width="10" height="16" rx="5" fill="rgba(255,255,255,.35)"/>
  </svg>`;
}
function cardHTML(p,{preview=false}={}){
  const pic = p.img ? `<img src="${p.img}" alt="${esc(p.name)}">` : jarSVG(p.cat);
  return `<article class="card">
    <div class="pic" style="--tint:${TINT[p.cat]||"#eef2e6"}">${pic}${p.isNew?'<span class="tag new">New</span>':`<span class="tag">${esc(p.cat)}</span>`}</div>
    <div class="body">
      <span class="cat">${esc(p.cat)}</span>
      <h3>${esc(p.name||"Product name")}</h3>
      <p>${esc(p.desc||"Your description will appear here.")}</p>
      <div class="row"><span class="price">${p.price?fmt(p.price):"Rs. 0"}</span>
      ${preview?"":`<button class="btn btn-dark" data-add="${p.id}">Add to cart</button>`}</div>
      ${p.isNew&&!preview?`<button class="remove" data-del="${p.id}">Remove this product</button>`:""}
    </div>
  </article>`;
}

/* ---------- Render shop ---------- */
function renderChips(){
  const cats = ["All",...CATEGORIES];
  $("#chips").innerHTML = cats.map(c=>`<button class="chip" aria-pressed="${c===activeCat}" data-cat="${c}">${c}</button>`).join("");
  $("#fCat").innerHTML = CATEGORIES.map(c=>`<option>${c}</option>`).join("");
  $("#footCats").innerHTML = CATEGORIES.map(c=>`<li><a href="#shop" data-footcat="${c}">${c}</a></li>`).join("");
}
function renderGrid(){
  const q = query.trim().toLowerCase();
  const list = all().filter(p => (activeCat==="All"||p.cat===activeCat) && (!q || (p.name+" "+p.desc+" "+p.cat).toLowerCase().includes(q)));
  $("#grid").innerHTML = list.length ? list.map(p=>cardHTML(p)).join("") : `<div class="empty">No products found. Try another category or search.</div>`;
}

/* ---------- Cart ---------- */
function cartLines(){ return Object.entries(cart).map(([id,q])=>({p:all().find(x=>x.id===id),q})).filter(x=>x.p); }
function renderCart(){
  const lines = cartLines();
  const count = lines.reduce((a,l)=>a+l.q,0);
  const total = lines.reduce((a,l)=>a+l.q*l.p.price,0);
  $("#cartCount").textContent = count;
  $("#cartTotal").textContent = fmt(total);
  $("#cartItems").innerHTML = lines.length ? lines.map(({p,q})=>`
    <div class="line">
      <div class="thumb">${p.img?`<img src="${p.img}" alt="">`:jarSVG(p.cat)}</div>
      <div><b>${esc(p.name)}</b><div>${fmt(p.price)}</div>
        <div class="qty"><button data-dec="${p.id}" aria-label="Less">-</button><span>${q}</span><button data-inc="${p.id}" aria-label="More">+</button></div></div>
      <b>${fmt(p.price*q)}</b>
    </div>`).join("") : `<div class="empty">Your cart is empty. Add a product from the shop.</div>`;
  store.set("sh_cart",cart);
}
function openCart(o){ $("#drawer").classList.toggle("open",o); $("#overlay").classList.toggle("open",o); }

/* ---------- Toast ---------- */
let tt; function toast(m){ const t=$("#toast"); t.textContent=m; t.classList.add("show"); clearTimeout(tt); tt=setTimeout(()=>t.classList.remove("show"),2600); }

/* ---------- Events ---------- */
document.addEventListener("click",e=>{
  const t = e.target.closest("button,a"); if(!t) return;
  if(t.dataset.cat){ activeCat=t.dataset.cat; renderChips(); renderGrid(); }
  if(t.dataset.footcat){ activeCat=t.dataset.footcat; renderChips(); renderGrid(); }
  if(t.dataset.add){ cart[t.dataset.add]=(cart[t.dataset.add]||0)+1; renderCart(); toast("Added to cart"); }
  if(t.dataset.inc){ cart[t.dataset.inc]++; renderCart(); }
  if(t.dataset.dec){ cart[t.dataset.dec]--; if(cart[t.dataset.dec]<=0) delete cart[t.dataset.dec]; renderCart(); }
  if(t.dataset.del && confirm("Remove this product from the shop?")){
    custom = custom.filter(p=>p.id!==t.dataset.del); delete cart[t.dataset.del];
    store.set("sh_custom",custom); renderGrid(); renderCart(); toast("Product removed");
  }
});
$("#search").addEventListener("input",e=>{query=e.target.value;renderGrid()});
$("#cartBtn").onclick=()=>openCart(true);
$("#closeCart").onclick=()=>openCart(false);
$("#overlay").onclick=()=>openCart(false);
document.addEventListener("keydown",e=>{if(e.key==="Escape")openCart(false)});
$("#burger").onclick=()=>{const o=$("#links").classList.toggle("open");$("#burger").setAttribute("aria-expanded",o)};
$("#links").addEventListener("click",()=>$("#links").classList.remove("open"));

$("#checkout").onclick=()=>{
  const lines=cartLines(); if(!lines.length){toast("Your cart is empty");return}
  const total=lines.reduce((a,l)=>a+l.q*l.p.price,0);
  const text="Assalam o Alaikum, I would like to order from Saleem Herbal:\n"+
    lines.map(l=>`- ${l.p.name} x ${l.q} = ${fmt(l.q*l.p.price)}`).join("\n")+`\nTotal: ${fmt(total)}`;
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`,"_blank");
};

/* ---------- Upload form + live preview ---------- */
let pendingImg = "";
function updatePreview(){
  $("#preview").innerHTML = cardHTML({id:"pv",name:$("#fName").value,cat:$("#fCat").value,price:$("#fPrice").value,desc:$("#fDesc").value,img:pendingImg,isNew:true},{preview:true});
}
["fName","fCat","fPrice","fDesc"].forEach(id=>$("#"+id).addEventListener("input",updatePreview));

function compress(file){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onerror=rej;
    r.onload=()=>{const im=new Image(); im.onerror=rej;
      im.onload=()=>{const max=640,s=Math.min(1,max/Math.max(im.width,im.height));
        const c=document.createElement("canvas"); c.width=im.width*s; c.height=im.height*s;
        c.getContext("2d").drawImage(im,0,0,c.width,c.height); res(c.toDataURL("image/jpeg",.82));};
      im.src=r.result;};
    r.readAsDataURL(file);
  });
}
async function handleFile(f){
  if(!f||!f.type.startsWith("image/")){toast("Please choose an image file");return}
  try{ pendingImg=await compress(f); $("#dropText").textContent="Photo added: "+f.name; updatePreview(); }
  catch(e){ toast("Could not read this photo. Try another one."); }
}
$("#fImg").addEventListener("change",e=>handleFile(e.target.files[0]));
const drop=$("#drop");
["dragover","dragenter"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add("over")}));
["dragleave","drop"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove("over")}));
drop.addEventListener("drop",e=>handleFile(e.dataTransfer.files[0]));

$("#prodForm").addEventListener("submit",e=>{
  e.preventDefault();
  const p={id:"c"+Date.now(),name:$("#fName").value.trim(),cat:$("#fCat").value,price:Number($("#fPrice").value),desc:$("#fDesc").value.trim(),img:pendingImg};
  if(!p.name||!p.price){toast("Enter a product name and price");return}
  custom.unshift(p); store.set("sh_custom",custom);
  e.target.reset(); pendingImg=""; $("#dropText").textContent="Click to choose a photo, or drop it here";
  activeCat="All"; query=""; $("#search").value="";
  renderChips(); renderGrid(); updatePreview(); toast("Product added to the shop");
  document.getElementById("shop").scrollIntoView({behavior:"smooth"});
});

/* ---------- Contact ---------- */
$("#msgForm").addEventListener("submit",e=>{
  e.preventDefault();
  const t=`Assalam o Alaikum, I am ${$("#mName").value}. ${$("#mText").value}`;
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(t)}`,"_blank");
});
document.querySelectorAll(".waLink,#waContact").forEach(a=>a.href=`https://wa.me/${WHATSAPP}`);

/* ---------- Footer date ---------- */
const now=new Date();
$("#year").textContent=now.getFullYear();
$("#today").textContent=now.toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"});

/* ---------- Start ---------- */
renderChips(); renderGrid(); renderCart(); updatePreview();
</script>
</body>
</html>